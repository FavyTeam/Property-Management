import Ember from 'ember';

const { Mixin, computed } = Ember;

export default Mixin.create({
  classNames: ['form-group'],
  classNameBindings: ['hasError'],

  hasError: computed.bool('errors.length'),

  errorMessages: computed.map('errors', function(error) {
    return error.message || error;
  })
});
