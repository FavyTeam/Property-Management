import DS from 'ember-data';

const { Model, attr, belongsTo } = DS;

export default Model.extend({
  waitListIdNo: attr('number'),
  propertyRef: attr('string'),
  dateAdded: attr('string'),

  prospectIdNo: belongsTo('prospect'),  
});
