import DS from 'ember-data';
import Ember from 'ember';
import moment from 'moment';

const { Model, attr, belongsTo } = DS;
const { computed, get } = Ember;

export default Model.extend({
  addr1: attr('string'),
  addr2: attr('string'),
  addr3: attr('string'),
  addr4: attr('string'),
  postcode: attr('string'),
  area: belongsTo('area'),
  lordRef: attr('string'),
  dateOn: attr('string'),
  takeOnBy: attr('number'),
  accountType: attr('string'),
  propRef: attr('string'),
  bedrooms: attr('number'),
  singleBedrooms: attr('number'),
  doubleBedrooms: attr('number'),
  toLet: attr('boolean'),
  availableDate: attr('string'),
  rent: attr('number'),
  current: attr('string'),
  tentRef: attr('string'),
  contRef: attr('number'),
  llSource: attr('number'),
  floors: attr('number'),
  createdAt: attr('date'),
  placement: attr('boolean'),
  appointments: attr('boolean'),
  primaryPhoto: attr(),
  furnished: attr('boolean'),
  heating: belongsTo('heating'),
  houseType: belongsTo('housetype'),
  dogs: attr('boolean'),
  cats: attr('boolean'),
  smokers: attr('boolean'),
  sharers: attr('boolean'),
  detached: attr('boolean'),
  garage: attr('boolean'),
  driveway: attr('boolean'),
  appliances: attr('boolean'),
  parkingFor: attr('number'),
  garden: attr('boolean'),
  upperFloor: attr('boolean'),
  groundFloor: attr('boolean'),

  formattedDateOn: computed('dateOn', function() {
    return get(this, 'dateOn') ? moment(get(this, 'dateOn')).format('MM/DD/YYYY') : '';
  }),

  computedAvailableDate: computed('availableDate', function() {
    if (get(this, 'availableDate')) {
      return moment(get(this, 'availableDate')) <= moment() ? 'Now' : moment(get(this, 'availableDate')).format('MM/DD/YYYY');
    }
    return '';
  }),

  isNew: computed('createdAt', function() {
    let baseDate = moment().subtract(150, 'days');
    let dateAdded = moment(get(this, 'dateAdded'));

    return dateAdded >= baseDate ? 'Yes' : '';
  }),

  address: computed('{addr1,addr2,addr3,addr4}', function() {
    let address = [];
    if (get(this, 'addr1') && get(this, 'addr1') !== '-') address.push(get(this, 'addr1'));
    if (get(this, 'addr2') && get(this, 'addr2') !== '-') address.push(get(this, 'addr2'));
    if (get(this, 'addr3') && get(this, 'addr3') !== '-') address.push(get(this, 'addr3'));
    if (get(this, 'addr4') && get(this, 'addr4') !== '-') address.push(get(this, 'addr4'));

    return address.join(', ');
  })

});
