import DS from 'ember-data';
import Ember from 'ember';
import moment from 'moment';

const { attr } = DS;
const { computed, get } = Ember;

export default DS.Model.extend({
  firstName: attr('string'),
  lastName: attr('string'),
  email: attr('string'),
  initials: attr('string'),
  ext: attr('string'),
  returnDate: attr('date'),
  returnTime: attr('date'),
  mobileNumber: attr('string'),
  lunch: attr('date'),
  nextEvening: attr('date'),
  createdAt: attr('date'),
  updatedAt: attr('date'),

  lunchTime: computed('lunch', function() {
    return get(this, 'lunch') ? moment(get(this, 'lunch')).format('HH:MM') : '';
  }),

  ret: computed('returnDate', function() {
    return get(this, 'returnDate') ? moment(get(this, 'returnDate')).format('MM/DD/YYYY') : '';
  }),

  time: computed('returnTime', function() {
    return get(this, 'returnTime') ? moment(get(this, 'returnTime')).format('HH:MM') : '';
  }),

  eve: computed('nextEvening', function() {
    return get(this, 'nextEvening') ? '*E' : '';
  }),

  fullName: computed('firstName', 'lastName', function() {
    return `${get(this, 'firstName')} ${get(this, 'lastName')}`;
  })
});
