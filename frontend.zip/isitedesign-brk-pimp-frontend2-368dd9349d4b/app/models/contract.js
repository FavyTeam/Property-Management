import DS from 'ember-data';

const { attr } = DS;

export default DS.Model.extend({
  contRef: attr('number'),
  tentRef: attr('string'),
  propRef: attr('string'),
  termFrom: attr(),
  termTo: attr(),
  drawnUp: attr(),
  rent: attr('number'),
  rentIncreaseDate: attr(),
  newRent: attr('number'),
  payMethod: attr('string'),
  payDay: attr('number'),
  noRenew: attr(),
  paymentCheckedNotes: attr('string')
});
