import DS from 'ember-data';
import Ember from 'ember';
import moment from 'moment';

const { Model, attr, belongsTo } = DS;
const { computed, get } = Ember;

export default Model.extend({
  dateAdded: attr(),
  timeAdded: attr(),
  whoBooked: belongsTo('user'),
  appSource: attr('string'),
  whoDoing: belongsTo('user'),
  area: belongsTo('area'),
  date: attr(),
  time: attr(),
  propRef: attr('string'),
  prospect: belongsTo('prospect'),
  appNotes: attr('string'),
  rtc: attr('boolean'),
  confirmOcc: attr('boolean'),
  confirmOccNotes: attr('string'),
  confirmedOcc: attr('boolean'),
  whoConf: attr('string'),
  confNotes: attr('string'),
  showed: attr('boolean'),
  showedUp: attr('string'),
  interested: attr('boolean'),
  tenantFeedback: attr('string'),
  brookdaleFeedback: attr('string'),
  text: attr('boolean'),
  appDateTime: computed('date', function() {
    return `${get(this, 'appDate')} ${get(this, 'appTime')}`;
  }),

  appDate: computed('date', function() {
    return get(this, 'date') ? moment(get(this, 'date')).format('MM/DD/YYYY') : '-';
  }),
  appDateAdded: computed('dateAdded', function() {
    return get(this, 'dateAdded') ? moment(get(this, 'dateAdded')).format('MM/DD/YYYY') : '-';
  }),
  appTime: computed('time', function() {
    return get(this, 'time') ? moment(get(this, 'time')).format('hh:mm A') : '-';
  }),
  appTimeAdded: computed('timeAdded', function() {
    return get(this, 'timeAdded') ? moment(get(this, 'timeAdded')).format('hh:mm A') : '-';
  }),
  cReqd: computed('confirmOcc', function() {
    return get(this, 'confirmOcc') ? 'Y' : '';
  }),
  cRecv: computed('confirmOcc', 'confirmedOcc', function() {
    let retVal = '';
    if (get(this, 'confirmOcc')) {
      retVal = get(this, 'confirmedOcc') ? 'Yes' : '**No**';
    }
    return retVal;
  }),
  cText: computed('text', function() {
    return get(this, 'text') ? 'Y' : '';
  }),
  cRTC: computed('rtc', function() {
    return get(this, 'rtc') ? 'Y' : '';
  })
});
