import DS from 'ember-data';

const { Model, attr, belongsTo } = DS;

export default Model.extend({
  category: attr('string'),
  source: attr('string'),
  minmal: attr('boolean'),
  sourcesCategory: belongsTo('sourcescategory'),
  spoke: attr('boolean'),
  prics: attr('boolean'),
});
