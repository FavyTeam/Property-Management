import DS from 'ember-data';

const { attr, Model } = DS;

export default Model.extend({
  name: attr('string'),
  title: attr('string'),
  foreName: attr('string'),
  surName: attr('string'),
  address1: attr('string'),
  address2: attr('string'),
  address3: attr('string'),
  address4: attr('string'),
  postcode: attr('string'),
  telNo: attr('string'),
  faxNo: attr('string'),
  otherTel: attr('string'),
  mgsi: attr('string'),
  contact: attr('string'),
  description: attr('string'),
  specialComments: attr('string'),
  notUsed: attr('boolean'),
  sendLetter: attr('boolean'),
  blockDate: attr('string'),
  reason: attr('string'),
  blockedExpiry: attr('string'),
  pliStart: attr('string'),
  pliEnd: attr('string'),
  emailContact: attr('string'),
  gsi: attr('boolean'),
  invisible: attr('boolean')
});
