import DS from 'ember-data';

const { attr, Model } = DS;

export default Model.extend({
  lordRef: attr('string'),
  maintRef: attr(),
  blockBy: attr(),
  blockDate: attr('string'),
  blockNotes: attr('string')
});
