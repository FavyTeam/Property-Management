import DS from 'ember-data';

const { Model, attr } = DS;

export default Model.extend({
  areaIdNo: attr('number'),
  area: attr('string'),
  areaCat: attr('number'),
  webId: attr('number'),
  gasId: attr('number')
});
