import DS from 'ember-data';

const {
  Model,
  attr,
  belongsTo
} = DS;

export default Model.extend({
  bookedDate: attr(),
  bookedTime: attr(),
  date: attr('string'),
  time: attr('string'),
  someType: attr('number'),
  name: attr('string'),
  address: attr('string'),
  area: attr('string'),
  conf1Date: attr(),
  conf1Time: attr(),
  conf1Notes: attr('string'),
  conf2Date: attr(),
  conf2Time: attr(),
  conf2Notes: attr('string'),
  bookedBy: belongsTo('user'),
  conf1By: belongsTo('user'),
  conf2By: belongsTo('user'),
  for: belongsTo('user'),
  newProperty: belongsTo('new-property'),
  prospect: belongsTo('prospect'),
});
