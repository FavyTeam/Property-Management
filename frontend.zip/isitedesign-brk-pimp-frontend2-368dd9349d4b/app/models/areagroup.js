import DS from 'ember-data';

const { Model, attr, belongsTo } = DS;

export default Model.extend({
  areaGroupIdNo: attr('number'),
  areaGroupNo: belongsTo('areagroupspttemp'),
  areaGroupName: attr('string'),
  area: belongsTo('area')
});
