import Ember from 'ember';
import DS from 'ember-data';
import moment from 'moment';

const { Model, attr, belongsTo } = DS;
const { computed, get } = Ember;

export default Model.extend({  
  propRef: attr('string'),
  property: attr(),
  dateAdded: attr(),
  addedBy: belongsTo('user'),  
  status: belongsTo('upgradestatus'),
  notes: attr('string'),
  nextActionDate: attr(),
  nextActionBy: belongsTo('user'),
  nextAction: attr('string'),
  closed: attr('boolean'),
  lock: attr('boolean'),
  llAware: attr('boolean'),
  llAwareBy: belongsTo('user'),
  llAwareDate: attr(),

  cNextActionDate: computed('nextActionDate', function() {
      return get(this, 'nextActionDate') ? moment(get(this, 'nextActionDate')).format('MM/DD/YYYY') : '';
  }),
  cDateAdded: computed('dateAdded', function() {
      return get(this, 'dateAdded') ? moment(get(this, 'dateAdded')).format('MM/DD/YYYY') : '';
  }),
  cLLAware: computed('llAware', function() {
      return get(this, 'llAware') ? 'Y' : '';
  })  
});
