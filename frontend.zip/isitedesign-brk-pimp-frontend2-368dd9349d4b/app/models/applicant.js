import DS from 'ember-data';

const { Model, attr } = DS;

export default Model.extend({
  appid: attr('number'),
  dateCreated: attr('string'),
  surName: attr('string'),
  foreName: attr('string'),
  homeAddr1: attr('string'),
  homeAddr2: attr('string'),
  homeAddr3: attr('string'),
  homeAddr4: attr('string'),
  homePostCode: attr('string'),
  telHome: attr('string'),
  telWork: attr('string'),
  telMobile: attr('string'),
  email: attr('string')
});
