import DS from 'ember-data';

const { Model, attr } = DS;

export default Model.extend({
  addr1: attr('string'),
  addr2: attr('string'),
  addr3: attr('string'),
  addr4: attr('string'),
  postcode: attr('string'),
  area: attr('string'),
  lordRef: attr('string')
});
