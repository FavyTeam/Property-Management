import DS from 'ember-data';
import Ember from 'ember';

const { attr, Model } = DS;

export default Model.extend({
  companyName: attr('string'),
  title: attr('number'),
  foreName: attr('string'),
  surName: attr('string'),
  address1: attr('string'),
  address2: attr('string'),
  address3: attr('string'),
  address4: attr('string'),
  postcode: attr('string'),
  phoneWork: attr('string'),
  fax: attr('string'),
  phoneMobile: attr('string'),
  email: attr('string'),
  charge: attr('number'),
  createdAt: attr('date'),
  updatedAt: attr('date'),

  contactNumber: Ember.computed('phoneWork', 'phoneMobile', function() {
    return this.get('phoneWork') || this.get('phoneMobile');
  }),
});
