import DS from 'ember-data';

const { Model, attr, belongsTo } = DS;

export default Model.extend({
  deleted: attr('boolean'),
  deleteReason: attr('number'),
  dateAdded: attr('string'),
  addedBy: attr(),
  managedBy: attr(),
  title: attr('string'),
  foreName: attr('string'),
  surName: attr('string'),
  addr1: attr('string'),
  addr2: attr('string'),
  addr3: attr('string'),
  addr4: attr('string'),
  postcode: attr('string'),
  telHome: attr('string'),
  telWork: attr('string'),
  telMobile: attr('string'),
  email: attr('string'),
  source: attr('number'),
  planorLand: attr('number'),
  buying: attr('boolean'),
  dealNotes: attr('string'),
  buyAim: attr('string'),
  type: belongsTo('housetype'),
  siteOffice: attr('boolean'),
  deal: attr('boolean'),
  nextContact: attr('string')
});
