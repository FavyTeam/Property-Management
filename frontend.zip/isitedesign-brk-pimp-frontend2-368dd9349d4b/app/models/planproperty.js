import DS from 'ember-data';

const { Model, attr } = DS;

export default Model.extend({
  planIdNo: attr('string'),
  address1: attr('string'),
  address2: attr('string'),
  address3: attr('string'),
  address4: attr('string'),
  postcode: attr('string'),
  area: attr(),
  bedrooms: attr('string'),
  type: attr('string'),
  conditionChecked: attr('boolean'),
  conditionCheckedBy: attr('number')
});
