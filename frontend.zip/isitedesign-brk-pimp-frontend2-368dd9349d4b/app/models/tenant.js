import DS from 'ember-data';

const { Model, attr } = DS;

export default Model.extend({
  tentRef: attr('string'),
  propRef: attr('string'),
  contRef: attr('number'),
  foreName: attr('string'),
  initials: attr('string'),
  surName: attr('string'),
  addr1: attr('string'),
  addr2: attr('string'),
  addr3: attr('string'),
  addr4: attr('string'),
  postcode: attr('number'),
  telHome: attr('number'),
  telWork: attr('number'),
  mobile: attr('number'),
  email: attr('string'),
  source: attr('string')
});
