import Ember from 'ember';

const { RSVP, inject: { service } } = Ember;

export default Ember.Service.extend({
  session: service(),
  store: service(),

  load() {
    if (!this.get('session.isAuthenticated')) {
      return RSVP.resolve();
    }
    return this.get('store').queryRecord('user', { me: true })
      .then((user) => this.set('user', user));
  }
});
