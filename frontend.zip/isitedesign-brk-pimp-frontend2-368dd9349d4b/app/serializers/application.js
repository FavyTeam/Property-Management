import DS from 'ember-data';
import Ember from 'ember';

const { RESTSerializer } = DS;
const { merge } = Ember;

export default RESTSerializer.extend({
  serializeIntoHash(hash, type, record, options) {
    merge(hash, this.serialize(record, options));
  }
});
