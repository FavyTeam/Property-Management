import Application from './application';

export default Application.extend({
  attrs: {
    planType: 'PlanType'
  }
});
