import Application from './application';

export default Application.extend({
  attrs: {
    addr1: 'addr_1',
    addr2: 'addr_2',
    addr3: 'addr_3',
    addr4: 'addr_4',
    lordRef: 'lord_ref'
  }
});
