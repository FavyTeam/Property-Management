import Application from './application';

export default Application.extend({
  attrs: {
    areaIdNo: 'AreadIdNo',
    area: 'Area',
    areaCat: 'AreaCat',
    webId: 'WebId',
    gasId: 'GasId'
  }
});
