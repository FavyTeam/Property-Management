import OAuth2BearerAuthorizer from 'ember-simple-auth/authorizers/oauth2-bearer';

export default OAuth2BearerAuthorizer;
