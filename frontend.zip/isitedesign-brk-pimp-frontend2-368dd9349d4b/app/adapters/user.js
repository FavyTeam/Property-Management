import ApplicationAdapter from './application';
import ENV from 'project-dashboard/config/environment';

const { APP: { apiStandardsTree, apiSubtype } } = ENV;

export default ApplicationAdapter.extend({
  headers: {
    Accept: `application/${apiStandardsTree}.${apiSubtype}.v2+json`
  },

  urlForQueryRecord(query) {
    if (query.me) {
      delete query.me;
      return `${this._super(...arguments)}/me`;
    }
    return this._super(...arguments);
  }
});
