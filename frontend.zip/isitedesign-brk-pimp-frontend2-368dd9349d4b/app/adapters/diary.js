import ApplicationAdapter from './application';
import ENV from 'project-dashboard/config/environment';

const { APP: { apiStandardsTree, apiSubtype } } = ENV;

export default ApplicationAdapter.extend({
  headers: {
    Accept: `application/${apiStandardsTree}.rest.v2+json`
  }
});
