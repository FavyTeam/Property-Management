import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('dashboard', function() {
    this.route('properties', function() {
      this.route('details', {path: '/:newproperty_id'}, function() {
        this.route('basic-details');
        this.route('epc-green-deal');
        this.route('marketing');
        this.route('nrl');
        this.route('oic');
        this.route('owner-office-meters');
        this.route('rgri');
        this.route('selective-licensing');
        this.route('tenant-info-alarm');
        this.route('visuals');
      });
      this.route('landlords', {path: '/:landlord_id'}, function() {
        this.route('contact-details');
        this.route('overseas-details');
        this.route('id-proof');
        this.route('blocked-engineers');
      });

      this.route('tenants', function() {
        this.route('account');
      });

      this.route('misc', function(){
        this.route('letting-agents', function() {
          this.route('add');
        });
      });

      this.route('financials');

      this.route('message-note');
    });

    this.route('plans', function() {
      this.route('searchAdd');
      this.route('add');
      this.route('plan', {path: '/:plan_id'}, function() {

      });
    });
    this.route('snatchs', function() {
      this.route('searchAdd');
      this.route('add');
      this.route('snatch', {path: '/:snatch_id'}, function() {

      });
    });

    this.route('landlords', function() {
        this.route('find');
    });

    this.route('marketing');
    this.route('apps', function() {

    });
    this.route('office', function() {
      this.route('activity-summary');
      this.route('office-diary');
      this.route('tq-appointment');
    });
    this.route('ooc');
    this.route('notes');
    this.route('insp', function() {
      this.route('confirm-inspections');
    });

    this.route('gas', function() {
      this.route('edit-detector-details');
      this.route('legionellas-details');
    });

    this.route('tolet');
    this.route('msgs');
    this.route('finew');
    this.route('ap');
    this.route('control');
    this.route('docs');
    this.route('bums');
    this.route('reports');
    this.route('prospects', function() {
      this.route('tenant-entry');
    });

    this.route('rats');
    this.route('staff-tracker');
    this.route('key');

  });
  this.route('login');

});

export default Router;
