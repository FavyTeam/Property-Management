import OAuth2PasswordGrant from 'ember-simple-auth/authenticators/oauth2-password-grant';
import ENV from 'project-dashboard/config/environment';

const { APP: { apiHost, apiClientId, apiClientSecret} } = ENV;

export default OAuth2PasswordGrant.extend({
  serverTokenEndpoint: `${apiHost}/api/token`,

  makeRequest(url, data, headers = {}) {
    data.client_id = apiClientId;
    data.client_secret = apiClientSecret;
    data.username = data.username || '';
    data.password = data.password || '';
    return this._super(url, data, headers);
  }
});
