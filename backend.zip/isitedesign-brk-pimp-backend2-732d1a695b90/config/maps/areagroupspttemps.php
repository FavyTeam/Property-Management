<?php

return [
    'areaGroupNo' => 'AreaGroupNo',
    'areaGroupName' => 'AreaGroupName'
];
