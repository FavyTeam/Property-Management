<?php

return [
    'lordRef' => 'Lordref',
    'maintRef' => 'Maintref',
    'blockBy' => 'Blockby',
    'blockDate' => 'Blockdate',
    'blockNotes' => 'Blocknotes',
];