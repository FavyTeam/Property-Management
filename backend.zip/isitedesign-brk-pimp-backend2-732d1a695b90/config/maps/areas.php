<?php

return [
    'areaIdNo' => 'AreaIdNo',
    'area' => 'Area',
    'areaCat' => 'AreaCat',
    'webId' => 'WebId',
    'gasId' => 'Gasid',
];