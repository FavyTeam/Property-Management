<?php

return [
    'areaGroupIdNo' => 'Areagroupidno',
    'areaGroupNo' => 'AreaGroupNo',
    'areaGroupName' => 'AreaGroupName',
    'area' => 'Area'
];
