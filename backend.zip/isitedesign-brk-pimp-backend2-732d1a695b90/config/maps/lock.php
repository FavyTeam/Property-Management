<?php

return [
    'text' => 'Locktext',
];