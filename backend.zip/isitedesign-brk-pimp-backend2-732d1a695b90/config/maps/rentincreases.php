<?php

return [
    'transactionDate' => 'TransactionDate',
    'propRef' => 'PropertyRef',
    'contRef' => 'Contref',
    'riDate' => 'RIDate',
    'oldRent' => 'OldRent',
    'newRent' => 'Newrent',
];