<?php

return [
    'idNo' => 'IdNo',
    'description' => 'Description',
    'net' => 'Net',
    'vat' => 'VAT',
    'total' => 'Total',
    'notUsed' => 'NotUsed',
];