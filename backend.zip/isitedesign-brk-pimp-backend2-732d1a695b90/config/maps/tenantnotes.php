<?php

return [
    'tentRef' => 'TenantRef',
    'notes' => 'Notes',
];