<?php

return [
    'waitListIdNo' => 'WaitlistIdno',
    'prospectIdNo' => 'ProspectIdNo',
    'propertyRef' => 'PropertyRef',
    'dateAdded' => 'DateAdded',
];