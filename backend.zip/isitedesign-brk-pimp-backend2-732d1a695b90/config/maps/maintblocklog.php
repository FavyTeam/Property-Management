<?php

return [
    'idNo' => 'MaintBlockLogIdno',
    'company' => 'Maintco',
    'type' => 'Type',
    'date' => 'Date',
    'who' => 'Who',
    'reason' => 'Reason',
];