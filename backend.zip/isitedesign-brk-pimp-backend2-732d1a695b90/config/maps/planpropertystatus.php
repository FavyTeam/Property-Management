<?php

return [
    'status' => 'Status',
];