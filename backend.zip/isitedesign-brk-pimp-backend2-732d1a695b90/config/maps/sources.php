<?php

return [
    'category' =>'Category',
    'source' =>'Source',
    'minimal' =>'Minimal',
    'sourcesCategory' =>'SourcesCategory',
    'spoke' =>'Spoke',
    'prics' => 'PRICS',
];
