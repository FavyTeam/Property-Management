<?php

return [
    'title' => 'Title',
];