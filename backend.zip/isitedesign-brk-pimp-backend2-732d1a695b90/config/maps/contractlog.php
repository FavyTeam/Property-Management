<?php

return [
    'contRef' => 'Contref',
    'date' => 'Date',
    'time' => 'Time',
    'user' => 'User',
    'details' => 'Details',
];
