<?php

return [
    'planIdNo' => 'PlanIdno',
    'address1' => 'Address1',
    'address2' => 'Address2',
    'address3' => 'Address3',
    'address4' => 'Address4',
    'postcode' => 'Postcode',
    'status' => 'PropertyStatus',
    'area' => 'Area',
    'bedrooms' => 'Bedrooms',
    'type' => 'PropertyType',
    'conditionChecked' => 'Conditionchecked',
    'conditionCheckedBy' => 'Conditioncheckedby',
    'foundBy' => 'Foundby',
    'dateAdded' => 'dateAdded',
];