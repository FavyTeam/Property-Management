<?php

return [
    'propRef' => 'Propref',
    'letter' => 'Letter',
    'date' => 'Date',
];