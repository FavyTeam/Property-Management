<?php

return [
    'heating' => 'Heating',
];