<?php

return [
    'type' => 'HouseType',
    'webId' => 'WebId',
    'rightMoveId' => 'RightmoveId',
];