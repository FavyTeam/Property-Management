<?php

return [
    'propRef' => 'PropertyRef',
    'contRef' => 'Contref',
    'contractDate' => 'ContractDate',
    'months' => 'Months',
    'startDate' => 'StartDate',
    'endDate' => 'EndDate',
    'rent' => 'Rent',
    'payDate' => 'PayDate',
    'firstPayment' => 'FirstPayment',
    'deposit' => 'Deposit',
    'tenancyFee' => 'TenancyFee',
    'tenancyRenewal' => 'TenancyRenewal',
    'payMethod' => 'PayMethod',
    'active' => 'Active',
];