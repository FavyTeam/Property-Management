<?php

return [
    'reason' => 'Reason',
];