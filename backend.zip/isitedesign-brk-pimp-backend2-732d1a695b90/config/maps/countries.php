<?php

return [
    'country' => 'Country',
    'formalName' => 'FormalName',
];