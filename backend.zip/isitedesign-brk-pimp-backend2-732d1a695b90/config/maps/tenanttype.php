<?php

return [
    'type' => 'TenantType',
];