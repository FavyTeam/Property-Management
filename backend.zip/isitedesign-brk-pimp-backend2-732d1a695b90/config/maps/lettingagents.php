<?php

return [
    'companyName' => 'CompanyName',
    'title' => 'Title',
    'foreName' => 'Forename',
    'surName' => 'Surname',
    'address1' => 'Address1',
    'address2' => 'Address2',
    'address3' => 'Address3',
    'address4' => 'Address4',
    'postcode' => 'PostCode',
    'phoneWork' => 'PhoneWork',
    'fax' => 'Fax',
    'phoneMobile' => 'PhoneMobile',
    'email' => 'Email',
    'charge' => 'Charge',
];