<?php

return [
    'payMethod' => 'Paymethod',
];