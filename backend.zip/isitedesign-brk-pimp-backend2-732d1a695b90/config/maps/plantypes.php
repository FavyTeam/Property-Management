<?php

return [
    'type' => 'PlanType',
];