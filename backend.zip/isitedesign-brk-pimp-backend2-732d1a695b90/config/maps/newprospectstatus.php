<?php

return [
    'status' => 'ProspectStatus',
];