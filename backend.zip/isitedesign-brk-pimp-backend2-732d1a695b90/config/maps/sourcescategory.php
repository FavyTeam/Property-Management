<?php

return [
    'sourcesCategory' => 'SourcesCategory',
];
