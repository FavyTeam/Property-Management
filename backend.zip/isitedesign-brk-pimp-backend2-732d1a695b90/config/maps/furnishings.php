<?php

return [
    'furnishing' => 'Furnishing',
];