<?php

return [
    'rent' => 'Rent',
];