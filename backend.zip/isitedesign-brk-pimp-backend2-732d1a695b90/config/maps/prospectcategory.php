<?php

return [
    'description' => 'Description',
];