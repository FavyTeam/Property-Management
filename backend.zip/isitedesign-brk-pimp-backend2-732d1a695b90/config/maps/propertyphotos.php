<?php

return [
    'propRef' => 'PropertyRef',
    'fileName' => 'filename',
    'isPrimary' => 'is_primary',
];