<?php

return [
    'property' => 'Propertyid',
    'lettingAgent' => 'Lettingagent',
    'dateRecorded' => 'Daterecorded',
];