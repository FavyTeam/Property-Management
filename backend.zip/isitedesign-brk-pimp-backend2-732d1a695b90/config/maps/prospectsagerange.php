<?php

return [
    'range' => 'AgeRange',
];