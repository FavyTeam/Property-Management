<?php

return [
    'invoiceIdNo' => 'InvoiceIdNo',
    'date' => 'Date',
    'tentRef' => 'TentRef',
    'propRef' => 'PropRef',
    'firstName' => 'Firstname',
    'surName' => 'Surname',
    'addr1' => 'Addr1',
    'addr2' => 'Addr2',
    'addr3' => 'Addr3',
    'addr4' => 'Addr4',
    'postcode' => 'PostCode',
    'invLine' => 'Invline',
    'net' => 'Net',
    'vat' => 'VAT',
    'total' => 'Total',
];