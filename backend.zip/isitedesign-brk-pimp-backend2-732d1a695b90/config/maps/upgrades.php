<?php

return [
    'propRef' => 'Propertyref',
    'dateAdded' => 'DateAdded',
    'addedBy' => 'Addedby',
    'status' => 'Status',
    'notes' => 'Notes',
    'nextActionDate' => 'Nextactiondate',
    'nextActionBy' => 'Nextactionby',
    'nextAction' => 'NextAction',
    'closed' => 'Closed',
    'lock' => 'Lock',
    'llAware' => 'LLAware',
    'llAwareBy' => 'LLAwareby',
    'llAwareDate' => 'LLAwareDate',
];