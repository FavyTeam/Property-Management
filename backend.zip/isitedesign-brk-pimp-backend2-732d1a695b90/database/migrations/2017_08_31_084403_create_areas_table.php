<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateAreasTable extends Migration
{
    const TABLE = 'areas';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('AreaIdNo')->unsigned()->nullable();
            $table->string('Area', 50)->nullable()->unique('Area');
            $table->integer('AreaCat')->nullable()->default(0);
            $table->integer('WebId')->nullable()->default(0)->index('WebId');
            $table->integer('Gasid')->nullable()->default(0)->index('Gasid');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }

}
