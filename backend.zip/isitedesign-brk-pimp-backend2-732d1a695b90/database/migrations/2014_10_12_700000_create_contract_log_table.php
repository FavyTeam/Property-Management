<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateContractLogTable extends Migration
{
    const TABLE = 'contractlog';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('Contref')->unsigned()->default('0')->nullable();
            $table->dateTime('Date')->nullable();
            $table->dateTime('Time')->nullable();
            $table->integer('User')->unsigned()->default('0')->nullable();
            $table->string('Details', 100)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('User')
                  ->references('id')
                  ->on('users')
                  ->onDelete('cascade');

        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
