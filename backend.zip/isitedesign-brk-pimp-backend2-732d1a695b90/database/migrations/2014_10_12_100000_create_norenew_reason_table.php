<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateNoRenewReasonTable extends Migration
{
    const TABLE = 'norenewreason';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('Reason', 50)->nullable();
            $table->timestamps();
            $table->softDeletes();           
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
