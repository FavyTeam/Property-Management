<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AlterPlansTable extends Migration
{
    const TABLE = 'plans';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('Title', 20)->nullable()->change();
            $table->string('Source', 100)->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('Title', 5)->nullable()->change();
            $table->integer('Source')->default('0')->nullable()->change();
        });

    }
}
