<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateLordblockTable extends Migration
{
    const TABLE = 'lordblock';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('Lordref', 50)->nullable()->index('Lordref');
            $table->integer('Maintref')->unsigned()->nullable()->index('Maintref');
            $table->integer('Blockby')->unsigned()->nullable();
            $table->dateTime('Blockdate')->nullable();
            $table->longText('Blocknotes')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
