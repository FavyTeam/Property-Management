<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateContractHistoryTable extends Migration
{
    const TABLE = 'contracthistory';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('cont_ref')->unsigned()->default('0')->nullable();
            $table->string('tent_ref', 10)->nullable();
            $table->string('prop_ref', 10)->nullable();
            $table->dateTime('term_from')->nullable();
            $table->dateTime('term_to')->nullable();
            $table->dateTime('drawn_up')->nullable();
            $table->string('ContractType', 50)->nullable();
            $table->string('terminated', 5)->nullable();
            $table->decimal('Rent', 19, 4)->default('0.0000')->nullable();
            $table->string('PayMethod')->nullable();
            $table->integer('PayDay')->nullable();
            $table->tinyInteger('AutoInvoice')->length(1)->nullable();
            $table->tinyInteger('Periodic')->length(1)->default('0')->nullable();
            $table->longText('PayNotes')->nullable();
            $table->tinyInteger('NoRenew')->length(1)->nullable();
            $table->integer('NoRenewreason')->unsigned()->default('0')->nullable();
            $table->tinyInteger('UnderNotice')->length(1)->nullable();
            $table->string('NoticeReason', 50)->nullable();
            $table->dateTime('NoticeExpires')->nullable();
            $table->dateTime('TenantPlansToVacate')->nullable();
            $table->dateTime('CourtOrder')->nullable();
            $table->dateTime('BailliffOrder')->nullable();
            $table->dateTime('DateVacated')->nullable();
            $table->longText('NoticeNotes')->nullable();
            $table->dateTime('RentIncreaseDate')->nullable();
            $table->decimal('NewRent', 19, 4)->default('0.0000')->nullable();
            $table->dateTime('initialdrawn_up')->nullable();
            $table->dateTime('initialterm_from')->nullable();
            $table->dateTime('initialterm_to')->nullable();
            $table->string('LandlordName', 100)->nullable();
            $table->integer('NoTenants')->unsigned()->default('0')->nullable();
            $table->string('Tenant1Name', 100)->nullable();
            $table->string('Tenant2Name', 100)->nullable();
            $table->string('Tenant3Name', 100)->nullable();
            $table->string('Tenant1Address1', 50)->nullable();            
            $table->string('Tenant1Address2', 50)->nullable();            
            $table->string('Tenant1Address3', 50)->nullable();            
            $table->string('Tenant2Address1', 50)->nullable();            
            $table->string('Tenant2Address2', 50)->nullable();            
            $table->string('Tenant2Address3', 50)->nullable();            
            $table->string('Tenant3Address1', 50)->nullable();            
            $table->string('Tenant3Address2', 50)->nullable();            
            $table->string('Tenant3Address3', 50)->nullable();    
            $table->string('GuarantorName', 100)->nullable();
            $table->string('GuarantorAddress1', 50)->nullable();        
            $table->string('GuarantorAddress2', 50)->nullable();
            $table->string('GuarantorAddress3', 50)->nullable();
            $table->string('GuarantorAddress4', 50)->nullable();
            $table->string('GuarantorPostCode', 50)->nullable();
            $table->string('Guarantor2Name', 100)->nullable();
            $table->string('Guarantor2Address1', 50)->nullable();        
            $table->string('Guarantor2Address2', 50)->nullable();
            $table->string('Guarantor2Address3', 50)->nullable();
            $table->string('Guarantor2Address4', 50)->nullable();
            $table->string('Guarantor2PostCode', 50)->nullable();
            $table->string('Guarantor3Name', 100)->nullable();
            $table->string('Guarantor3Address1', 50)->nullable();        
            $table->string('Guarantor3Address2', 50)->nullable();
            $table->string('Guarantor3Address3', 50)->nullable();
            $table->string('Guarantor3Address4', 50)->nullable();
            $table->string('Guarantor3PostCode', 50)->nullable();
            $table->string('PropertyAddress1', 50)->nullable();
            $table->string('PropertyAddress2', 50)->nullable();
            $table->string('PropertyAddress3', 50)->nullable();
            $table->string('Months', 10)->nullable();
            $table->dateTime('FirstPayment')->nullable();
            $table->decimal('Deposit', 19, 4)->default('0.0000')->nullable();
            $table->decimal('TenancyFee', 19, 4)->default('0.0000')->nullable();
            $table->decimal('TenancyRenewal', 19, 4)->default('0.0000')->nullable();
            $table->timestamps();
            $table->softDeletes();           
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
