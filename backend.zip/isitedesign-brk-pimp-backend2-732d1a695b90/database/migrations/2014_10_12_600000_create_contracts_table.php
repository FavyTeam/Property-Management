<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateContractsTable extends Migration
{
    const TABLE = 'contracts';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('cont_ref')->nullable();
            $table->string('tent_ref')->nullable();
            $table->string('prop_ref')->nullable();
            $table->dateTime('term_from')->nullable();
            $table->dateTime('term_to')->nullable();
            $table->dateTime('drawn_up')->nullable();
            $table->double('deposit')->nullable();
            $table->double('rent_per')->nullable();
            $table->double('comm_rate')->nullable();
            $table->dateTime('tdue_date')->nullable();
            $table->dateTime('ldue_date')->nullable();
            $table->double('tnt_credit')->nullable();
            $table->dateTime('tnt_pd_to')->nullable();
            $table->double('tnt_sundry')->nullable();
            $table->double('lrd_credit')->nullable();
            $table->dateTime('lrd_pd_to')->nullable();
            $table->double('lrd_sundry')->nullable();
            $table->string('terminated')->nullable();
            $table->string('checksum')->nullable();
            $table->double('tent_each')->nullable();
            $table->string('tent_time')->nullable();
            $table->double('lord_each')->nullable();
            $table->string('lord_time')->nullable();
            $table->string('cstt_date')->nullable();
            $table->string('pay_lord')->nullable();
            $table->tinyInteger('app_joint')->length(1)->nullable();
            $table->tinyInteger('tstt_done')->length(1)->nullable();
            $table->tinyInteger('means_cost')->length(1)->nullable();
            $table->dateTime('tdue_from')->nullable();
            $table->double('rent_in')->nullable();
            $table->double('rent_out')->nullable();
            $table->tinyInteger('lr_done')->length(1)->nullable();
            $table->double('lr_due')->nullable();
            $table->dateTime('tdue_to')->nullable();
            $table->double('uncleared')->nullable();
            $table->double('dep_held')->nullable();
            $table->double('dep_out')->nullable();
            $table->double('hbtotal')->nullable();
            $table->double('hbamount')->nullable();
            $table->double('hbrentper')->nullable();
            $table->tinyInteger('hbnotional')->length(1)->nullable();
            $table->string('reviewdate')->nullable();
            $table->tinyInteger('renttoll')->nullable();
            $table->string('sch_to')->nullable();
            $table->tinyInteger('meanspayll')->length(1)->nullable();
            $table->string('rpinext')->nullable();
            $table->string('notice')->nullable();
            $table->dateTime('rnw_start')->nullable();
            $table->double('rnwlrdstat')->nullable();
            $table->double('rnwtntstat')->nullable();
            $table->double('arrdelay')->nullable();
            $table->tinyInteger('paydefault')->length(1)->nullable();
            $table->double('paywhen')->nullable();
            $table->double('payarrears')->nullable();
            $table->double('payarredep')->nullable();
            $table->double('payoverpd')->nullable();
            $table->tinyInteger('periodic')->length(1)->nullable();
            $table->double('termstatus')->nullable();
            $table->dateTime('agreefrom')->nullable();
            $table->tinyInteger('future')->length(1)->nullable();
            $table->tinyInteger('provisiona')->length(1)->nullable();
            $table->string('noticeexp')->nullable();
            $table->double('start_due')->nullable();
            $table->double('full_due')->nullable();
            $table->double('end_due')->nullable();
            $table->double('end_days')->nullable();
            $table->string('arrfreq')->nullable();
            $table->tinyInteger('arrhbdates')->nullable();
            $table->double('paymin')->nullable();
            $table->tinyInteger('payonly')->nullable();
            $table->string('payonhold')->nullable();
            $table->double('paydays')->nullable();
            $table->double('contrarent')->nullable();
            $table->string('firststat')->nullable();
            $table->double('paymthday')->nullable();
            $table->double('initrents')->nullable();
            $table->tinyInteger('guaranteed')->length(1)->nullable();
            $table->tinyInteger('nohbstart')->length(1)->nullable();
            $table->string('mainoffice')->nullable();
            $table->string('updoffices')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
