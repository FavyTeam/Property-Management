<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateRentLettersTable extends Migration
{
    const TABLE = 'rentletters';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('Propref', 10)->nullable();
            $table->string('Letter', 50)->nullable();
            $table->dateTime('Date')->nullable();
            $table->timestamps();
            $table->softDeletes();           
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
