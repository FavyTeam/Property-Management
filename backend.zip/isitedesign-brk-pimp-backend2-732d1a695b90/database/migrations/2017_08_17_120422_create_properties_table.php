<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreatePropertiesTable extends Migration
{
    const TABLE = 'properties';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table)
        {
            $table->increments('id');
            $table->string('lord_ref', 20)->nullable();
            $table->string('prop_ref', 20)->nullable();
            $table->string('cont_ref', 20)->nullable();
            $table->string('tent_ref', 20)->nullable();
            $table->string('addr_1', 100)->nullable();
            $table->string('addr_2', 100)->nullable();
            $table->string('addr_3', 100)->nullable();
            $table->string('addr_4', 100)->nullable();
            $table->string('postcode', 20)->nullable();
            $table->string('telephone', 20)->nullable();
            $table->string('house_type', 20)->nullable();
            $table->string('key_no', 20)->nullable();
            $table->text('features')->nullable();
            $table->dateTime('insp_date')->nullable();
            $table->dateTime('insp_time')->nullable();
            $table->float('rent_per', 10, 0)->nullable();
            $table->string('guaranteed')->nullable();
            $table->float('comm_rate', 10, 0)->nullable();
            $table->string('pay_method', 10)->nullable();
            $table->dateTime('avail_to')->nullable();
            $table->string('addr_srch', 20)->nullable();
            $table->text('checksum')->nullable();
            $table->string('documents', 5)->nullable();
            $table->float('tent_each', 10, 0)->nullable();
            $table->string('tent_time', 20)->nullable();
            $table->string('group', 20)->nullable();
            $table->string('group_ref', 20)->nullable();
            $table->float('lord_each', 10, 0)->nullable();
            $table->string('lord_time', 20)->nullable();
            $table->float('apportion', 10, 0)->nullable();
            $table->string('cl_start', 20)->nullable();
            $table->string('cl_end', 20)->nullable();
            $table->string('ins_status', 20)->nullable();
            $table->string('acct_ref', 20)->nullable();
            $table->string('srvcgas', 20)->nullable();
            $table->string('srvcelec', 20)->nullable();
            $table->string('srvcwater', 20)->nullable();
            $table->string('srvcctax', 20)->nullable();
            $table->string('srvcmgmt', 20)->nullable();
            $table->string('srvchb', 20)->nullable();
            $table->dateTime('nextfree')->nullable();
            $table->string('provistent', 20)->nullable();
            $table->dateTime('gas_done')->nullable();
            $table->string('gas_by', 10)->nullable();
            $table->dateTime('gas_next')->nullable();
            $table->boolean('gas_none')->nullable();
            $table->boolean('gas_lrdorg')->nullable();
            $table->string('propstatus', 10)->nullable();
            $table->boolean('deptolord')->nullable();
            $table->string('taxband', 10)->nullable();
            $table->string('keyheldby', 5)->nullable();
            $table->string('keyrcvd', 20)->nullable();
            $table->string('keyreturn', 20)->nullable();
            $table->string('boardtype', 5)->nullable();
            $table->string('boardsup', 10)->nullable();
            $table->string('boardsdown', 10)->nullable();
            $table->string('srvcinsure', 10)->nullable();
            $table->boolean('insrpi')->nullable();
            $table->boolean('insbuild')->nullable();
            $table->boolean('inscontent')->nullable();
            $table->float('rpicharge', 10, 0)->nullable();
            $table->float('rpicost', 10, 0)->nullable();
            $table->string('rpiupto', 20)->nullable();
            $table->string('azregion', 10)->nullable();
            $table->float('azpageno', 10, 0)->nullable();
            $table->string('azgridref', 10)->nullable();
            $table->dateTime('created')->nullable();
            $table->dateTime('insp_last')->nullable();
            $table->dateTime('gc_start')->nullable();
            $table->dateTime('gas_appt')->nullable();
            $table->dateTime('gas_time')->nullable();
            $table->float('gc_status', 10, 0)->nullable();
            $table->string('hse_descr', 100)->nullable();
            $table->string('hse_type', 30)->nullable();
            $table->string('blr_by', 10)->nullable();
            $table->string('blr_next', 10)->nullable();
            $table->dateTime('blr_time')->nullable();
            $table->boolean('blr_none')->nullable();
            $table->boolean('blr_lrdorg')->nullable();
            $table->string('blr_done', 10)->nullable();
            $table->string('blr_appt', 10)->nullable();
            $table->dateTime('bc_start')->nullable();
            $table->float('bc_status', 10, 0)->nullable();
            $table->string('ele_by', 10)->nullable();
            $table->string('ele_next', 10)->nullable();
            $table->dateTime('ele_time')->nullable();
            $table->boolean('ele_none')->nullable();
            $table->boolean('ele_lrdorg')->nullable();
            $table->string('ele_done', 10)->nullable();
            $table->string('ele_appt', 10)->nullable();
            $table->dateTime('ec_start')->nullable();
            $table->float('ec_status', 10, 0)->nullable();
            $table->string('mgmttype', 5)->nullable();
            $table->boolean('payusegas')->nullable();
            $table->boolean('payuseele')->nullable();
            $table->float('bedrooms', 10, 0)->nullable();
            $table->float('receptions', 10, 0)->nullable();
            $table->float('furnished', 10, 0)->nullable();
            $table->float('parking', 10, 0)->nullable();
            $table->float('heating', 10, 0)->nullable();
            $table->float('garden', 10, 0)->nullable();
            $table->boolean('nopets')->nullable();
            $table->boolean('nochildren')->nullable();
            $table->boolean('nosmokers')->nullable();
            $table->boolean('nostudents')->nullable();
            $table->float('fuel', 10, 0)->nullable();
            $table->string('nextstatus', 5)->nullable();
            $table->float('inspstatus', 10, 0)->nullable();
            $table->float('mtrgas', 10, 0)->nullable();
            $table->string('mtrgasd', 10)->nullable();
            $table->float('mtrelech', 10, 0)->nullable();
            $table->string('mtrelechd', 10)->nullable();
            $table->float('mtrelecl', 10, 0)->nullable();
            $table->string('mtrelecld', 10)->nullable();
            $table->float('mtrwater', 10, 0)->nullable();
            $table->string('mtrwaterd', 10)->nullable();
            $table->boolean('inspmeters')->nullable();
            $table->boolean('inspinv')->nullable();
            $table->boolean('inspcond')->nullable();
            $table->float('insoverall', 10, 0)->nullable();
            $table->float('inspreason', 10, 0)->nullable();
            $table->float('inspevery', 10, 0)->nullable();
            $table->boolean('employed')->nullable();
            $table->string('area', 30)->nullable();
            $table->string('viddate', 10)->nullable();
            $table->float('vidtape', 10, 0)->nullable();
            $table->string('vidindex', 10)->nullable();
            $table->string('vidprev', 10)->nullable();
            $table->boolean('approxfree')->nullable();
            $table->string('webref', 20)->nullable();
            $table->boolean('lloccupied')->nullable();
            $table->boolean('indivrooms')->nullable();
            $table->float('roomslet', 10, 0)->nullable();
            $table->string('srvcsewage', 10)->nullable();
            $table->dateTime('ptddate')->nullable();
            $table->float('ptdamount', 10, 0)->nullable();
            $table->boolean('jointequal')->nullable();
            $table->float('refurbstat', 10, 0)->nullable();
            $table->string('inspgroup', 10)->nullable();
            $table->float('acctgroup', 10, 0)->nullable();
            $table->float('mtrreason', 10, 0)->nullable();
            $table->boolean('vidnone')->nullable();
            $table->boolean('gasboiler')->nullable();
            $table->boolean('gasstove')->nullable();
            $table->boolean('gasfires')->nullable();
            $table->boolean('gaspipes')->nullable();
            $table->boolean('gasflues')->nullable();
            $table->string('mainoffice', 20)->nullable();
            $table->string('updoffices', 20)->nullable();
            $table->float('mtrwater2', 10, 0)->nullable();
            $table->string('mtrwater2d', 10)->nullable();
            $table->float('mtrelec3', 10, 0)->nullable();
            $table->string('mtrelec3d', 10)->nullable();
            $table->string('webstatus', 10)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}