<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateMaintengineersTable extends Migration
{
    const TABLE = 'maintengineers';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('Maintidno')->unsigned()->nullable()->default(0);
            $table->string('MaintName', 50)->nullable();
            $table->string('MaintTitle', 10)->nullable();
            $table->string('MaintForename', 50)->nullable();
            $table->string('MaintSurname', 50)->nullable();
            $table->string('MaintAdd1', 50)->nullable();
            $table->string('MaintAdd2', 50)->nullable();
            $table->string('MaintAdd3', 50)->nullable();
            $table->string('MaintAdd4', 50)->nullable();
            $table->string('MainPostcode', 50)->nullable()->index('MainPostcode');
            $table->string('MainTelno', 50)->nullable();
            $table->string('MaintFaxno', 50)->nullable()->default('0');
            $table->string('MaintOthertel', 50)->nullable();
            $table->string('MaintGSI', 50)->nullable();
            $table->string('MaintContact', 50)->nullable();
            $table->string('MaintDescription', 50)->nullable();
            $table->text('SpecialComments')->nullable();
            $table->boolean('NotUsed')->nullable();
            $table->boolean('SendLetter')->nullable();
            $table->boolean('Blocked')->nullable();
            $table->integer('BlockedBy')->unsigned()->nullable();
            $table->dateTime('BlockedDate')->nullable();
            $table->text('Reason')->nullable();
            $table->dateTime('BlockedExpiry')->nullable();
            $table->integer('BlockLimit')->unsigned()->nullable();
            $table->dateTime('PLIStart')->nullable();
            $table->dateTime('PLIEnd')->nullable();
            $table->text('PLINotes')->nullable();
            $table->boolean('Emailcontact')->nullable();
            $table->boolean('GSI')->nullable();
            $table->boolean('Invisible')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
