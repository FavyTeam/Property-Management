<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDiaryTable extends Migration
{

    const TABLE = 'diary';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('DiaryIdNo')->unsigned()->nullable();
            $table->boolean('Lock')->nullable();
            $table->integer('BookedBy')->unsigned()->nullable();
            $table->dateTime('BookedDate')->nullable();
            $table->dateTime('BookedTime')->nullable();
            $table->dateTime('Date')->nullable();
            $table->dateTime('Time')->nullable();
            $table->integer('Type')->unsigned()->nullable();
            $table->boolean('Timed')->nullable();
            $table->integer('For')->unsigned()->nullable();
            $table->string('PropRef', 50)->nullable();
            $table->string('Name', 50)->nullable();
            $table->integer('Prospect')->unsigned()->nullable();
            $table->integer('PLAN')->unsigned()->nullable();
            $table->integer('Planproperty')->unsigned()->nullable();
            $table->string('Address', 50)->nullable();
            $table->longText('Details')->nullable();
            $table->integer('Conf1By')->unsigned()->nullable();
            $table->dateTime('Conf1Date')->nullable();
            $table->dateTime('Conf1Time')->nullable();
            $table->longText('Conf1Notes')->nullable();
            $table->integer('Conf2By')->unsigned()->nullable();
            $table->dateTime('Conf2Date')->nullable();
            $table->dateTime('Conf2Time')->nullable();
            $table->longText('Conf2Notes')->nullable();
            $table->longText('Area')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
