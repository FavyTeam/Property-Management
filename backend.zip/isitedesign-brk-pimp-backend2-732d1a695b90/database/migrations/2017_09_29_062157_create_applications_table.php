<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateApplicationsTable extends Migration
{
    const TABLE = 'applications';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('Lock')->unsigned()->nullable()->default(0)->index('Lock');
            $table->integer('Allocatedto')->unsigned()->nullable()->default(30)->index('Allocatedto');
            $table->integer('ProspectIdNo')->unsigned()->nullable()->default(0)->index('ProspectIdNo');
            $table->integer('Source')->unsigned()->nullable()->default(0);
            $table->string('Type', 50)->nullable()->index('Type');
            $table->integer('Contract')->unsigned()->nullable()->default(0)->index('Contract');
            $table->boolean('LLOS')->nullable();
            $table->dateTime('LLOSdate')->nullable();
            $table->integer('LLOSBy')->unsigned()->nullable()->default(0);
            $table->boolean('Finished')->nullable()->index('Finished');
            $table->integer('Finishedby')->unsigned()->nullable()->default(0);
            $table->dateTime('Finisheddate')->nullable();
            $table->dateTime('DateTaken')->nullable();
            $table->integer('credits')->unsigned()->nullable()->default(0);
            $table->integer('Takenby')->unsigned()->nullable()->default(0);
            $table->boolean('Improvements')->nullable()->default(1);
            $table->text('Improvementsnotes')->nullable();
            $table->boolean('ImprovementsSorted')->nullable();
            $table->text('VINotes')->nullable();
            $table->boolean('LLInformed')->nullable()->index('LLInformed');
            $table->dateTime('LLInformedDate')->nullable();
            $table->integer('LLInformedBy')->unsigned()->nullable()->default(0);
            $table->text('LLInformedNotes')->nullable();
            $table->string('PropertyRef', 15)->nullable()->index('PropertyRef');
            $table->integer('PropertyStatus')->unsigned()->nullable()->default(0);
            $table->boolean('PropertyCheckRequired')->nullable();
            $table->dateTime('PropertyCheckDate')->nullable();
            $table->integer('PropertyCheckBy')->unsigned()->nullable()->default(30);
            $table->boolean('PropertyCheckOkay')->nullable();
            $table->decimal('Rent', 19, 4)->nullable()->default(0.0000);
            $table->decimal('Deposit', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->decimal('Fee', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->text('MoniesNotes')->nullable();
            $table->dateTime('Vacationdate')->nullable();
            $table->text('VacationNotes')->nullable();
            $table->dateTime('Movedate')->nullable()->index('Movedate');
            $table->text('MovedateNotes')->nullable();
            $table->boolean('Gascoverchecked')->nullable();
            $table->integer('Gascovercheckedby')->unsigned()->nullable()->default(0);
            $table->dateTime('Gascovercheckeddate')->nullable();
            $table->integer('GSIRequired')->unsigned()->nullable()->default(3);
            $table->text('GSINotes')->nullable();
            $table->boolean('GSIComplete')->nullable();
            $table->dateTime('GSICompleteDate')->nullable();
            $table->integer('GSICompleteBy')->unsigned()->nullable()->default(0);
            $table->integer('HIRequired')->unsigned()->nullable()->default(1)->index('HIRequired');
            $table->dateTime('HIScheduledDate')->nullable();
            $table->dateTime('HIScheduledTime')->nullable();
            $table->integer('HISCheduledForWho')->unsigned()->nullable()->default(0);
            $table->boolean('HIComplete')->nullable();
            $table->boolean('HISatisfactory')->nullable();
            $table->text('HINotes')->nullable();
            $table->boolean('MAReceived')->nullable();
            $table->boolean('MANotRequired')->nullable();
            $table->dateTime('MAReceivedDate')->nullable();
            $table->integer('MAReceivedBy')->unsigned()->nullable()->default(0);
            $table->text('MAReceivedNoted')->nullable();
            $table->integer('VIRequired')->unsigned()->nullable()->default(1);
            $table->dateTime('VIDate')->nullable()->index('VIDate');
            $table->boolean('VIComplete')->nullable()->index('VIComplete');
            $table->boolean('VIFileschecked')->nullable();
            $table->integer('VIFilescheckedby')->unsigned()->nullable()->default(30);
            $table->dateTime('VIFilescheckeddate')->nullable();
            $table->boolean('KeysReady')->nullable();
            $table->text('KeysNotes')->nullable();
            $table->dateTime('BookedInDate')->nullable();
            $table->dateTime('BookedInTime')->nullable();
            $table->boolean('ContractsSigned')->nullable();
            $table->integer('KeySheetOriginal')->unsigned()->nullable()->default(0)->index('KeySheetOriginal');
            $table->integer('KeySheetTenant')->unsigned()->nullable()->default(0)->index('KeySheetTenant');
            $table->text('KeySheetNotes')->nullable();
            $table->boolean('MaintOs')->nullable()->index('MaintOs');
            $table->text('MaintOSNotes')->nullable();
            $table->text('Scratchmemo')->nullable();
            $table->dateTime('TAcceptanceLetter')->nullable();
            $table->dateTime('TOfferLetter')->nullable();
            $table->dateTime('LLLetter1')->nullable();
            $table->dateTime('LLLetter2')->nullable();
            $table->string('SO1BankName', 50)->nullable();
            $table->string('SO1BankAddress1', 50)->nullable();
            $table->string('SO1BankAddress2', 50)->nullable();
            $table->string('SO1BankAddress3', 50)->nullable();
            $table->string('SO1BankAddress4', 50)->nullable();
            $table->string('SO1BankPostCode', 50)->nullable()->index('SO1BankPostCode');
            $table->string('SO1BankAccountName', 50)->nullable();
            $table->string('SO1BankWorkNo', 50)->nullable();
            $table->string('SO1BankHomeNo', 50)->nullable();
            $table->string('SO1SortCode', 50)->nullable()->index('SO1SortCode');
            $table->string('SO1AccountNumber', 50)->nullable();
            $table->decimal('SO1Amount', 19, 4)->unsigned()->nullable();
            $table->string('SO1AmountWords', 100)->nullable();
            $table->string('SO1Reference', 50)->nullable();
            $table->decimal('SO1FirstPayment', 19, 4)->unsigned()->nullable();
            $table->decimal('SO1NormalPayment', 19, 4)->unsigned()->nullable();
            $table->string('SO1PayDay', 50)->nullable();
            $table->string('SO1Frequency', 50)->nullable();
            $table->dateTime('SO1Commencing')->nullable();
            $table->string('SO2BankName', 50)->nullable();
            $table->string('SO2BankAddress1', 50)->nullable();
            $table->string('SO2BankAddress2', 50)->nullable();
            $table->string('SO2BankAddress3', 50)->nullable();
            $table->string('SO2BankAddress4', 50)->nullable();
            $table->string('SO2BankPostCode', 50)->nullable()->index('SO2BankPostCode');
            $table->string('SO2BankAccountName', 50)->nullable();
            $table->string('SO2BankWorkNo', 50)->nullable();
            $table->string('SO2BankHomeNo', 50)->nullable();
            $table->string('SO2SortCode', 50)->nullable()->index('SO2SortCode');
            $table->string('SO2AccountNumber', 50)->nullable();
            $table->decimal('SO2Amount', 19, 4)->unsigned()->nullable();
            $table->string('SO2AmountWords', 100)->nullable();
            $table->string('SO2Reference', 50)->nullable();
            $table->decimal('SO2FirstPayment', 19, 4)->unsigned()->nullable();
            $table->decimal('SO2NormalPayment', 19, 4)->unsigned()->nullable();
            $table->string('SO2PayDay', 50)->nullable();
            $table->string('SO2Frequency', 50)->nullable();
            $table->dateTime('SO2Commencing')->nullable();
            $table->boolean('EPC')->nullable();
            $table->integer('EPCBy')->unsigned()->nullable()->default(0);
            $table->dateTime('EPCDate')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
