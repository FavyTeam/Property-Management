<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePttodayTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pttoday', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('ProspectIdNo')->unsigned()->nullable();
            $table->string('event')->nullable();
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('pttoday');
    }

}
