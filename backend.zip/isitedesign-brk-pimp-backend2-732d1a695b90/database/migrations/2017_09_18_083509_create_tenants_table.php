<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateTenantsTable extends Migration
{
    const TABLE = 'tenants';

	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table) {
		    $table->increments('id');
			$table->integer('Lock')->nullable()->default(0)->index('Lock');
			$table->string('tent_ref', 10)->nullable()->unique('tent_ref');
			$table->integer('applicationid')->unsigned()->nullable()->default(0)->index('applicationid');
			$table->text('Notes')->nullable();
			$table->integer('cont_ref')->unsigned()->nullable()->default(0)->index('cont_ref');
			$table->string('prop_ref', 10)->nullable()->index('prop_ref');
			$table->string('title', 30)->nullable();
			$table->string('forename', 50)->nullable();
			$table->string('initials', 50)->nullable();
			$table->string('surname', 50)->nullable();
			$table->string('addr_1', 60)->nullable();
			$table->string('addr_2', 60)->nullable();
			$table->string('addr_3', 60)->nullable();
			$table->string('addr_4', 60)->nullable();
			$table->string('postcode', 30)->nullable()->index('postcode');
			$table->string('tel_home', 60)->nullable();
			$table->string('tel_work', 60)->nullable();
			$table->text('tel_workdesc')->nullable();
			$table->text('mobiledesc')->nullable();
			$table->text('tel_1desc')->nullable();
			$table->string('tel_2', 50)->nullable();
			$table->string('tel_2desc', 50)->nullable();
			$table->string('tel_3', 50)->nullable();
			$table->string('tel_3desc', 50)->nullable();
			$table->string('tel_4', 50)->nullable();
			$table->text('tel4_desc')->nullable();
			$table->integer('Source')->unsigned()->nullable()->default(0);
			$table->boolean('joint')->nullable();
			$table->string('guar_name', 60)->nullable();
			$table->string('guar_addr1', 60)->nullable();
			$table->string('guar_addr2', 60)->nullable();
			$table->string('guar_addr3', 60)->nullable();
			$table->string('guar_pcode', 60)->nullable()->index('guar_pcode');
			$table->string('tel_1', 60)->nullable();
			$table->string('mobile', 60)->nullable();
			$table->string('email')->nullable()->index('email');
			$table->integer('Nationality')->unsigned()->nullable()->default(1);
			$table->string('Gu1Title', 50)->nullable();
			$table->string('Gu1Forename', 50)->nullable();
			$table->string('GU1Surname', 50)->nullable();
			$table->string('Gu1Addr1', 50)->nullable();
			$table->string('GU1Addr2', 50)->nullable();
			$table->string('Gu1Addr3', 50)->nullable();
			$table->string('GU1Addr4', 50)->nullable();
			$table->string('GU1Postcode', 50)->nullable()->index('GU1Postcode');
			$table->string('GU1HomePhone', 50)->nullable();
			$table->string('GU1WorkPhone', 50)->nullable();
			$table->string('GU1Mobile', 50)->nullable();
			$table->string('Gu2Title', 50)->nullable();
			$table->string('Gu2Forename', 50)->nullable();
			$table->string('GU2Surname', 50)->nullable();
			$table->string('Gu2Addr1', 50)->nullable();
			$table->string('GU2Addr2', 50)->nullable();
			$table->string('Gu2Addr3', 50)->nullable();
			$table->string('GU2Addr4', 50)->nullable();
			$table->string('GU2Postcode', 50)->nullable()->index('GU2Postcode');
			$table->string('GU2HomePhone', 50)->nullable();
			$table->string('GU2WorkPhone', 50)->nullable();
			$table->string('GU2Mobile', 50)->nullable();
			$table->boolean('NOPT')->nullable();
			$table->integer('NOPTBy')->unsigned()->nullable()->default(0);
			$table->dateTime('NOPTByDate')->nullable();
			$table->text('NOPTNotes')->nullable();
			$table->integer('TextOk')->unsigned()->nullable()->default(0)->index('TextOk');
			$table->integer('TextOKBy')->unsigned()->nullable()->default(0);
			$table->dateTime('TextOKDate')->nullable();
			$table->text('TextOKComments')->nullable();
			$table->integer('EmailOk')->unsigned()->nullable()->default(1)->index('EmailOk');
			$table->integer('EmailOKBy')->unsigned()->nullable()->default(0);
			$table->dateTime('EmailOKDate')->nullable();
			$table->text('EmailOKComments')->nullable();
			$table->boolean('Unsubscribe')->nullable();
			$table->dateTime('Lastemail')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}
}
