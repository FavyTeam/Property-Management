<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateInvoicestenantTable extends Migration
{
    const TABLE = 'invoicestenant';

	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table) {
		    $table->increments('id');
			$table->integer('InvoiceIdNo')->unsigned()->nullable()->default(0);
			$table->dateTime('Date')->nullable()->index('Date');
			$table->string('TentRef', 15)->nullable()->index('TentRef');
			$table->string('PropRef', 15)->nullable()->index('PropRef');
			$table->string('Firstname', 50)->nullable();
			$table->string('Surname', 50)->nullable();
			$table->string('Addr1', 50)->nullable();
			$table->string('Addr2', 50)->nullable();
			$table->string('Addr3', 50)->nullable();
			$table->string('Addr4', 50)->nullable();
			$table->string('PostCode', 20)->nullable()->index('PostCode');
			$table->text('Invline')->nullable();
			$table->decimal('Net', 19, 4)->nullable()->default(0.0000);
			$table->decimal('VAT', 19, 4)->nullable()->default(0.0000);
			$table->decimal('Total', 19, 4)->nullable()->default(0.0000);
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}
}
