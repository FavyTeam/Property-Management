<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateUpgradesTable extends Migration
{
    const TABLE = 'upgrades';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('Propertyref', 10)->nullable();
            $table->dateTime('DateAdded')->nullable();
            $table->integer('Addedby')->unsigned()->nullable();
            $table->integer('Status')->unsigned()->nullable();
            $table->text('Notes')->nullable();
            $table->dateTime('Nextactiondate')->nullable();
            $table->integer('Nextactionby')->unsigned()->nullable();
            $table->text('NextAction')->nullable();
            $table->boolean('Closed')->nullable();
            $table->boolean('Lock')->default(0)->nullable();
            $table->boolean('LLAware')->default(0)->nullable();
            $table->integer('LLAwareby')->unsigned()->nullable();
            $table->dateTime('LLAwareDate')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
