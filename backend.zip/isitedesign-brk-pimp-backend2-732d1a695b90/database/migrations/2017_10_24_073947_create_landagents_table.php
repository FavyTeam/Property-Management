<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateLandagentsTable extends Migration
{
    const TABLE = 'landagents';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('Propertyid')->nullable()->default(0)->index('Propertyid');
            $table->integer('Lettingagent')->nullable()->default(0);
            $table->timestamp('Daterecorded')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
