<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProspectsTable extends Migration
{

    const TABLE = 'prospects';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('ProspectIdNo')->unsigned()->nullable();
            $table->boolean('Lock')->default('0')->nullable();
            $table->boolean('Modern')->default('0')->nullable();
            $table->boolean('Refurb')->default('0')->nullable();
            $table->string('Parkingfortext', 20)->nullable();
            $table->integer('Owned')->unsigned()->nullable();
            $table->string('Type', 20)->nullable();
            $table->boolean('Missinginfo')->default('0')->nullable();
            $table->longText('Missinginfodetails')->nullable();
            $table->integer('Category')->unsigned()->nullable();
            $table->boolean('View')->default('0')->nullable();
            $table->boolean('WaitExchange')->default('0')->nullable();
            $table->boolean('Blacklist')->default('0')->nullable();
            $table->boolean('HOTBOX')->default('0')->nullable();
            $table->boolean('BestTime')->default('0')->nullable();
            $table->dateTime('BestTimeStart')->nullable();
            $table->string('BestTimeNotes', 100)->nullable();
            $table->string('Enquiredabout', 50)->nullable();
            $table->boolean('Deleted')->default('0')->nullable();
            $table->dateTime('Callback')->nullable();
            $table->string('CallbackReason', 100)->nullable();
            $table->boolean('Calltonight')->default('0')->nullable();
            $table->boolean('RAC')->default('0')->nullable();
            $table->integer('RACby')->unsigned()->nullable();
            $table->dateTime('RACDate')->nullable();
            $table->dateTime('RACTime')->nullable();
            $table->boolean('MoveNow')->default('0')->nullable();
            $table->boolean('MoveNotice')->default('0')->nullable();
            $table->boolean('Movenotice2')->default('0')->nullable();
            $table->boolean('MoveFuture')->default('0')->nullable();
            $table->boolean('MoveASAP')->default('0')->nullable();
            $table->dateTime('DateTaken')->nullable();
            $table->integer('ContactScore')->unsigned()->nullable();
            $table->dateTime('TimeTaken')->nullable();
            $table->integer('TakenBy')->unsigned()->nullable();
            $table->integer('Source')->unsigned()->nullable();
            $table->integer('Title')->unsigned()->nullable();
            $table->string('Forename', 50)->nullable();
            $table->string('LastName', 50)->nullable();
            $table->boolean('HBChecked')->default('0')->nullable();
            $table->integer('Payment')->unsigned()->nullable();
            $table->boolean('MoneyOK')->default('0')->nullable();
            $table->integer('NoAdults')->unsigned()->nullable();
            $table->integer('AgeAdu1')->unsigned()->nullable();
            $table->integer('AgeAdu2')->unsigned()->nullable();
            $table->integer('AgeAdu3')->unsigned()->nullable();
            $table->integer('AgeAdu4')->unsigned()->nullable();
            $table->integer('AgeAdu5')->unsigned()->nullable();
            $table->integer('Agerange')->unsigned()->nullable();
            $table->boolean('GuarantorOk')->default('0')->nullable();
            $table->integer('NoChildren')->unsigned()->nullable();
            $table->integer('Nationality')->unsigned()->nullable();
            $table->integer('AgeEnf1')->unsigned()->nullable();
            $table->integer('AgeEnf2')->unsigned()->nullable();
            $table->integer('AgeEnf3')->unsigned()->nullable();
            $table->integer('AgeEnf4')->unsigned()->nullable();
            $table->integer('AgeEnf5')->unsigned()->nullable();
            $table->integer('AgeEnf6')->unsigned()->nullable();
            $table->string('Address1', 50)->nullable();
            $table->string('Address2', 50)->nullable();
            $table->string('Address3', 50)->nullable();
            $table->string('Address4', 50)->nullable();
            $table->string('PostCode', 15)->nullable();
            $table->string('PhoneHome', 15)->nullable();
            $table->string('PhoneWork', 15)->nullable();
            $table->string('PhoneMobile', 15)->nullable();
            $table->string('Email', 15)->nullable();
            $table->boolean('NoEmail')->default('0')->nullable();
            $table->string('ContactDetails', 100)->nullable();
            $table->integer('CurrentStatus')->unsigned()->nullable();
            $table->dateTime('MoveDate')->nullable();
            $table->integer('MinBeds')->unsigned()->nullable();
            $table->decimal('MaxRent', 6, 2)->nullable();
            $table->boolean('Garage')->default('0')->nullable();
            $table->boolean('Driveway')->default('0')->nullable();
            $table->integer('Parkingfor')->unsigned()->nullable();
            $table->boolean('NoFlat')->default('0')->nullable();
            $table->boolean('GroundFloor')->default('0')->nullable();
            $table->boolean('Upperfloor')->default('0')->nullable();
            $table->boolean('Detached')->default('0')->nullable();
            $table->boolean('Shower')->default('0')->nullable();
            $table->boolean('Furnished')->default('0')->nullable();
            $table->boolean('Appliances')->default('0')->nullable();
            $table->boolean('NotTerrace')->default('0')->nullable();
            $table->boolean('Bungalow')->default('0')->nullable();
            $table->boolean('Garden')->default('0')->nullable();
            $table->integer('Category1')->unsigned()->nullable();
            $table->integer('Category2')->unsigned()->nullable();
            $table->boolean('Cat')->default('0')->nullable();
            $table->boolean('Dog')->default('0')->nullable();
            $table->string('Dogdetails', 100)->nullable();
            $table->boolean('Nopets')->default('0')->nullable();
            $table->boolean('Smoker')->default('0')->nullable();
            $table->boolean('SmokeOutside')->default('0')->nullable();
            $table->longText('Info')->nullable();
            $table->longText('Progress')->nullable();
            $table->dateTime('DeleteBy')->nullable();
            $table->boolean('Agechecked')->default('0')->nullable();
            $table->boolean('Firstareayes')->default('0')->nullable();
            $table->boolean('Secondareayes')->default('0')->nullable();
            $table->boolean('thirdareayes')->default('0')->nullable();
            $table->boolean('firstareano')->default('0')->nullable();
            $table->boolean('secondareano')->default('0')->nullable();
            $table->boolean('thirdareano')->default('0')->nullable();
            $table->boolean('Flat')->default('0')->nullable();
            $table->boolean('Specifics')->default('0')->nullable();
            $table->decimal('Maxrent2', 6, 2)->nullable();
            $table->boolean('Sharers')->default('0')->nullable();
            $table->boolean('2doubles')->default('0')->nullable();
            $table->dateTime('LastMsg')->nullable();
            $table->dateTime('Lastspoke')->nullable();
            $table->dateTime('LastVisitedDate')->nullable();
            $table->integer('LastVisitedBy')->unsigned()->nullable();
            $table->dateTime('LastVisitedTime')->nullable();
            $table->dateTime('LastListsent')->nullable();
            $table->boolean('Noothernumbers')->default('0')->nullable();
            $table->integer('NoothernumbersUser')->unsigned()->nullable();
            $table->dateTime('Noothernumbersdate')->nullable();
            $table->string('ExistintTenantReason', 100)->nullable();
            $table->boolean('Orbit')->default('0')->nullable();
            $table->dateTime('Appdate')->nullable();
            $table->integer('Approvalnumber')->unsigned()->nullable();
            $table->dateTime('Approvaldate')->nullable();
            $table->longText('Orbitnotes')->nullable();
            $table->boolean('Snatch')->default('0')->nullable();
            $table->integer('Snatchby')->unsigned()->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
