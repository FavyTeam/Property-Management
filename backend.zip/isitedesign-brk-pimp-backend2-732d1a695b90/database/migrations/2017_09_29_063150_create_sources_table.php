<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateSourcesTable extends Migration
{
    const TABLE = 'sources';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->string('Category', 50)->nullable();
            $table->string('Source', 50)->nullable()->index('Source');
            $table->boolean('Minimal')->nullable()->index('Minimal');
            $table->integer('SourcesCategory')->unsigned()->nullable()->default(0);
            $table->boolean('Spoke')->nullable();
            $table->boolean('PRICS')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
