<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateInvoicestemplateTable extends Migration
{
    const TABLE = 'invoicestemplate';

	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table)
		{
		    $table->increments('id');
			$table->integer('IdNo')->usngiend()->nullable()->default(0);
			$table->string('Description', 100)->nullable();
			$table->decimal('Net', 19, 4)->nullable()->default(0.0000);
			$table->decimal('VAT', 19, 4)->nullable()->default(0.0000);
			$table->decimal('Total', 19, 4)->nullable()->default(0.0000);
			$table->boolean('NotUsed')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}
}
