<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWaitlistTable extends Migration
{

    const TABLE = 'waitlist';

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
	    Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('WaitlistIdno')->unsigned()->nullable();
            $table->integer('ProspectIdNo')->unsigned()->nullable();
            $table->string('PropertyRef', 10)->nullable();
            $table->date('DateAdded')->nullable();        
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
