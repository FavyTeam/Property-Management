<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterProspectsTable extends Migration
{
    const TABLE = 'prospects';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('Email', 100)->nullable()->change();
        });
    }


    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('Email', 15)->nullable()->change();
        });
    }
}
