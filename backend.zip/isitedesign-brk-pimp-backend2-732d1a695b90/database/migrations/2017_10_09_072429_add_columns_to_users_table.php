<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AddColumnsToUsersTable extends Migration
{
    const TABLE = 'users';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('Username', 20)->nullable()->after('remember_token');
            $table->string('Initials', 5)->nullable()->after('Username');
            $table->dateTime('Ratsdate')->nullable()->after('Initials');
            $table->string('Current Status', 100)->nullable()->after('Ratsdate');
            $table->string('Ext', 25)->nullable()->after('Current Status');
            $table->integer('Activity')->unsigned()->nullable()->default(0)->after('Ext');
            $table->boolean('Loggedin')->nullable()->after('Activity');
            $table->dateTime('Lunch')->nullable()->after('Loggedin');
            $table->boolean('Out')->nullable()->after('Lunch');
            $table->integer('Inactivity')->unsigned()->nullable()->default(0)->after('Out');
            $table->integer('Security')->unsigned()->nullable()->default(0)->after('Inactivity');
            $table->boolean('Management')->nullable()->after('Security');
            $table->boolean('Prospects')->nullable()->after('Management');
            $table->boolean('Prospectsdefault')->nullable()->after('Prospects');
            $table->integer('MaximumProspects')->unsigned()->nullable()->after('Prospectsdefault');
            $table->boolean('Letterhead')->nullable()->after('MaximumProspects');
            $table->boolean('Department')->nullable()->after('Letterhead');
            $table->boolean('TenantAccount')->nullable()->after('Department');
            $table->boolean('AddProperty')->nullable()->after('TenantAccount');
            $table->boolean('Febootimail')->nullable()->after('AddProperty');
            $table->boolean('Current')->nullable()->default(1)->after('Febootimail');
            $table->boolean('RAC')->nullable()->after('Current');
            $table->boolean('Delprosp')->nullable()->after('RAC');
            $table->longText('EmailSignature')->nullable()->after('Delprosp');
            $table->boolean('Board')->nullable()->after('EmailSignature');
            $table->boolean('Updaterequired')->nullable()->after('Board');
            $table->string('Mobilenumber', 50)->nullable()->after('Updaterequired');
            $table->dateTime('Returndate')->nullable()->after('Mobilenumber');
            $table->dateTime('Returntime')->nullable()->after('Returndate');
            $table->dateTime('Receptionfrom')->nullable()->after('Returntime');
            $table->dateTime('ReceptionTo')->nullable()->after('Receptionfrom');
            $table->boolean('Janitor')->nullable()->after('ReceptionTo');
            $table->boolean('Seen')->nullable()->after('Janitor');
            $table->dateTime('ratsdatein')->nullable()->after('Seen');
            $table->dateTime('ratstimein')->nullable()->after('ratsdatein');
            $table->dateTime('ratsdateout')->nullable()->after('ratstimein');
            $table->dateTime('ratstimeout')->nullable()->after('ratsdateout');
            $table->boolean('Viewings')->nullable()->after('ratstimeout');
            $table->dateTime('Nextevening')->nullable()->after('Viewings');
            $table->boolean('Logout')->nullable()->after('Nextevening');
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->dropColumn('Username');
            $table->dropColumn('Initials');
            $table->dropColumn('Ratsdate');
            $table->dropColumn('Current Status');
            $table->dropColumn('Ext');
            $table->dropColumn('Activity');
            $table->dropColumn('Loggedin');
            $table->dropColumn('Lunch');
            $table->dropColumn('Out');
            $table->dropColumn('Inactivity');
            $table->dropColumn('Security');
            $table->dropColumn('Management');
            $table->dropColumn('Prospects');
            $table->dropColumn('Prospectsdefault');
            $table->dropColumn('MaximumProspects');
            $table->dropColumn('Letterhead');
            $table->dropColumn('Department');
            $table->dropColumn('TenantAccount');
            $table->dropColumn('AddProperty');
            $table->dropColumn('Febootimail');
            $table->dropColumn('Current');
            $table->dropColumn('RAC');
            $table->dropColumn('Delprosp');
            $table->dropColumn('EmailSignature');
            $table->dropColumn('Board');
            $table->dropColumn('Updaterequired');
            $table->dropColumn('Mobilenumber');
            $table->dropColumn('Returndate');
            $table->dropColumn('Returntime');
            $table->dropColumn('Receptionfrom');
            $table->dropColumn('ReceptionTo');
            $table->dropColumn('Janitor');
            $table->dropColumn('Seen');
            $table->dropColumn('ratsdatein');
            $table->dropColumn('ratstimein');
            $table->dropColumn('ratsdateout');
            $table->dropColumn('ratstimeout');
            $table->dropColumn('Viewings');
            $table->dropColumn('Nextevening');
            $table->dropColumn('Logout');
        });
    }
}
