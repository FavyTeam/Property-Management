<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePhotosrequiredTable extends Migration
{
    const TABLE = 'photosrequired';

	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table) {
		    $table->increments('id');
			$table->string('PropertyRef', 10);
			$table->dateTime('DateRequested')->nullable();
			$table->integer('RequestedBy')->unsigned()->nullable()->default(0);
			$table->text('Details', 100)->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}

}
