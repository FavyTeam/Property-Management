<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAppointmentsTable extends Migration
{
    const TABLE = 'appointments';

	public function up()
	{
	    if (Schema::hasTable(self::TABLE)) return;

		Schema::create(self::TABLE, function(Blueprint $table) {
			$table->increments('id');
			$table->integer('Lock')->nullable()->default(0);
			$table->dateTime('DateAdded')->nullable()->index('DateAdded');
			$table->dateTime('TimeAdded')->nullable();
			$table->integer('Whobooked')->nullable()->default(0)->index('Whobooked');
			$table->integer('AppSource')->nullable()->default(0);
			$table->integer('WhoDoing')->nullable()->default(0)->index('WhoDoing');
			$table->dateTime('Date')->nullable()->index('Date');
			$table->dateTime('Time')->nullable()->index('Time');
			$table->dateTime('TimeOrig')->nullable();
			$table->string('PropRef', 10)->nullable()->index('PropRef');
			$table->integer('ProspectId')->nullable()->default(0)->index('ProspectId');
			$table->text('AppNotes')->nullable();
			$table->boolean('RTC')->nullable();
			$table->boolean('ConfirmOcc')->nullable()->index('ConfirmOcc');
			$table->text('ConfirmOccNotes')->nullable();
			$table->boolean('ConfirmedOcc')->nullable()->index('ConfirmedOcc');
			$table->integer('Whoconf')->nullable()->default(0);
			$table->text('Confnotes')->nullable();
			$table->boolean('Showed')->nullable();
			$table->string('Showedup', 15)->nullable()->index('Showedup');
			$table->boolean('Interested')->nullable();
			$table->text('TenantFeedback')->nullable();
			$table->text('BrookdaleFeedback')->nullable();
			$table->string('ScriptChecked', 50)->nullable();
			$table->integer('ScriptCheckedBy')->nullable()->default(0);
			$table->integer('PropertyMatch')->nullable()->default(3);
			$table->integer('AreaMatch')->nullable()->default(3);
			$table->integer('TimeMatch')->nullable()->default(3);
			$table->boolean('Emailed')->nullable()->index('Emailed');
			$table->boolean('Text')->nullable()->index('Text');
			$table->boolean('Checked')->nullable()->index('Checked');
			$table->integer('Checkedby')->nullable()->default(0);
			$table->text('CheckedNotes')->nullable();
			$table->boolean('Feedbackchecked')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}

}
