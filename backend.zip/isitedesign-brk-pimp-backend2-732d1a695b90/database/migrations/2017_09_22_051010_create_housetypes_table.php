<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateHousetypesTable extends Migration
{
    const TABLE = 'housetypes';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->string('HouseType', 50)->nullable();
            $table->integer('WebId')->unsigned()->nullable()->default(0)->index('WebId');
            $table->integer('RightmoveId')->unsigned()->nullable()->default(0)->index('RightmoveId');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
