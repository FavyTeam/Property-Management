<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAreagroupspttempTable extends Migration
{
    const TABLE = 'areagroupspttemp';

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
	Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('AreaGroupNo')->unsigned()->nullable();
            $table->string('AreaGroupName', 100);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
