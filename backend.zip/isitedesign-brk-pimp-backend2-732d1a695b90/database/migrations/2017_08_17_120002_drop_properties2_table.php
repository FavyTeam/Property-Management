<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class DropProperties2Table extends Migration
{
    const TABLE = 'properties2';

    public function up()
    {
        Schema::dropIfExists(self::TABLE);
    }

    public function down()
    {

    }
}
