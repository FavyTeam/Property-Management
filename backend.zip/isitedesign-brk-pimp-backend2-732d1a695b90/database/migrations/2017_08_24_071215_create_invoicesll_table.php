<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateInvoicesllTable extends Migration
{
    const TABLE = 'invoicesll';

	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table) {
		    $table->increments('id');
			$table->integer('InvoiceIdNo')->unsigned()->nullable()->default(0)->unique('InvoiceIdNo');
			$table->integer('Lock')->unsigned()->nullable()->default(0);
			$table->dateTime('Date')->nullable();
			$table->string('LordRef', 15)->nullable()->index('LordRef');
			$table->string('PropRef', 15)->nullable()->index('PropRef');
			$table->integer('JobNo')->unsigned()->nullable()->default(0)->index('JobNo');
			$table->text('Internalcomments')->nullable();
			$table->string('Firstname', 50)->nullable();
			$table->string('Surname', 50)->nullable();
			$table->string('Addr1', 50)->nullable();
			$table->string('Addr2', 50)->nullable();
			$table->string('Addr3', 50)->nullable();
			$table->string('Addr4', 50)->nullable();
			$table->string('PostCode', 20)->nullable()->index('PostCode');
			$table->string('SuppInvNo', 20)->nullable();
			$table->text('Invline')->nullable();
			$table->decimal('Net', 19, 4)->nullable()->default(0.0000);
			$table->decimal('VAT', 19, 4)->nullable()->default(0.0000);
			$table->decimal('Total', 19, 4)->nullable()->default(0.0000);
			$table->decimal('OurNet', 19, 4)->nullable()->default(0.0000);
			$table->decimal('OurVAT', 19, 4)->nullable()->default(0.0000);
			$table->decimal('OurTotal', 19, 4)->nullable()->default(0.0000);
			$table->boolean('AccountsUpdated')->nullable();
			$table->boolean('Check')->nullable();
			$table->timestamps();
			$table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}
}
