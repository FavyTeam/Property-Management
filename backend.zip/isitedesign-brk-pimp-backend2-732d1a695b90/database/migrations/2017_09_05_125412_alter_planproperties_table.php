<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AlterPlanpropertiesTable extends Migration
{
    const TABLE = 'planproperties';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('PropertyType', 50)->nullable()->default(null)->change();
            $table->integer('Foundby')->unsigned()->nullable()->default(null)->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('PropertyType')->unsigned()->nullable()->default(0)->change();
            $table->integer('Foundby')->unsigned()->nullable()->default(30)->change();
        });

    }
}
