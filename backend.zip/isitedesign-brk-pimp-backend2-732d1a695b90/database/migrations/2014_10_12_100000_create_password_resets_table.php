<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreatePasswordResetsTable extends Migration
{
    const TABLE = 'password_resets';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->string('email')->index();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }

}
