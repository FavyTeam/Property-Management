<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterAppointmentsTable extends Migration
{
    const TABLE = 'appointments';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->string('AppSource', 25)->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('AppSource')->nullable()->default(0)->change();
        });
    }
}
