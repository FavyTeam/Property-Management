<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AddPropIdToPropertiesTable extends Migration
{
    const TABLE = 'properties';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('prop_id')->unsigned()->nullable()->after('id');
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->dropColumn('prop_id');
        });
    }
}