<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateContractDetailsTable extends Migration
{
    const TABLE = 'contractdetails';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->string('PropertyRef', 10)->nullable();
            $table->integer('Contref')->unsigned()->default('0')->nullable();
            $table->dateTime('ContractDate')->nullable();
            $table->string('Months', 10)->nullable();
            $table->dateTime('StartDate')->nullable();
            $table->dateTime('EndDate')->nullable();
            $table->decimal('Rent', 19, 4)->default('0.0000')->nullable();
            $table->integer('PayDate')->default('0')->nullable();
            $table->dateTime('FirstPayment')->nullable();
            $table->decimal('Deposit', 19, 4)->default('0.0000')->nullable();
            $table->decimal('TenancyFee', 19, 4)->default('0.0000')->nullable();
            $table->decimal('TenancyRenewal', 19, 4)->default('0.0000')->nullable();
            $table->string('PayMethod', 50)->default('0')->nullable();
            $table->tinyInteger('Active')->length(1)->default('0')->nullable();
            $table->timestamps();
            $table->softDeletes();         
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
