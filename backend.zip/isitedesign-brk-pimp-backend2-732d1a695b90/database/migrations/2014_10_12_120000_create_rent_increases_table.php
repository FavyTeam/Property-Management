<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateRentIncreasesTable extends Migration
{
    const TABLE = 'rentincreases';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->dateTime('TransactionDate')->nullable();
            $table->string('PropertyRef', 10)->nullable();
            $table->integer('Contref')->unsigned()->default('0')->nullable();
            $table->dateTime('RIDate')->nullable();
            $table->decimal('OldRent', 19, 4)->default('0.0000')->nullable();
            $table->decimal('Newrent', 19, 4)->default('0.0000')->nullable();
            $table->timestamps();
            $table->softDeletes();           
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
