<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AlterNewpropertiesTableContref extends Migration
{
    const TABLE = 'newproperties';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('Contref')->unsigned()->nullable()->default(null)->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('Contref')->unsigned()->nullable()->default(0)->change();
        });
    }
}
