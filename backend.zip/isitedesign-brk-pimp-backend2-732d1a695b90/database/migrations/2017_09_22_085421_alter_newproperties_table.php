<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class AlterNewpropertiesTable extends Migration
{
    const TABLE = 'newproperties';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('HouseType')->unsigned()->nullable()->default(20)->change();
            $table->integer('Furnished')->unsigned()->nullable()->default(1)->change();
            $table->integer('Heating')->unsigned()->nullable()->default(3)->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('HouseType')->unsigned()->nullable()->default(22)->change();
            $table->integer('Furnished')->unsigned()->nullable()->default(0)->change();
            $table->integer('Heating')->unsigned()->nullable()->default(0)->change();
        });
    }
}
