<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterNewpropertiesTableDefaults extends Migration
{
    const TABLE = 'newproperties';

    public function up()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('HouseType')->unsigned()->nullable(false)->default(20)->change();
            $table->integer('Furnished')->unsigned()->nullable(false)->default(1)->change();
            $table->integer('Heating')->unsigned()->nullable(false)->default(3)->change();
            $table->integer('Builder')->unsigned()->nullable(false)->default(1)->change();
            $table->integer('Development')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('Intcompany')->unsigned()->nullable(false)->default(5)->change();
            $table->integer('Takeonby')->unsigned()->nullable()->change();
            $table->integer('GuaranteeCommission')->unsigned()->nullable()->change();
            $table->integer('GuaranteeContractBy')->unsigned()->nullable()->change();
            $table->integer('Guaranteeblockreason')->unsigned()->nullable()->change();
            $table->integer('LLBlockreason')->unsigned()->nullable()->change();
            $table->boolean('NOEMAIL')->nullable(false)->default(1)->change();
            $table->integer('WebId')->unsigned()->nullable()->change();
            $table->integer('KLAPSDay')->unsigned()->nullable()->change();
            $table->integer('EERCurrent')->unsigned()->nullable()->change();
            $table->integer('EERPotential')->unsigned()->nullable()->change();
            $table->string('EER', 3)->nullable()->change();
            $table->integer('EIRCurrent')->unsigned()->nullable()->change();
            $table->integer('EIRPotential')->unsigned()->nullable()->change();
            $table->string('EIR', 2)->nullable()->change();
            $table->integer('DEACreatedBy')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('AgreementOnFileCheckedBy')->nullable(false)->unsigned()->default(0)->change();
            $table->integer('Owned')->unsigned()->nullable(false)->default(30)->change();
            $table->integer('Category')->unsigned()->nullable(false)->default(1)->change();
            $table->decimal('Placementfee', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->boolean('Board')->nullable(false)->default(1)->change();
            $table->string('Current', 50)->nullable()->change();
            $table->boolean('ConfirmApps')->nullable(false)->default(0)->change();
            $table->decimal('Rent', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->decimal('CreditAmount', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->integer('Autopay')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('AutopayDefault')->unsigned()->nullable(false)->default(3)->change();
            $table->integer('DeductTaxRate')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('DoubleBedrooms')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('SingleBedrooms')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('TenantType')->unsigned()->nullable(false)->default(1)->change();
            $table->integer('Appliances')->unsigned()->nullable(false)->default(0)->change();
            $table->decimal('NetCommission', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->decimal('VATCommission', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->decimal('TotalCommission', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->decimal('APFee', 19, 4)->nullable(false)->default(0.0000)->change();
            $table->boolean('MonthlyStatement')->nullable(false)->default(1)->change();
            $table->integer('ElectricMeterType')->unsigned()->nullable()->change();
            $table->integer('GasMeterType')->unsigned()->nullable()->change();
            $table->integer('ManagementCompany')->unsigned()->nullable()->change();
            $table->integer('ParkingFor')->unsigned()->nullable(false)->default(0)->change();
            $table->integer('LLSource')->unsigned()->nullable()->change();
            $table->integer('Yearbuilt')->unsigned()->nullable()->change();
            $table->integer('Yearbuilt2')->unsigned()->nullable()->change();
            $table->integer('OICName')->unsigned()->nullable()->change();
            $table->integer('Picuser')->unsigned()->nullable()->change();
            $table->integer('Propname')->unsigned()->nullable()->change();
            $table->integer('VEBy')->unsigned()->nullable()->change();
            $table->integer('Floors')->nullable(false)->default(1)->change();
            $table->integer('Floorscheckedby')->nullable()->change();
            $table->boolean('Ownerchecked')->nullable(false)->default(0)->change();
            $table->integer('Ownercheckedby')->nullable()->change();
            $table->boolean('Money')->nullable(false)->default(0)->change();
        });
    }

    public function down()
    {
        Schema::table(self::TABLE, function (Blueprint $table) {
            $table->integer('HouseType')->unsigned()->nullable()->default(20)->change();
            $table->integer('Furnished')->unsigned()->nullable()->default(1)->change();
            $table->integer('Heating')->unsigned()->nullable()->default(3)->change();
            $table->integer('Builder')->unsigned()->nullable()->default(1)->change();
            $table->integer('Development')->unsigned()->nullable()->default(1)->change();
            $table->integer('Intcompany')->unsigned()->nullable()->default(5)->change();
            $table->integer('Takeonby')->unsigned()->nullable()->default(0)->change();
            $table->integer('GuaranteeCommission')->unsigned()->nullable()->default(2)->change();
            $table->integer('GuaranteeContractBy')->unsigned()->nullable()->default(0)->change();
            $table->integer('Guaranteeblockreason')->unsigned()->nullable()->default(0)->change();
            $table->integer('LLBlockreason')->unsigned()->nullable()->default(0)->change();
            $table->boolean('NOEMAIL')->nullable()->default(0)->change();
            $table->integer('WebId')->unsigned()->nullable()->default(0)->change();
            $table->integer('KLAPSDay')->unsigned()->nullable()->default(2)->change();
            $table->integer('EERCurrent')->unsigned()->nullable()->default(0)->change();
            $table->integer('EERPotential')->unsigned()->nullable()->default(0)->change();
            $table->string('EER', 3)->nullable()->default('0')->change();
            $table->integer('EIRCurrent')->unsigned()->nullable()->default(0)->change();
            $table->integer('EIRPotential')->unsigned()->nullable()->default(0)->change();
            $table->string('EIR', 2)->nullable()->default('0')->change();
            $table->integer('DEACreatedBy')->unsigned()->nullable()->default(0)->change();
            $table->integer('AgreementOnFileCheckedBy')->unsigned()->nullable()->default(0)->change();
            $table->integer('Owned')->unsigned()->nullable()->default(30)->change();
            $table->integer('Category')->unsigned()->nullable()->default(1)->change();
            $table->decimal('Placementfee', 19, 4)->nullable()->default(0.0000)->change();
            $table->boolean('Board')->nullable()->default(1)->change();
            $table->string('Current', 50)->nullable()->default('0')->change();
            $table->boolean('ConfirmApps')->nullable()->default(0)->change();
            $table->decimal('Rent', 19, 4)->nullable()->default(0.0000)->change();
            $table->decimal('CreditAmount', 19, 4)->nullable()->default(0.0000)->change();
            $table->integer('Autopay')->unsigned()->nullable()->default(0)->change();
            $table->integer('AutopayDefault')->unsigned()->nullable()->default(3)->change();
            $table->integer('DeductTaxRate')->unsigned()->nullable()->default(0)->change();
            $table->integer('DoubleBedrooms')->unsigned()->nullable()->default(0)->change();
            $table->integer('SingleBedrooms')->unsigned()->nullable()->default(0)->change();
            $table->integer('TenantType')->unsigned()->nullable()->default(1)->change();
            $table->integer('Appliances')->unsigned()->nullable()->default(0)->change();
            $table->decimal('NetCommission', 19, 4)->nullable()->default(0.0000)->change();
            $table->decimal('VATCommission', 19, 4)->nullable()->default(0.0000)->change();
            $table->decimal('TotalCommission', 19, 4)->nullable()->default(0.0000)->change();
            $table->decimal('APFee', 19, 4)->nullable()->default(0.0000)->change();
            $table->boolean('MonthlyStatement')->nullable()->default(1)->change();
            $table->integer('ElectricMeterType')->unsigned()->nullable()->default(0)->change();
            $table->integer('GasMeterType')->unsigned()->nullable()->default(0)->change();
            $table->integer('ManagementCompany')->unsigned()->nullable()->default(0)->change();
            $table->integer('ParkingFor')->unsigned()->nullable()->default(0)->change();
            $table->integer('LLSource')->unsigned()->nullable()->default(0)->change();
            $table->integer('Yearbuilt')->unsigned()->nullable()->default(0)->change();
            $table->integer('Yearbuilt2')->unsigned()->nullable()->default(0)->change();
            $table->integer('OICName')->unsigned()->nullable()->default(0)->change();
            $table->integer('Picuser')->unsigned()->nullable()->default(0)->change();
            $table->integer('Propname')->unsigned()->nullable()->default(1)->change();
            $table->integer('VEBy')->unsigned()->nullable()->default(0)->change();
            $table->integer('Floors')->nullable()->default(0)->change();
            $table->integer('Floorscheckedby')->nullable()->default(30)->change();
            $table->boolean('Ownerchecked')->nullable()->change();
            $table->integer('Ownercheckedby')->nullable()->default(0)->change();
            $table->boolean('Money')->nullable()->change();
        });
    }
}
