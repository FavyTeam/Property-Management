<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateLandLordsTable extends Migration
{
    const TABLE = 'landlords';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('Lock')->default('0')->nullable();            
            $table->string('lord_ref')->nullable();
            $table->string('title')->nullable();
            $table->string('surname')->nullable();
            $table->string('forename')->nullable();
            $table->string('initials')->nullable();
            $table->string('addr_1')->nullable();
            $table->string('addr_2')->nullable();
            $table->string('addr_3')->nullable();
            $table->string('addr_4')->nullable();
            $table->string('postcode')->nullable();
            $table->string('tel_home')->nullable();
            $table->string('tel_work')->nullable();
            $table->longText('Notes')->nullable();
            $table->string('Source', 100)->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bank_addr1')->nullable();
            $table->string('bank_addr2')->nullable();
            $table->string('bank_addr3')->nullable();
            $table->string('bank_pcode')->nullable();
            $table->string('bank_sort')->nullable();
            $table->string('bank_accno')->nullable();
            $table->string('bank_accnt')->nullable();
            $table->string('bank_ref')->nullable();
            $table->string('checksum')->nullable();
            $table->double('tax_retain')->nullable();
            $table->double('tax_value')->nullable();
            $table->string('lstt_date')->nullable();
            $table->string('acct_ref')->nullable();
            $table->double('addtocost')->nullable();
            $table->string('addtowhat')->nullable();
            $table->tinyInteger('indiv_stat')->length(1)->nullable();
            $table->tinyInteger('ownrepairs')->length(1)->nullable();
            $table->string('fax')->nullable();
            $table->string('email')->nullable();
            $table->string('mobile')->nullable();
            $table->string('fico2', 50)->nullable();
            $table->double('clientacct')->nullable();
            $table->string('mainoffice')->nullable();
            $table->string('updoffices')->nullable();
            $table->longText('MainNotes')->nullable();
            $table->tinyInteger('overseas')->length(1)->nullable();
            $table->longText('Overseasnotes')->nullable();
            $table->string('fico', 50)->nullable();
            $table->tinyInteger('UKContact')->length(1)->nullable();
            $table->string('UKTitle', 50)->nullable();
            $table->string('UKForename', 100)->nullable();
            $table->string('UKSurname', 100)->nullable();
            $table->string('UKAddress1', 100)->nullable();
            $table->string('UKAddress2', 100)->nullable();
            $table->string('UKAddress3', 100)->nullable();
            $table->string('UKAddress4', 100)->nullable();
            $table->string('UKPostCode', 50)->nullable();
            $table->string('UKTelephone')->nullable();
            $table->tinyInteger('JointOS')->length(1)->nullable();
            $table->string('Partnername', 100)->nullable();
            $table->integer('Country')->default('0')->nullable();
            $table->longText('Dealnotes')->nullable();
            $table->string('Tel1', 50)->nullable();
            $table->string('Tel1desc')->nullable();
            $table->string('Tel2', 50)->nullable();
            $table->string('Tel2desc')->nullable();
            $table->string('Tel3', 50)->nullable();
            $table->string('Tel3desc')->nullable();
            $table->string('Tel4', 50)->nullable();
            $table->string('Tel4desc')->nullable();
            $table->string('Tel5', 50)->nullable();
            $table->string('Tel5desc')->nullable();
            $table->string('Tel6', 50)->nullable();
            $table->string('Tel6desc')->nullable();
            $table->tinyInteger('Unsubscribe')->length(1)->nullable();
            $table->longText('Emailnotes')->nullable();
            $table->dateTime('Date')->nullable();
            $table->dateTime('Time')->nullable();
            $table->integer('User')->default('30')->nullable();
            $table->dateTime('Lastemail')->nullable();
            $table->tinyInteger('IDChecked')->length(1)->nullable();
            $table->integer('IDCheckedBy')->nullable();
            $table->dateTime('IDcheckeddate')->nullable();
            $table->longText('IDCheckeddetails')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
