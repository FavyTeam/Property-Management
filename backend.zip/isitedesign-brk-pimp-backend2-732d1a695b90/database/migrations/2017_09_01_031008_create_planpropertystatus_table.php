<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreatePlanpropertystatusTable extends Migration
{
    const TABLE = 'planpropertystatus';

    public function up()
    {
        Schema::create('planpropertystatus', function(Blueprint $table) {
            $table->increments('id');
            $table->string('Status', 50)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop('planpropertystatus');
    }
}
