<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateLettingagentsTable extends Migration
{
    const TABLE = 'lettingagents';

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create(self::TABLE, function(Blueprint $table) {
			$table->increments('id');
			$table->string('CompanyName')->nullable();
			$table->integer('Title')->unsigned()->nullable()->default(0);
			$table->string('Forename', 50)->nullable();
			$table->string('Surname', 50)->nullable();
			$table->string('Address1', 50)->nullable();
			$table->string('Address2', 50)->nullable();
			$table->string('Address3', 50)->nullable();
			$table->string('Address4', 50)->nullable();
			$table->string('PostCode', 50)->nullable()->index('PostCode');
			$table->string('PhoneWork', 50)->nullable();
			$table->string('Fax', 50)->nullable();
			$table->string('PhoneMobile', 50)->nullable();
			$table->string('Email')->nullable();
			$table->decimal('Charge', 19, 4)->nullable()->default(0.0000);
            $table->timestamps();
            $table->softDeletes();
		});
	}

	public function down()
	{
		Schema::drop(self::TABLE);
	}
}
