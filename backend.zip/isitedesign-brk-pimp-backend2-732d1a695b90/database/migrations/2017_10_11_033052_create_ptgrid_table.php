<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePtgridTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ptgrid', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('ProspectId')->unsigned()->nullable();
            $table->string('Forename')->nullable();
            $table->string('Lastname')->nullable();
            $table->integer('Minbeds')->nullable();
            $table->integer('Maxrent')->nullable();
            $table->string('Propertyref')->nullable();
            $table->integer('PropertyBeds')->nullable();
            $table->integer('PropertyRent')->nullable();
            $table->integer('PropertyArea')->nullable();
            $table->boolean('Noflat')->nullable();
            $table->integer('FlatMatch')->nullable();
            $table->integer('Bedmatch')->nullable();
            $table->integer('Rentmatch')->nullable();
            $table->integer('Areamatch')->nullable();
            $table->integer('Dismissed')->nullable();
            $table->integer('Viewed')->nullable();
            $table->integer('Flysheet')->nullable();
            $table->integer('Epage')->nullable();
            $table->integer('HouseType')->nullable();
            $table->integer('PTDoubles')->nullable();
            $table->integer('HouseDoubles')->nullable();
            $table->integer('LastContact')->nullable();
            $table->string('Scratch')->nullable();
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('ptgrid');
    }

}
