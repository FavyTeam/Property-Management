<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class DropPropertiesTable extends Migration
{
    const TABLE = 'properties';

    public function up()
    {
        Schema::dropIfExists(self::TABLE);
    }

    public function down()
    {

    }
}
