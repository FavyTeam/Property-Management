<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAreagroupsTable extends Migration
{
    const TABLE = 'areagroups';

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
	Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->integer('Areagroupidno')->unsigned()->nullable();
            $table->integer('AreaGroupNo')->unsigned();
            $table->string('AreaGroupName', 100);
            $table->integer('Area')->unsigned();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
