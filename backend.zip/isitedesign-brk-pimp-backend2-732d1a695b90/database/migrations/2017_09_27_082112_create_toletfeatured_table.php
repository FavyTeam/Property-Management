<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateToletfeaturedTable extends Migration
{
    const TABLE = 'toletfeatured';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->string('PropertyRef', 10)->nullable();
            $table->string('Billing', 200)->nullable();
            $table->string('Mailto')->nullable();
            $table->string('Addr1')->nullable();
            $table->integer('Bedrooms')->unsigned()->nullable();
            $table->string('Area', 50)->nullable();
            $table->string('Location', 50)->nullable();
            $table->string('Available')->nullable();
            $table->string('Appointments', 50)->nullable();
            $table->string('Garage', 50)->nullable();
            $table->string('Heating', 50)->nullable();
            $table->string('Furnished', 50)->nullable();
            $table->string('Parking', 50)->nullable();
            $table->string('Rent', 50)->nullable();
            $table->string('TenantType', 50)->nullable();
            $table->text('Description')->nullable();
            $table->string('Pic', 50)->nullable();
            $table->string('Pic1', 50)->nullable();
            $table->string('Pic2', 50)->nullable();
            $table->string('Thumb', 50)->nullable();
            $table->boolean('Featured')->nullable();
            $table->string('Feature1', 50)->nullable();
            $table->string('Feature2', 50)->nullable();
            $table->string('Feature3', 50)->nullable();
            $table->string('Feature4', 50)->nullable();
            $table->string('Feature5', 50)->nullable();
            $table->string('Feature6', 50)->nullable();
            $table->string('Feature7', 50)->nullable();
            $table->string('Feature8', 50)->nullable();
            $table->string('Feature9', 50)->nullable();
            $table->string('Feature10', 50)->nullable();
            $table->string('Feature11', 50)->nullable();
            $table->string('Feature12', 50)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
