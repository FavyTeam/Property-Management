<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreatePlansTable extends Migration
{
    const TABLE = 'plans';

    public function up()
    {
        Schema::create(self::TABLE, function (Blueprint $table) {
            $table->increments('id');
            $table->tinyInteger('Deleted')->default('0')->nullable();
            $table->integer('Deletereason')->default('0')->nullable();
            $table->integer('Lock')->default('0')->nullable();
            $table->dateTime('DateAdded')->nullable();
            $table->integer('AddedBy')->default('0')->nullable();
            $table->integer('Managedby')->default('30')->nullable();
            $table->integer('Type')->default('0')->nullable();
            $table->string('Title', 5)->nullable();
            $table->string('Forename', 50)->nullable();
            $table->string('Surname', 50)->nullable();
            $table->string('2Title', 50)->nullable();
            $table->string('2Forename', 50)->nullable();
            $table->string('2Surname', 50)->nullable();
            $table->string('Addr1', 50)->nullable();
            $table->string('Addr2', 50)->nullable();
            $table->string('Addr3', 50)->nullable();
            $table->string('Addr4', 50)->nullable();
            $table->string('PostCode', 15)->nullable();
            $table->string('2Addr1', 50)->nullable();
            $table->string('2Addr2', 50)->nullable();
            $table->string('2Addr3', 50)->nullable();
            $table->string('2Addr4', 50)->nullable();
            $table->string('2Postcode', 50)->nullable();
            $table->string('Telhome', 50)->nullable();
            $table->string('Telwork', 50)->nullable();
            $table->string('Telmobile', 50)->nullable();
            $table->string('Email')->nullable();
            $table->integer('Source')->default('0')->nullable();
            $table->longText('Progress')->nullable();
            $table->dateTime('NextContact')->nullable();
            $table->dateTime('Timeadded')->nullable();
            $table->tinyInteger('Overseas')->nullable();
            $table->longText('Overseasnotes')->nullable();
            $table->tinyInteger('Mailshot')->nullable();
            $table->integer('Planorland')->default('1')->nullable();
            $table->tinyInteger('Blockletters')->nullable();
            $table->tinyInteger('Deal')->nullable();
            $table->tinyInteger('Siteoffice')->nullable();
            $table->tinyInteger('Buying')->nullable();
            $table->longText('Dealnotes')->nullable();
            $table->longText('Buyaim')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLE);
    }

}
