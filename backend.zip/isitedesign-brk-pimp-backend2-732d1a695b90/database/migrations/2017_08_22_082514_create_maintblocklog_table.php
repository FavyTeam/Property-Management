<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreateMaintblocklogTable extends Migration
{
    const TABLE = 'maintblocklog';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('MaintBlockLogIdno')->unsigned()->nullable()->default(0);
            $table->integer('Maintco')->unsigned()->nullable()->default(0);
            $table->string('Type', 50)->nullable();
            $table->dateTime('Date')->nullable();
            $table->integer('Who')->unsigned()->nullable()->default(0);
            $table->text('Reason')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}