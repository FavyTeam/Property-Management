<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateNewcontractsTable extends Migration
{
    const TABLE = 'newcontracts';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('Lock')->unsigned()->nullable()->default(0)->index('Lock');
            $table->integer('cont_ref')->unsigned()->nullable()->default(0)->unique('cont_ref');
            $table->string('tent_ref', 10)->nullable()->unique('tent_ref');
            $table->string('SORef', 100)->nullable();
            $table->string('SOSort', 6)->nullable();
            $table->string('SOAccount', 50)->nullable();
            $table->string('prop_ref', 10)->nullable()->unique('prop_ref');
            $table->dateTime('term_from')->nullable()->index('term_from');
            $table->dateTime('term_to')->nullable();
            $table->dateTime('drawn_up')->nullable();
            $table->string('ContractType', 50)->nullable();
            $table->string('terminated', 5)->nullable();
            $table->decimal('Rent', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->string('PayMethod', 5)->nullable();
            $table->integer('PayDay')->unsigned()->nullable()->default(0);
            $table->boolean('AutoInvoice')->nullable();
            $table->boolean('Periodic')->nullable()->default(0);
            $table->text('PayNotes')->nullable();
            $table->boolean('NoRenew')->nullable();
            $table->integer('NoRenewreason')->unsigned()->nullable()->default(0);
            $table->integer('NoRenewBy')->unsigned()->nullable()->default(0);
            $table->dateTime('NoRenewDate')->nullable();
            $table->boolean('UnderNotice')->nullable();
            $table->string('NoticeReason', 50)->nullable();
            $table->string('LeaveReason')->nullable();
            $table->dateTime('NoticeExpires')->nullable();
            $table->dateTime('TenantPlansToVacate')->nullable();
            $table->dateTime('SenttoLL')->nullable();
            $table->dateTime('SenttoCourt')->nullable();
            $table->dateTime('CourtOrder')->nullable();
            $table->dateTime('BailliffOrder')->nullable();
            $table->dateTime('DateVacated')->nullable();
            $table->text('NoticeNotes')->nullable();
            $table->dateTime('RentIncreaseDate')->nullable();
            $table->decimal('NewRent', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->dateTime('initialdrawn_up')->nullable();
            $table->dateTime('initialterm_from')->nullable()->index('initialterm_from');
            $table->dateTime('initialterm_to')->nullable();
            $table->string('LandlordName', 100)->nullable();
            $table->integer('NoTenants')->unsigned()->nullable()->default(0);
            $table->string('Tenant1Name', 100)->nullable();
            $table->string('Tenant2Name', 100)->nullable();
            $table->string('Tenant3Name', 100)->nullable();
            $table->string('Tenant1Address1', 50)->nullable();
            $table->string('Tenant1Address2', 50)->nullable();
            $table->string('Tenant1Address3', 50)->nullable();
            $table->string('Tenant2Address1', 50)->nullable();
            $table->string('Tenant2Address2', 50)->nullable();
            $table->string('Tenant2Address3', 50)->nullable();
            $table->string('Tenant3Address1', 50)->nullable();
            $table->string('Tenant3Address2', 50)->nullable();
            $table->string('Tenant3Address3', 50)->nullable();
            $table->string('GUTitle', 50)->nullable()->index('GUTitle');
            $table->string('GUForename', 50)->nullable();
            $table->string('GUInitials', 50)->nullable();
            $table->string('GUSurname', 100)->nullable();
            $table->string('GuarantorName', 100)->nullable();
            $table->string('GuarantorAddress1', 50)->nullable();
            $table->string('GuarantorAddress2', 50)->nullable();
            $table->string('GuarantorAddress3', 50)->nullable();
            $table->string('GuarantorAddress4', 50)->nullable();
            $table->string('GuarantorPostCode', 50)->nullable()->index('GuarantorPostCode');
            $table->text('GUEmail')->nullable();
            $table->string('GU2Title', 50)->nullable();
            $table->string('GU2Forename', 50)->nullable();
            $table->string('GU2Initials', 50)->nullable();
            $table->string('GU2Surname', 100)->nullable();
            $table->string('Guarantor2Name', 100)->nullable();
            $table->string('Guarantor2Address1', 50)->nullable();
            $table->string('Guarantor2Address2', 50)->nullable();
            $table->string('Guarantor2Address3', 50)->nullable();
            $table->string('Guarantor2Address4', 50)->nullable();
            $table->string('Guarantor2PostCode', 50)->nullable()->index('Guarantor2PostCode');
            $table->text('GU2Email')->nullable();
            $table->string('GU3Title', 50)->nullable();
            $table->string('GU3Forename', 50)->nullable();
            $table->string('GU3Initials', 50)->nullable();
            $table->string('GU3Surname', 100)->nullable();
            $table->string('Guarantor3Name', 100)->nullable();
            $table->string('Guarantor3Address1', 50)->nullable();
            $table->string('Guarantor3Address2', 50)->nullable();
            $table->string('Guarantor3Address3', 50)->nullable();
            $table->string('Guarantor3Address4', 50)->nullable();
            $table->string('Guarantor3PostCode', 50)->nullable()->index('Guarantor3PostCode');
            $table->text('GU3email')->nullable();
            $table->string('PropertyAddress1', 50)->nullable();
            $table->string('PropertyAddress2', 50)->nullable();
            $table->string('PropertyAddress3', 50)->nullable();
            $table->string('Months', 10)->nullable();
            $table->dateTime('FirstPayment')->nullable();
            $table->decimal('Deposit', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->decimal('TenancyFee', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->decimal('TenancyRenewal', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->string('LeadAddr1', 50)->nullable();
            $table->string('LeadAddr2', 50)->nullable();
            $table->string('LeadAddr3', 50)->nullable();
            $table->string('LeadAddr4', 50)->nullable();
            $table->string('LeadPostcode', 50)->nullable()->index('LeadPostcode');
            $table->text('LeadEmail')->nullable();
            $table->text('LeadPhone')->nullable();
            $table->integer('DepositScheme')->unsigned()->nullable()->default(2);
            $table->string('DPSDepositID', 50)->nullable()->index('DPSDepositID');
            $table->string('DPSRepaymentID', 50)->nullable()->index('DPSRepaymentID');
            $table->boolean('TDSLeadComplete')->nullable();
            $table->dateTime('TDSLeadCompleteDate')->nullable();
            $table->integer('TDSLeadCompleteBy')->nullable()->default(0);
            $table->boolean('TDSInfoComplete')->nullable();
            $table->dateTime('TDSInfoCompleteDate')->nullable();
            $table->integer('TDSInfoCompleteBy')->unsigned()->nullable()->default(0);
            $table->text('TDSNotes')->nullable();
            $table->decimal('T1DepositShare', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->decimal('T2DepositShare', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->decimal('T3DepositShare', 19, 4)->unsigned()->nullable()->default(0.0000);
            $table->string('SchemeReferenceNo', 50)->nullable();
            $table->text('TDSThirdPartyDepositInformation')->nullable();
            $table->boolean('TDSCert')->nullable();
            $table->dateTime('TDSCertDate')->nullable();
            $table->integer('TDSCertBy')->unsigned()->nullable()->default(0);
            $table->boolean('CorpInv')->nullable();
            $table->text('CorpInvAddress')->nullable();
            $table->text('Corpinvbody')->nullable();
            $table->boolean('Paymentchecked')->nullable();
            $table->dateTime('Paymentcheckeddate')->nullable();
            $table->text('Paymentcheckednotes')->nullable();
            $table->integer('Paymentcheckedby')->unsigned()->nullable()->default(0);
            $table->boolean('PISent')->nullable();
            $table->integer('PISentBy')->unsigned()->nullable()->default(0);
            $table->dateTime('PISentDate')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }

}
