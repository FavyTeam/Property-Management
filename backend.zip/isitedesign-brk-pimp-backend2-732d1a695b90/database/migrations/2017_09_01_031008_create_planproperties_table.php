<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;


class CreatePlanpropertiesTable extends Migration
{
    const TABLE = 'planproperties';

    public function up()
    {
        Schema::create(self::TABLE, function(Blueprint $table) {
            $table->increments('id');
            $table->integer('PlanIdno')->unsigned()->nullable()->default(0)->index('PlanIdno');
            $table->string('Address1', 50)->nullable();
            $table->string('Address2', 50)->nullable();
            $table->string('Address3', 50)->nullable();
            $table->string('Address4', 50)->nullable();
            $table->string('Postcode', 50)->nullable()->index('Postcode');
            $table->integer('PropertyStatus')->unsigned()->nullable()->default(0);
            $table->integer('Area')->unsigned()->nullable()->default(0);
            $table->integer('Bedrooms')->unsigned()->nullable()->default(0);
            $table->integer('PropertyType')->unsigned()->nullable()->default(0);
            $table->boolean('Conditionchecked')->nullable();
            $table->integer('Conditioncheckedby')->unsigned()->nullable()->default(0);
            $table->integer('Foundby')->unsigned()->nullable()->default(30);
            $table->timestamp('Dateadded')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->text('Details')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::drop(self::TABLE);
    }
}
