<?php

use App\Models\Heating;
use Illuminate\Database\Seeder;


class HeatingsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/heatings.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Heating::updateOrCreate(
                    ['Heating' => $row->heating]
                );
            }
        });
    }
}
