<?php

use App\Models\InvoiceTemplate;
use Illuminate\Database\Seeder;


class InvoicesTemplateTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/invoicestemplate.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {
            $results = $reader->all();

            foreach ($results as $row) {
                InvoiceTemplate::updateOrCreate(['IdNo' => $row->idno],
                    [
                        'Description' => $row->description,
                        'Net' => $row->net,
                        'VAT' => $row->vat,
                        'Total' => $row->total,
                        'NotUsed' => $row->notused
                    ]
                );
            }
        });
    }
}
