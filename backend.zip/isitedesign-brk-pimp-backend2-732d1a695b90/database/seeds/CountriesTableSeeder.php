<?php

use App\Models\Country;
use Illuminate\Database\Seeder;


class CountriesTableSeeder extends Seeder
{
  
    public function run()
    {
        $file = database_path('seeds/csv/countries.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Country::updateOrCreate(
                    ['Country' => $row->country],
                    ['FormalName' => $row->formal_name]
                );
            }
        });
    }
  
}
