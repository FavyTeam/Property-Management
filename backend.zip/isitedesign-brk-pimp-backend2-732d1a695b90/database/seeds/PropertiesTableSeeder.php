<?php

use App\Models\Property;
use Illuminate\Database\Seeder;


class PropertiesTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/properties.csv');
        $excel = App::make('excel');

        // dateTime column
        $lists = [
            'insp_date',
            'insp_time',
            'avail_to',
            'nextfree',
            'gas_done',
            'gas_next',
            'created',
            'insp_last',
            'gc_start',
            'gas_appt',
            'gas_time',
            'blr_time',
            'bc_start',
            'ele_time',
            'ec_start',
            'ptddate',
        ];

        $rows = $excel->load($file, function($reader) use ($lists) {

            $results = $reader->all();

            // make this to array of property
            $properties = $results->toArray();

            // get all keys
            $columns = array_keys($properties[0]);

            // get rid of the first column as this isn't needed
            array_shift($columns);

            // begin save
            foreach ($properties as $row) {
                // get all values
                $values = array_values($row);

                // get rid of the first element
                array_shift($values);

                // build data for saving
                $data = array_combine($columns, $values);

                $newData = null;

                // double check if data has a valid value
                array_walk($data, function($value, $key) use (&$newData, $lists) {
                    // include only value that is not empty
                    if (trim($value) !== '') {
                        $value = trim($value);

                        // check if dateTime type
                        if (in_array($key, $lists)) {
                            // format string value to a valid dateTime value
                            $dateTime = DateTime::createFromFormat('d/m/Y', $value);
                            $value = $dateTime->format('Y-m-d');
                        }

                        $newData[$key] = trim($value);
                    }
                });

                // save
                if (null != $newData) {
                    Property::updateOrCreate(['prop_id' => $row['id']], $newData);
                }
            }
        });
    }
}