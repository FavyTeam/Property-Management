<?php

use App\Models\PlanType;
use Illuminate\Database\Seeder;


class PlanTypesTableSeeder extends Seeder
{
    public function run()
    {
        // pre-defined plan types
        $types = [
            'Looking to Purchase',
            'Residential',
            'BTL Has Properties',
            'Changing Agent',
            'Other (Please specify in dialogue box)',
            'Inheritance',
            '***** Persimmon',
            'Land Registry',
            'New Investment Landlord',
            'Investment Landlord With Portfolio',
            'Selected Property Only'
        ];

        // make the pre-defined plan types available in db
        foreach ($types as $type) {
            PlanType::updateOrCreate(['PlanType' => $type]);
        }
    }
}
