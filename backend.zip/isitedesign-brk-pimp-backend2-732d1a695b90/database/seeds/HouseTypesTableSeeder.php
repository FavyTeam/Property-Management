<?php

use App\Models\HouseType;
use Illuminate\Database\Seeder;


class HouseTypesTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/housetypes.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                HouseType::updateOrCreate(
                    ['HouseType' => $row->housetype]
                );
            }
        });
    }
}
