<?php

use App\Models\ProspectAgeRange;
use Illuminate\Database\Seeder;


class ProspectsAgeRangeTableSeeder extends Seeder
{
    public function run()
    {
        $ageRanges = [
            '21 or Under',
            '21-25',
            '26-30',
            'Unknown',
            '31-40',
            '41-50',
            '51-60',
            '61+',
        ];

        foreach ($ageRanges as $ageRange) {
            ProspectAgeRange::updateOrCreate(['AgeRange' => $ageRange]);
        }
    }
}
