<?php

use App\Models\InvPayMethod;
use Illuminate\Database\Seeder;


class InvPayMethodsTableSeeder extends Seeder
{
    public function run()
    {
        $payMethods = [
            'Cash',
            'Chq',
            'SO',
            'Int',
            'PO',
            'Card',
            'NS',
        ];

        foreach ($payMethods as $method) {
            InvPayMethod::updateOrCreate(['Paymethod' => $method]);
        }
    }
}
