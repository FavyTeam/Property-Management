<?php

use App\Models\ProspectStatus;
use Illuminate\Database\Seeder;


class NewProspectStatusTableSeeder extends Seeder
{
    public function run()
    {
        $status = [
            'At Home/With parents',
            'Rented',
            'Own Home/Selling/Sold',
            'Staying With Friends',
            'Temp Accom (Hostel/Hotel)',
            'Unknown',
            'Irrelevant (not reliant on sale)',
            'Renting Own Property Out'
        ];

        foreach ($status as $stat) {
            ProspectStatus::updateOrCreate(['ProspectStatus' => $stat]);
        }
    }
}
