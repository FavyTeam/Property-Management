<?php

use App\Models\AreaGroups;
use Illuminate\Database\Seeder;

class AreaGroupsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/areagroups.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                AreaGroups::updateOrCreate(
                    [
                        'Areagroupidno' => $row->areagroupidno,
                        'AreaGroupNo' => $row->areagroupno,
                        'AreaGroupName' => $row->areagroupname,
                        'Area' => $row->area
                    ]
                );
            }
        });
    }

}
