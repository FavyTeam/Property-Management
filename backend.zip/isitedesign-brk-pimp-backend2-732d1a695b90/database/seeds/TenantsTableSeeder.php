<?php

use App\Models\Tenant;
use Illuminate\Database\Seeder;


class TenantsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/tenants.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                $data = [
                    'tent_ref' => $row->tent_ref,
                    'title' => $row->title,
                    'forename' => $row->forename,
                    'initials' => $row->initials,
                    'surname' => $row->surname,
                    'addr_1' => $row->addr_1,
                    'addr_2' => $row->addr_2,
                    'addr_3' => $row->addr_3,
                    'addr_4' => $row->addr_4,
                    'postcode' => $row->postcode,
                    'tel_home' => $row->tel_home,
                    'tel_work' => $row->tel_work,
                    'tel_workdesc' => $row->tel_workdesc,
                    'mobile' => $row->mobile,
                    'email' => $row->email,
                    'Nationality' => $row->nationality,
                    'NOPT' => $row->nopt,
                    'TextOk' => $row->textok,
                    'EmailOk' => $row->emailok,
                    'Unsubscribe' => $row->unsubscribe
                ];
                Tenant::updateOrCreate(['id' => $row->id], $data);
            }
        });
    }
}
