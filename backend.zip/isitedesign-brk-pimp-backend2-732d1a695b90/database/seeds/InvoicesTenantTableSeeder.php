<?php

use App\Models\InvoiceTenant;
use Illuminate\Database\Seeder;


class InvoicesTenantTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/invoicestenant.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {
            $results = $reader->all();

            foreach ($results as $row) {
                InvoiceTenant::updateOrCreate(['InvoiceIdNo' => $row->invoiceidno],
                    [
                        'Date' => date('Y-m-d', strtotime($row->date)),
                        'TentRef' => $row->tentref,
                        'PropRef' => $row->propref,
                        'Firstname' => $row->firstname,
                        'Surname' => $row->surname,
                        'Addr1' => $row->addr1,
                        'Addr2' => $row->addr2,
                        'Addr3' => $row->addr3,
                        'Addr4' => $row->addr4,
                        'PostCode' => $row->postcode,
                        'Invline' => $row->invline,
                        'Net' => $row->net,
                        'VAT' => $row->vat,
                        'Total' => $row->total,
                    ]
                );
            }
        });
    }
}
