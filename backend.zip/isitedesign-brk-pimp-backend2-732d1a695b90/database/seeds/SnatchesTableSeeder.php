<?php

use App\Models\Plan;
use Illuminate\Database\Seeder;


class SnatchesTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/snatches.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {

            $results = $reader->all();

            foreach ($results as $row) {
                Plan::updateOrCreate(['PlebIdno' => $row->plebidno],
                    [
                        'AddedBy' => 1,
                        'Managedby' => 1,
                        'Type' => $row->type,
                        'Title' => $row->title,
                        'Forename' => $row->forename,
                        'Surname' => $row->surname,
                        'Addr1' => $row->addr1,
                        'Addr2' => $row->addr2,
                        'Addr3' => $row->addr3,
                        'Addr4' => $row->addr4,
                        'PostCode' => $row->postcode,
                        'Telhome' => $row->telhome,
                        'Telwork' => $row->telwork,
                        'Telmobile' => $row->telmobile,
                        'Email' => $row->email,
                        'Progress' => $row->progress,
                        'Overseas' => $row->overseas,
                        'Planorland' => 2,
                        'Mailshot' => $row->mailshot,
                        'Blockletters' => $row->blockletters,
                        'Deal' => $row->deal,
                        'Siteoffice' => $row->siteoffice,
                        'Buying' => $row->buying,
                        'Dealnotes' => $row->dealnotes
                    ]
                );
            }
        });
    }
}
