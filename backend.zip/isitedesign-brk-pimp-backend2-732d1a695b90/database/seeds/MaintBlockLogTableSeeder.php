<?php

use App\Models\MaintBlockLog;
use Illuminate\Database\Seeder;


class MaintBlockLogTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/maintblocklog.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {

            $results = $reader->all();

            foreach ($results as $row) {
                MaintBlockLog::updateOrCreate(['MaintBlockLogIdno' => $row->id],
                    [
                        'Maintco' => $row->maintco,
                        'Type' => $row->type,
                        'Date' => date('Y-m-d', strtotime($row->date)),
                        'Who' => 1,
                        'Reason' => $row->reason
                    ]
                );
            }
        });
    }
}
