<?php

use App\Models\Invoice;
use Illuminate\Database\Seeder;


class InvoicesTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/invoicesll.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {
            $results = $reader->all();

            foreach ($results as $row) {
                Invoice::updateOrCreate(['InvoiceIdNo' => $row->invoiceidno],
                    [
                        'Lock' => $row->lock,
                        'Date' => date('Y-m-d', strtotime($row->date)),
                        'LordRef' => $row->lordref,
                        'PropRef' => $row->propref,
                        'JobNo' => $row->jobno,
                        'Internalcomments' => $row->internalcomments,
                        'Firstname' => $row->firstname,
                        'Surname' => $row->surname,
                        'Addr1' => $row->addr1,
                        'Addr2' => $row->addr2,
                        'Addr3' => $row->addr3,
                        'Addr4' => $row->addr4,
                        'PostCode' => $row->postcode,
                        'SuppInvNo' => $row->suppinvno,
                        'Invline' => $row->invline,
                        'Net' => $row->net,
                        'VAT' => $row->vat,
                        'Total' => $row->total,
                        'OurNet' => $row->ournet,
                        'OurVAT' => $row->ourvat,
                        'OurTotal' => $row->ourtotal,
                        'AccountsUpdated' => $row->accountsupdated,
                        'Check' => $row->check
                    ]
                );
            }
        });
    }
}
