<?php

use App\Models\Upgrade;
use Illuminate\Database\Seeder;

class UpgradeTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/upgrades.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
              Upgrade::updateOrCreate(
                [ 
                  'Propertyref' => $row->propertyref,
                  'DateAdded' => date('Y-m-d', strtotime($row->dateadded)),
                  'Addedby' => $row->addedby,
                  'Status' => $row->status,                  
                  'Notes' => $row->notes,
                  'Nextactiondate' => date('Y-m-d', strtotime($row->nextactiondate)),
                  'Nextactionby' => $row->nextactionby,
                  'NextAction' => $row->nextAction,
                  'Closed' => $row->closed,
                  'Lock' => $row->lock,
                  'LLAware' => $row->llaware,
                  'LLAwareby' => $row->llawareby,                  
                  'LLAwareDate' => date('Y-m-d', strtotime($row->llawareDate))
                ]
              );
            }
        });
    }
}
