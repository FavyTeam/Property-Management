<?php

use App\Models\LettingAgent;
use Illuminate\Database\Seeder;


class LettingAgentsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/lettingagents.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {

            $results = $reader->all();

            foreach ($results as $row) {
                LettingAgent::updateOrCreate(['CompanyName' => $row->companyname],
                    [
                        'Title' => $row->title,
                        'Forename' => $row->forename,
                        'Surname' => $row->surname,
                        'Address1' => $row->address1,
                        'Address2' => $row->address2,
                        'Address3' => $row->address3,
                        'Address4' => $row->address4,
                        'PostCode' => $row->postcode,
                        'PhoneWork' => $row->phonework,
                        'Fax' => $row->fax,
                        'PhoneMobile' => $row->phonemobile,
                        'Email' => $row->email,
                        'Charge' => $row->charge
                    ]
                );
            }
        });
    }
}
