<?php

use App\Models\LandLord;
use Illuminate\Database\Seeder;


class LandLordsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/landlords.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {
            $results = $reader->all();

            foreach ($results as $row) {
                LandLord::updateOrCreate(['lord_ref' => $row->lord_ref],
                    [
                        'title' => $row->title,
                        'forename' => $row->forename,
                        'surname' => $row->surname,
                        'initials' => $row->initials,
                        'addr_1' => $row->addr_1,
                        'addr_2' => $row->addr_2,
                        'addr_3' => $row->addr_3,
                        'addr_4' => $row->addr_4,
                        'postcode' => $row->postcode,
                        'Country' => $row->country,
                        'tel_home' => $row->tel_home,
                        'tel_work' => $row->tel_work,
                        'mobile' => $row->mobile,
                        'fax' => $row->fax,
                        'email' => $row->email,
                        'Source' => $row->source,
                        'overseas' => $row->overseas,
                        'Overseasnotes' => $row->overseasnotes,
                        'Dealnotes' => $row->dealnotes
                    ]
                );
            }
        });
    }
}
