<?php

use App\Models\ProspectTitle;
use Illuminate\Database\Seeder;


class ProspectsTitleTableSeeder extends Seeder
{
    public function run()
    {
        $titles = [
            'Mr',
            'Miss',
            'Ms',
            'Doctor',
            'Sir',
            'Reverand',
            'Warr Off',
            'Lady',
            'Lord',
            'Sgt',
            'Father',
            'Rt Hon',
            'The',
        ];

        foreach ($titles as $title) {
            ProspectTitle::updateOrCreate(['Title' => $title]);
        }
    }
}
