<?php

use App\Models\ProspectRent;
use Illuminate\Database\Seeder;


class ProspectRentTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/prospectsrent.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                ProspectRent::updateOrCreate(['Rent' => floatval(str_replace(',', '', $row->rent))]);
            }
        });
    }
}
