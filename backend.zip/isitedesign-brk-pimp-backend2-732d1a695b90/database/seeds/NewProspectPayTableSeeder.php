<?php

use App\Models\NewProspectPay;
use Illuminate\Database\Seeder;


class NewProspectPayTableSeeder extends Seeder
{
    public function run()
    {
        $pays = [
            'Working',
            'Own Means',
            'Housing Benefit',
            'Part Housing Benefit',
            'Company Paying',
            'Unknown',
            'Self Employed',
            'Agency Employed',
        ];

        foreach ($pays as $pay) {
            NewProspectPay::updateOrCreate(['Paymethod' => $pay]);
        }
    }
}
