<?php

use App\Models\Prospect;
use Illuminate\Database\Seeder;


class ProspectsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('/seeds/csv/prospects.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function($reader) {

            $results = $reader->all();

            foreach ($results as $row) {
                Prospect::updateOrCreate(['id' => $row->id],
                    [
                        'DateTaken' => $row->datetaken,
                        'Forename' => $row->forename,
                        'LastName' => $row->lastname,
                        'Address1' => $row->address1,
                        'Address2' => $row->address2,
                        'Address3' => $row->address3,
                        'Address4' => $row->address4,
                        'PostCode' => $row->postcode,
                        'PhoneHome' => $row->phonehome,
                        'PhoneWork' => $row->phonework,
                        'PhoneMobile' => $row->phonemobile,
                        'Email' => $row->email,
                    ]
                );
            }
        });
    }
}
