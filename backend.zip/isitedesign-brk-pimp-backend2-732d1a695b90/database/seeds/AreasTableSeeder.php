<?php

use App\Models\Area;
use Illuminate\Database\Seeder;


class AreasTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/areas.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Area::updateOrCreate(['AreaIdNo' => $row->areaidno],
                    [
                        'Area' => $row->area,
                        'AreaCat' => $row->areacat,
                        'WebId' => $row->webid,
                        'Gasid' => $row->gasid,
                    ]
                );
            }
        });
    }

}
