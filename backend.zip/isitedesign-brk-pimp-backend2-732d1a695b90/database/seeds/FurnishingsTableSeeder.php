<?php

use App\Models\Furnishing;
use Illuminate\Database\Seeder;


class FurnishingsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/furnishings.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Furnishing::updateOrCreate(
                    ['Furnishing' => $row->furnishing]
                );
            }
        });
    }
}
