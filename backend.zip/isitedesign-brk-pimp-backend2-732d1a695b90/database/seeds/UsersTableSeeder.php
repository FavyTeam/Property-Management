<?php

use App\Models\User;
use Illuminate\Database\Seeder;


class UsersTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/users.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                User::updateOrCreate(['email' => $row->email],
                    [
                        'first_name' => $row->first_name,
                        'last_name' => $row->last_name,
                        'password' => bcrypt($row->password),
                        'Username' => $row->username,
                        'Initials' => $row->initials,
                        'Ratsdate' => !empty($row->ratsdate) ? date('Y-m-d', strtotime($row->ratsdate)) : null,
                        'Current Status' => $row->current_status,
                        'Ext' => $row->ext,
                        'Loggedin' => $row->loggedin,
                        'Lunch' => !empty($row->lunch) ? date('Y-m-d H:i:s', strtotime($row->lunch)) : null,
                        'Out' => $row->out,
                        'Inactivity' => $row->inactivity,
                        'Security' => $row->security,
                        'Management' => $row->management,
                        'Prospects' => $row->prospects,
                        'Prospectsdefault' => $row->prospectsdefault,
                        'MaximumProspects' => $row->maximumprospects,
                        'Letterhead' => $row->letterhead,
                        'Department' => $row->department,
                        'TenantAccount' => $row->tenantaccount,
                        'AddProperty' => $row->addproperty,
                        'Febootimail' => $row->febootimail,
                        'Current' => $row->current,
                        'RAC' => $row->rac,
                        'Delprosp' => $row->delprosp,
                        'Board' => $row->board,
                        'Updaterequired' => $row->updaterequired,
                        'Mobilenumber' => $row->mobilenumber,
                        'Returndate' => date('Y-m-d'),
                        'Returntime' => date('Y-m-d H:i:s'),
                        'ratsdatein' => !empty($row->ratsdatein) ? date('Y-m-d', strtotime($row->ratsdatein)) : null,
                        'ratstimein' => !empty($row->ratstimein) ? date('Y-m-d H:i:s', strtotime($row->ratstimein)) : null,
                        'ratsdateout' => !empty($row->ratsdateout) ? date('Y-m-d', strtotime($row->ratsdatetout)) : null,
                        'ratstimeout' => !empty($row->ratstimeout) ? date('Y-m-d H:i:s', strtotime($row->ratstimeout)) : null,
                        'Viewings' => $row->viewings,
                        'Nextevening' => !empty($row->nextevening) ? date('Y-m-d', strtotime($row->nextevening)) : null,
                    ]);
            }
        });
    }
}