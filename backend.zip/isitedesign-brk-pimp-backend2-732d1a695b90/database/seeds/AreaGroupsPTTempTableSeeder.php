<?php

use App\Models\AreaGroupsPTTemp;
use Illuminate\Database\Seeder;

class AreaGroupsPTTempTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/areagroupspttemp.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                AreaGroupsPTTemp::updateOrCreate(
                    [
                        'AreaGroupNo' => $row->areagroupno,
                        'AreaGroupName' => $row->areagroupname
                    ]
                );
            }
        });
    }

}
