<?php

use App\Models\SourcesCategory;
use Illuminate\Database\Seeder;


class SourcesCategoryTableSeeder extends Seeder
{
    public function run()
    {
        $categories = [
            'Internet Email Incoming',
            'Publication (Newspaper/Supplement)',
            'Public Body',
            'Other',
            'Estate Agent',
            'Internet (Saw us on a web-site)',
            'Leaflet',
        ];

        foreach ($categories as $category) {
            SourcesCategory::updateOrCreate(['SourcesCategory' => $category]);
        }
    }
}
