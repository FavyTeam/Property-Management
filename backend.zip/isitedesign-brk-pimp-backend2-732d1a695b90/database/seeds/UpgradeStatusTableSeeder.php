<?php

use App\Models\UpgradeStatus;
use Illuminate\Database\Seeder;


class UpgradeStatusTableSeeder extends Seeder
{
    public function run()
    {
        $statuses = [
            'LL Not Sure',
            'PLI Pending',
            'Await LL',
            'Awaiting Quotes',
            'Await Works Completion',
            'Pending Allocation',
            'FI Pending',
            'Marketing Required',
            'LL Trying To Sell',
        ];

        foreach ($statuses as $status) {
            UpgradeStatus::updateOrCreate(['Status' => $status]);
        }
    }
}
