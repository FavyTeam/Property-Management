<?php

use App\Models\MaintEngineer;
use Illuminate\Database\Seeder;


class MaintEngineersTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/maintengineers.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {

            $results = $reader->all();

            foreach ($results as $row) {
                MaintEngineer::updateOrCreate(['MaintIdno' => $row->maintidno],
                    [
                        'MaintName' => $row->maintname,
                        'MaintTitle' => $row->mainttitle,
                        'MaintForename' => $row->maintforename,
                        'MaintSurname' => $row->maintsurname,
                        'MaintAdd1' => $row->maintadd1,
                        'MaintAdd2' => $row->maintadd2,
                        'MaintAdd3' => $row->maintadd3,
                        'MaintAdd4' => $row->maintadd4,
                        'MainPostcode' => $row->mainpostcode,
                        'MainTelno' => $row->maintelno,
                        'MaintFaxno' => $row->maintfaxno,
                        'MaintOthertel' => $row->maintothertel,
                        'MaintGSI' => $row->maintgsi,
                        'MaintContact' => $row->maintcontact,
                        'MaintDescription' => $row->maintdescription,
                        'SpecialComments' => $row->specialcomments,
                        'NotUsed' => $row->notused,
                        'SendLetter' => $row->sendletter,
                        'Blocked' => $row->blocked,
                        'BlockedBy' => $row->blockedby,
                        'BlockedDate' => $row->blockeddate,
                        'Reason' => $row->reason,
                        'BlockedExpiry' => $row->blockedexpiry,
                        'BlockLimit' => $row->blocklimit,
                        'PLIStart' => !empty($row->plistart) ? date('Y-m-d', strtotime($row->plistart)) : null,
                        'PLIEnd' => !empty($row->pliend) ? date('Y-m-d', strtotime($row->pliend)) : null,
                        'PLINotes' => $row->plinotes,
                        'Emailcontact' => $row->emailcontact,
                        'GSI' => $row->gsi,
                        'Invisible' => $row->invisible
                    ]
                );
            }
        });
    }
}
