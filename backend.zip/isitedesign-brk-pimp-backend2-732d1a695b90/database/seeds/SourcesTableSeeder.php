<?php

use App\Models\Source;
use Illuminate\Database\Seeder;


class SourcesTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/sources.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Source::updateOrCreate(['id' => $row->sourceidno],
                    [
                        'Category' => $row->category,
                        'Source' => $row->source,
                        'Minimal' => $row->minimal,
                        'SourcesCategory' => $row->sourcescategory,
                        'Spoke' => $row->spoke,
                        'PRICS' => $row->prics,
                    ]
                );
            }
        });
    }

}
