<?php

use App\Models\ProspectCategory;
use Illuminate\Database\Seeder;


class ProspectCategoryTableSeeder extends Seeder
{
    public function run()
    {
        $categories = [
            'Must Contact',
            'Actively Looking',
            'On Back Burner',
            'Test',
        ];

        foreach ($categories as $category) {
            ProspectCategory::updateOrCreate(['Description' => $category]);
        }
    }
}
