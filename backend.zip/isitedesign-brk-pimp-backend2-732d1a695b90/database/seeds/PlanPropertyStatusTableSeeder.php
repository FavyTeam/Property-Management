<?php

use App\Models\PlanPropertyStatus;
use Illuminate\Database\Seeder;


class PlanPropertyStatusTableSeeder extends Seeder
{
    public function run()
    {
        // pre-defined plan property status
        $status = [
            'Currently Tenanted',
            'Landlord Resident',
            'Being Purchased',
            'Empty',
            'Land Registry',
        ];

        // make the pre-defined plan property status available in db
        foreach ($status as $st) {
            PlanPropertyStatus::updateOrCreate(['Status' => $st]);
        }
    }
}
