<?php

use App\Models\TenantType;
use Illuminate\Database\Seeder;


class TenantTypeTableSeeder extends Seeder
{
    public function run()
    {
        // pre-defined tenant types
        $types = [
            'Working Tenants Only',
            'All Applicants Considered',
            'Working Housing Benefit Only',
        ];

        // make the pre-defined tenant types available in db
        foreach ($types as $type) {
            TenantType::updateOrCreate(['TenantType' => $type]);
        }
    }
}
