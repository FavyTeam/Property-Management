<?php

use Illuminate\Database\Seeder;


class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call(UsersTableSeeder::class);
        $this->call(CountriesTableSeeder::class);
        $this->call(PlanTypesTableSeeder::class);
        $this->call(PlansTableSeeder::class);
        $this->call(SnatchesTableSeeder::class);
        $this->call(LandLordsTableSeeder::class);
        $this->call(PropertiesTableSeeder::class);
        $this->call(LettingAgentsTableSeeder::class);
        $this->call(MaintEngineersTableSeeder::class);
        $this->call(MaintBlockLogTableSeeder::class);
        $this->call(InvPayMethodsTableSeeder::class);
        $this->call(InvoicesTemplateTableSeeder::class);
        $this->call(InvoicesTenantTableSeeder::class);
        $this->call(InvoicesTableSeeder::class);
        $this->call(AreasTableSeeder::class);
        $this->call(PlanPropertyStatusTableSeeder::class);
        $this->call(TenantTypeTableSeeder::class);
        $this->call(TenantsTableSeeder::class);
        $this->call(HouseTypesTableSeeder::class);
        $this->call(HeatingsTableSeeder::class);
        $this->call(FurnishingsTableSeeder::class);
        $this->call(ProspectsTitleTableSeeder::class);
        $this->call(SourcesCategoryTableSeeder::class);
        $this->call(ApplicationsTableSeeder::class);
        $this->call(ProspectsTableSeeder::class);
        $this->call(NewProspectPayTableSeeder::class);
        $this->call(NewProspectStatusTableSeeder::class);
        $this->call(ProspectsAgeRangeTableSeeder::class);
        $this->call(ProspectCategoryTableSeeder::class);
        $this->call(ProspectRentTableSeeder::class);
        $this->call(NewPropertiesTableSeeder::class);
        $this->call(UpgradeStatusTableSeeder::class);
        $this->call(AppointmentsTableSeeder::class);
        $this->call(SourcesTableSeeder::class);
        $this->call(WaitListTableSeeder::class);
        $this->call(AreaGroupsPTTempTableSeeder::class);
        $this->call(AreaGroupsTableSeeder::class);
        $this->call(UpgradeTableSeeder::class);
    }
}
