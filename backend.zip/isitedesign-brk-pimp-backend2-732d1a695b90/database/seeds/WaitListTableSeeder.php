<?php

use App\Models\WaitList;
use Illuminate\Database\Seeder;

class WaitListTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/waitlist.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                WaitList::updateOrCreate(
                    [
                        'WaitlistIdno' => $row->waitlistidno,
                        'ProspectIdNo' => $row->prospectidno,
                        'PropertyRef' => $row->propertyref,
                        'DateAdded' => date('Y-m-d', strtotime($row->dateadded))
                    ]
                );
            }
        });
    }

}
