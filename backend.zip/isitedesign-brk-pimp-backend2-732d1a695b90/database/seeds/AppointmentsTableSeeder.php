<?php

use App\Models\Appointment;
use Illuminate\Database\Seeder;


class AppointmentsTableSeeder extends Seeder
{
    public function run()
    {
        $file = database_path('seeds/csv/appointments.csv');
        $excel = App::make('excel');

        $rows = $excel->load($file, function ($reader) {
            $results = $reader->all();
            foreach ($results as $row) {
                Appointment::updateOrCreate(
                    [
                        'DateAdded' => $row->dateadded,
                        'TimeAdded' => $row->timeadded,
                        'Whobooked' => $row->whobooked,
                        'AppSource' => null,
                        'WhoDoing' => $row->whodoing,
                        'Date' => $row->date,
                        'Time' => $row->time,
                        'PropRef' => $row->propref,
                        'ProspectId' => $row->prospectid,
                        'AppNotes' => $row->appnotes,
                        'RTC' => $row->rtc,
                        'ConfirmOcc' => $row->confirmocc,
                        'ConfirmOccNotes' => $row->confirmoccnotes,
                        'ConfirmedOcc' => $row->confirmedocc,
                        'Whoconf' => $row->whoconf,
                        'Confnotes' => $row->confnotes,
                        'Showed' => $row->showed,
                        'Interested' => $row->interested,
                        'TenantFeedback' => $row->tenantfeedback,
                        'BrookdaleFeedback' => $row->brookdalefeedback
                    ]
                );
            }
        });
    }

}
