<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Controllers\Api\V2\Controller;
use App\Models\Diary;

class DiaryController extends Controller
{
    public function __construct()
    {
        $this->model = Diary::class;
    }

    public function index()
    {
        $query = $this->getModel()
            ->when($date = request()->date, function ($query) use ($date) {
                $query->where('date', 'LIKE', '%'.$date.'%');
            })
            ->when($for = request()->for, function ($query) use ($for) {
                $query->where('for', '=', $for);
            })
            ->when($date_before = request()->dateBefore, function ($query) use ($date_before) {
              $query->where('date', '<', $date_before);
            })
            ->when($date_from = request()->dateFrom, function ($query) use ($date_from) {
                $query->where('date', '>=', $date_from);
            });

        if ($limit = request()->limit) {
            return $this->paginator($query->paginate($limit));
        }

        return $this->collection($query->get());
    }
}
