<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller as BaseController;
use Dingo\Api\Routing\Helpers;
use App\Transformers\V1\BaseTransformer as Transformer;
use App\Traits\Resource;
use Input;


/**
 * Base Controller class on handling HTTP request
 *
 * Class Controller
 * @package App\Http\Controllers\Api
 */

class Controller extends BaseController
{
    use Helpers, Resource;

    /**
     * @var
     */
    protected $repository;

    /**
     * @var
     */
    protected $transformer;

    /**
     * @var
     */
    protected $key;

    /**
     * @var
     */
    protected $storeRequest = null;

    /**
     * @var
     */
    protected $updateRequest = null;

    /**
     * @var int
     */
    protected $perPage = 25;

    /**
     * @var int
     */
    protected $perPageMin = 1;

    /**
     * @var int
     */
    protected $perPageMax = 1000;

    /**
     * @var bool
     */
    protected $paginate = true;

    /**
     * @var string
     */
    protected $sortBy = 'id';

    /**
     * @var string
     */
    protected $sortOrder = 'desc';

    /**
     * @var array
     */
    protected $fields = ['*'];

    /**
     * @var null
     */
    protected $relations = null;

    public function __construct()
    {
        // default transformer class
        $this->transformer = Transformer::class;

        $this->key = ['key' => $this->key];

        // use pagination?
        $this->paginate = Input::has('paginate') ? ((bool) (int) Input::get('paginate')) : $this->paginate;

        $perPage = (int) Input::get('per_page');

        // Ensure that we only allow the maximum perPage value
        if ($perPage > $this->perPageMax || $perPage < $this->perPageMin)
        {
            // use the default
            $perPage = $this->perPage;
        }

        $this->perPage = $perPage;

        // Sorting
        $this->sortBy = Input::has('sortBy') ? Input::get('sortBy') : $this->sortBy;
        $this->sortOrder = Input::has('sortOrder') ? Input::get('sortOrder') : $this->sortOrder;

        // Custom fields, expected to be facebook like arguments appended to the URL, e.g ?fields=field1,field2,field3
        if (Input::get('fields')) {
            $fields = rtrim(Input::get('fields'), ',');
            $this->fields = explode(',', $fields);
        }
    }
}
