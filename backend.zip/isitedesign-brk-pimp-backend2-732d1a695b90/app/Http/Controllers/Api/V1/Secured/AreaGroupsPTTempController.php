<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\AreaGroupsPTTempRepository as AreaGroupsPTTemp;
use Input;


class AreaGroupsPTTempController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'areagroupspttemps';

    public function __construct(AreaGroupsPTTemp $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        return parent::index();
    }
}
