<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\DiaryRepository as Diary;
use App\Repositories\Criteria\Common\FindByPropRef;
use App\Http\Requests\V1\Diary\StoreRequest;
use App\Repositories\Criteria\Diary\FindByFor;
use App\Repositories\Criteria\Diary\FindByDate;
use App\Repositories\Criteria\Diary\FindDatesFrom;
use App\Repositories\Criteria\Diary\FindDatesBefore;
use Input;


class DiaryController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'diaries';

    public function __construct(Diary $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        if (Input::get('propRef')) {
            $this->repository->pushCriteria(new FindByPropRef(Input::get('propRef')));
        }

        if (Input::has('for')) {
            $this->repository->pushCriteria(new FindByFor(Input::get('for')));
        }

        if (Input::has('date')) {
            $this->repository->pushCriteria(new FindByDate(Input::get('date')));
        }

        if (Input::has('dateBefore')) {
            $this->repository->pushCriteria(new FindDatesBefore(Input::get('dateBefore')));
        }

        if (Input::has('dateFrom')) {
            $this->repository->pushCriteria(new FindDatesFrom(Input::get('dateFrom')));
        }

        return parent::index();
    }
}
