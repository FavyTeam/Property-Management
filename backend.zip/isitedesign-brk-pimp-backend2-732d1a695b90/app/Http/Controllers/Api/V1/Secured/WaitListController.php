<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\WaitListRepository as WaitList;
use App\Repositories\Criteria\Common\FindByProspectIdNo;
use Input;


class WaitListController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'waitlists';

    public function __construct(WaitList $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        if (Input::has('prospectIdNo')) {
            $this->repository->pushCriteria(new FindByProspectIdNo(Input::get('prospectIdNo')));
        }

        return parent::index();
    }
}
