<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Criteria\MaintEngineer\BlockedByLordRef;
use App\Repositories\Eloquent\MaintEngineerRepository as MaintEngineer;
use App\Repositories\Criteria\MaintEngineer\MaintNameNotEqualLandLord;
use App\Repositories\Criteria\MaintEngineer\UsedCondition;
use App\Repositories\Criteria\MaintEngineer\NotUsedCondition;
use Input;


class MaintEngineerController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'maintengineers';

    public function __construct(MaintEngineer $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        // criteria
        $this->repository->pushCriteria(new MaintNameNotEqualLandLord);

        if (null !== Input::get('used')) {
            if (1 === (int) Input::get('used')) {
                // UsedCondition criteria
                $this->repository->pushCriteria(new UsedCondition());
            } else {
                // NotUsedCondition criteria
                $this->repository->pushCriteria(new NotUsedCondition());
            }
        }

        // Check if we don't want to include company that has been blocked by lordRef
        if (Input::get('lordRef')) {
            $this->repository->pushCriteria(new BlockedByLordRef(Input::get('lordRef')));
        }

        // Call mom!
        return parent::index();
    }
}
