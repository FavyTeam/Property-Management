<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\RentLetterRepository as RentLetter;


class RentLetterController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'rentletters';

    public function __construct(RentLetter $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
