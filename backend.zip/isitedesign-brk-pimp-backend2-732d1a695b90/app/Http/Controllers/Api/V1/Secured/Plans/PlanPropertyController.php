<?php

namespace App\Http\Controllers\Api\V1\Secured\Plans;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\Plans\PlanPropertyRepository as PlanProperty;
use App\Repositories\Criteria\PlanProperty\PlanOnly;
use App\Repositories\Criteria\PlanProperty\AllByPlanId;
use Input;


class PlanPropertyController extends Controller
{
    /**
     * @var string
     */
    protected $sortBy = 'planproperties.id';

    /**
     * @var array
     */
    protected $relations = ['area'];

    /**
     * @var string
     */
    protected $key = 'planproperties';

    /**
     * @var array
     */
    protected $fields = ['planproperties.*'];

    public function __construct(PlanProperty $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // Push PlanOnly criteria to the repo
        $this->repository->pushCriteria(new PlanOnly());

        if (Input::get('planId')) {
            $this->repository->pushCriteria(new AllByPlanId(Input::get('planId')));
        }

        return parent::index();
    }
}
