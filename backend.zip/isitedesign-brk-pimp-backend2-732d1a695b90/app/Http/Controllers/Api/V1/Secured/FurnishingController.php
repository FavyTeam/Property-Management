<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\FurnishingRepository as Furnishing;


class FurnishingController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'furnishings';

    public function __construct(Furnishing $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
