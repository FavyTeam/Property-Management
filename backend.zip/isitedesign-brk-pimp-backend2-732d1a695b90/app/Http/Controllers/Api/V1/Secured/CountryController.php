<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\CountryRepository as Country;


class CountryController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'countries';

    public function __construct(Country $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
