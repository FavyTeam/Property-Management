<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\UserRepository as User;
use App\Repositories\Criteria\User\IsCurrent;
use App\Repositories\Criteria\User\IsNotCurrent;
use App\Repositories\Criteria\User\IsDepartment;
use App\Repositories\Criteria\User\IsNotDepartment;
use Input;


class UserController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'users';

    public function __construct(User $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        if (Input::has('current')) {
            if (Input::get('current') == 1) {
                $this->repository->pushCriteria(new IsCurrent());
            } elseif (Input::get('current') == 0) {
                $this->repository->pushCriteria(new IsNotCurrent());
            }
        }

        if (Input::has('department')) {
            if (Input::get('department') == 1) {
                $this->repository->pushCriteria(new IsDepartment());
            } elseif (Input::get('department') == 0) {
                $this->repository->pushCriteria(new IsNotDepartment());
            }
        }

        return parent::index();
    }

    /**
     * Display the specified resource.
     *
     * @param string $id
     * @return Response
     */
    public function show($id)
    {
        // Check if we want the current user data
        if (strtolower(trim($id)) == 'me') {
            $id = request()->user()->id;
        }

        // call mom!
        return parent::show($id);
    }
}
