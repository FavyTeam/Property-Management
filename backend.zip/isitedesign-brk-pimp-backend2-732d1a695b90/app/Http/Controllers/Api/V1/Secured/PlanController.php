<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\PlanRepository as Plan;
use App\Repositories\Criteria\Plan\PlanOnly;
use App\Http\Requests\V1\Plan\StoreRequest;
use App\Http\Requests\V1\Plan\UpdateRequest;


class PlanController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'plans';

    /**
     * @var array
     */
    protected $relations = ['addedBy', 'managedBy'];

    public function __construct(Plan $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // Push PlanOnly criteria to the repo
        $this->repository->pushCriteria(new PlanOnly());

        return parent::index();
    }
}
