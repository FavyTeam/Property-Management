<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\PlanRepository as Plan;
use App\Repositories\Criteria\Plan\SnatchOnly;
use App\Http\Requests\V1\Snatch\StoreRequest;
use App\Http\Requests\V1\Snatch\UpdateRequest;

class SnatchController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'snatches';

    /**
     * @var array
     */
    protected $relations = ['addedBy', 'managedBy'];

    public function __construct(Plan $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // Push SnatchOnly criteria to the repo
        $this->repository->pushCriteria(new SnatchOnly());

        return parent::index();
    }
}
