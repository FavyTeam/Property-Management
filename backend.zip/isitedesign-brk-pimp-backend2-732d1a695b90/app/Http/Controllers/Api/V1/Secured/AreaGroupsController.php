<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\AreaGroupsRepository as AreaGroups;
use App\Repositories\Criteria\Area\FindByAreaGroupNo;
use Input;


class AreaGroupsController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'areagroups';

    public function __construct(AreaGroups $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        if (Input::has('areaGroupNo')) {
            $this->repository->pushCriteria(new FindByAreaGroupNo(Input::get('areaGroupNo')));
        }

        return parent::index();
    }
}
