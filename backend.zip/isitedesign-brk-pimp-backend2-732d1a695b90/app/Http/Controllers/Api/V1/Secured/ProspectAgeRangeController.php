<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectAgeRangeRepository as AgeRange;


class ProspectAgeRangeController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospectageranges';

    public function __construct(AgeRange $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
