<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\NewContractRepository as NewContract;
use App\Http\Requests\V1\Contract\StoreRequest;


class NewContractController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'contracts';


    public function __construct(NewContract $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }

    public function store($data = null)
    {
        return parent::store([
            'contRef' => $this->repository->generateContRef(),
        ]);
    }
}
