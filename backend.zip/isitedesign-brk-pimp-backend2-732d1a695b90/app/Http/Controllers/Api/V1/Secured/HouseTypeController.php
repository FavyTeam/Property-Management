<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\HouseTypeRepository as HouseType;


class HouseTypeController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'housetypes';

    public function __construct(HouseType $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
