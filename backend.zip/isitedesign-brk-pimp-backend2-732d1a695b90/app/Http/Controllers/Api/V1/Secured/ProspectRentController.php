<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectRentRepository as ProspectRent;


class ProspectRentController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospectrents';

    public function __construct(ProspectRent $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
