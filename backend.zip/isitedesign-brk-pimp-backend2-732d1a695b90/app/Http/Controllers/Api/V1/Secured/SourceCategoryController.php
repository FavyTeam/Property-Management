<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\SourceCategoryRepository as SourceCategory;


class SourceCategoryController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'sourcecategories';

    public function __construct(SourceCategory $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
