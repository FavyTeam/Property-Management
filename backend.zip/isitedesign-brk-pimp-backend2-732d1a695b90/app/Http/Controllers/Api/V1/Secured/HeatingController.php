<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\HeatingRepository as Heating;


class HeatingController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'heatings';

    public function __construct(Heating $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
