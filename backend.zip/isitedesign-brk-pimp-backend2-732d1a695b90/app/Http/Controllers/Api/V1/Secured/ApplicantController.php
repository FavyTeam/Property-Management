<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ApplicantRepository as Applicant;
use App\Repositories\Criteria\Common\FindByPropRef;
use Input;


class ApplicantController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'applicants';

    public function __construct(Applicant $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        if (Input::get('propRef')) {
            $this->repository->pushCriteria(new FindByPropRef(Input::get('propRef')));
        }

        return parent::index();
    }
}
