<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\InvoiceTenantRepository as InvoiceTenant;


class InvoiceTenantController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'invoicetenants';

    public function __construct(InvoiceTenant $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
