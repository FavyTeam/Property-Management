<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\PropertyPhotoRepository as PropertyPhoto;
use App\Http\Requests\V1\Photo\StoreRequest;
use Storage, Image;


class PhotoController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'photos';

    private $storagePath = 'photos/';

    public function __construct(PropertyPhoto $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * @param StoreRequest $request
     * @return \Dingo\Api\Http\Response
     */
    public function upload(StoreRequest $request)
    {
        $photoId = [];

        foreach ($request->file('photos') as $photo) {
            // save image
            $fileName = basename($photo->store('photos'));

            // save in db
            $photoId[] = $this->repository->create([
               'propertyRef' => $request->get('propRef'),
                'fileName' => $fileName,
            ]);

            // resize image
            $this->resize($fileName);
        }

        return $this->response->collection(
            $this->repository->findWhereIn('id', $photoId),
            $this->getTransformer(),
            $this->getKey()
        );
    }

    /**
     * @param $filename
     * @return string|void
     */
    public function getUrl($filename)
    {
        // Retrieve file from Storage
        if (Storage::disk('local')->exists($this->storagePath.$filename)) {
            return $this->response->array([
                'path' => secure_asset($this->storagePath.$filename),
            ]);
        }

        return $this->response->errorNotFound();
    }

    /**
     * @param $fileName
     * @param int $width
     * @param int $height
     * @return mixed
     */
    private function resize($fileName, $width = 300, $height = 300)
    {
        $imagePath = $this->storagePath.$fileName;
        $image = Image::make(Storage::get($imagePath))->resize($width, $height)->encode();
        Storage::put($imagePath, $image);
        return true;
    }
}
