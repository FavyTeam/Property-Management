<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ApplicationRepository as Application;
use App\Repositories\Criteria\Application\MoveDateRange;
use App\Repositories\Criteria\Application\MoveDateIsNull;
use Input;


class ApplicationController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'applications';

    public function __construct(Application $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // criteria
        if (Input::get('moveDateRange')) {
            $this->repository->pushCriteria(new MoveDateRange(Input::get('moveDateRange')));
        }

        if (Input::get('moveDateNull')) {
            $this->repository->pushCriteria(new MoveDateIsNull());
        }

        return parent::index();
    }
}
