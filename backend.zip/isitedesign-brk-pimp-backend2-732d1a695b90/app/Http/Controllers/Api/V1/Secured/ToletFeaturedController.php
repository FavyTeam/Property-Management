<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ToletFeaturedRepository as ToletFeatured;


class ToletFeaturedController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'toletfeatures';

    public function __construct(ToletFeatured $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
