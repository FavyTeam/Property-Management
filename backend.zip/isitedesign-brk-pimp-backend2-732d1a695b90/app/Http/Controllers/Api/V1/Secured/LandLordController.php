<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\LandLordRepository as LandLord;
use App\Repositories\Criteria\Common\LordRefIsNotNull;
use App\Repositories\Criteria\Common\FindByLordRef;
use App\Http\Requests\V1\LandLord\StoreRequest;
use App\Http\Requests\V1\LandLord\UpdateRequest;
use Input;


class LandLordController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'landlords';

    public function __construct(LandLord $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }

    /**
     * store()
     *
     * @param null $data
     * @return \Dingo\Api\Http\Response|void
     */
    public function store($data = null)
    {
        return parent::store(['lordRef' => $this->repository->generateLordRef(Input::get('surName'), Input::get('foreName'))]);
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        if (Input::get('lordRef')) {
            $this->repository->pushCriteria(new FindByLordRef(Input::get('lordRef')));
        }

        return parent::index();
    }
}
