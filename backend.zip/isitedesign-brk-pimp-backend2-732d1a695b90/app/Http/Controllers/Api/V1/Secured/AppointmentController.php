<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\AppointmentRepository as Appointment;
use App\Repositories\Criteria\Common\FindByPropRef;
use App\Repositories\Criteria\Appointment\FilterByDate;
use App\Http\Requests\V1\Appointment\StoreRequest;
use Input;


class AppointmentController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'appointments';

    protected $relations = [
        'property',
    ];

    public function __construct(Appointment $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        if (Input::get('propRef')) {
            $this->repository->pushCriteria(new FindByPropRef(Input::get('propRef')));
        }

        if (Input::get('date')) {
            $this->repository->pushCriteria(new FilterByDate(Input::get('date')));
        }

        return parent::index();
    }
}
