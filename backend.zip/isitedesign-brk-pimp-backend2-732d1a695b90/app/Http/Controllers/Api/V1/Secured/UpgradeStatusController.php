<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\UpgradeStatusRepository as UpgradeStatus;


class UpgradeStatusController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'upgradestatuses';

    public function __construct(UpgradeStatus $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
