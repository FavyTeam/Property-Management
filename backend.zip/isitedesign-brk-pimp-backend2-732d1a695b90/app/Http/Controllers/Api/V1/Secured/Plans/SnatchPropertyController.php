<?php

namespace App\Http\Controllers\Api\V1\Secured\Plans;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\Plans\SnatchPropertyRepository as SnatchProperty;
use App\Repositories\Criteria\PlanProperty\SnatchOnly;
use App\Repositories\Criteria\PlanProperty\AllByPlanId;
use Input;


class SnatchPropertyController extends Controller
{
    /**
     * @var string
     */
    protected $sortBy = 'planproperties.id';

    /**
     * @var array
     */
    protected $relations = ['area'];

    /**
     * @var string
     */
    protected $key = 'snatchproperties';

    /**
     * @var array
     */
    protected $fields = ['planproperties.*'];

    public function __construct(SnatchProperty $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // Push SnatchOnly criteria to the repo
        $this->repository->pushCriteria(new SnatchOnly());

        if (Input::get('planId')) {
            $this->repository->pushCriteria(new AllByPlanId(Input::get('planId')));
        }

        return parent::index();
    }
}
