<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectCategoryRepository as ProspectCategory;


class ProspectCategoryController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospectcategories';

    public function __construct(ProspectCategory $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
