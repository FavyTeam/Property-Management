<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\LandAgentRepository as LandAgent;


class LandAgentController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'landagents';

    public function __construct(LandAgent $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
