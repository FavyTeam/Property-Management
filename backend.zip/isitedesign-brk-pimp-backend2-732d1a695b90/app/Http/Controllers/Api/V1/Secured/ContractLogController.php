<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ContractLogRepository as ContractLog;


class ContractLogController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'contractlogs';

    public function __construct(ContractLog $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
