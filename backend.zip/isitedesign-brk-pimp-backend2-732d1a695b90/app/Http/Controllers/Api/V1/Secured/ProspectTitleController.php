<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectTitleRepository as ProspectTitle;


class ProspectTitleController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospecttitles';

    public function __construct(ProspectTitle $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
