<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\MaintBlockLogRepository as MaintBlockLog;


class MaintBlockLogController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'maintblocklogs';

    public function __construct(MaintBlockLog $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
