<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ContractRepository as Contract;


class ContractController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'contracts';

    public function __construct(Contract $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
