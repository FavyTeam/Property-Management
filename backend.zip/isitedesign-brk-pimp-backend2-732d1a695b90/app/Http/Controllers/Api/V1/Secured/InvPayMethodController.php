<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\InvPayMethodRepository as InvPayMethod;


class InvPayMethodController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'invpaymethods';

    public function __construct(InvPayMethod $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
