<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\NewPropertyRepository as NewProperty;
use App\Repositories\Criteria\Common\LordRefIsNotNull;
use App\Repositories\Criteria\Property\Tolet;
use App\Repositories\Criteria\Property\FilterByBedrooms;
use App\Repositories\Criteria\Property\FilterByArea;
use App\Repositories\Criteria\Property\LessThanOrEqualToRent;
use App\Repositories\Criteria\Property\IsDogOk;
use App\Repositories\Criteria\Property\IsCatOk;
use App\Repositories\Criteria\Property\CanSmoke;
use App\Repositories\Criteria\Property\IsSharers;
use App\Repositories\Criteria\Property\IsFurnished;
use App\Repositories\Criteria\Property\HasGarage;
use App\Repositories\Criteria\Property\HasDriveway;
use App\Repositories\Criteria\Property\HasAppliances;
use App\Repositories\Criteria\Property\HasGarden;
use App\Repositories\Criteria\Property\IsDetached;
use App\Repositories\Criteria\Property\GreaterThanOrEqualToParking;
use App\Repositories\Criteria\Property\IsUpperFloor;
use App\Repositories\Criteria\Property\IsGroundFloor;
use App\Http\Requests\V1\Property\StoreRequest;
use App\Http\Requests\V1\Property\UpdateRequest;
use App\Repositories\Criteria\Common\FindByPropRef;
use App\Repositories\Criteria\Property\IsTolet;
use App\Repositories\Criteria\Property\HasAppointments;
use App\Repositories\Criteria\Common\FindByPropRefs;
use Input;


class NewPropertyController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'newproperties';

    /**
     * @var array
     */
    protected $fields = ['newproperties.*'];

    /**
     * @var array
     */
    protected $relations = [
        'primaryPhoto',
        'appointments',
    ];

    public function __construct(NewProperty $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        // criteria
        $this->repository->pushCriteria(new LordRefIsNotNull());

        if (Input::get('tolet') && ((int) Input::get('tolet')) === 1) {
            $this->fields = ['newproperties.*'];
            $this->repository->pushCriteria(new Tolet());
        }

        if (Input::has('bedrooms')) {
            $this->repository->pushCriteria(new FilterByBedrooms(Input::get('bedrooms')));
        }

        if (Input::has('area')) {
            $this->repository->pushCriteria(new FilterByArea(Input::get('area')));
        }

        if (Input::has('rent')) {
            $this->repository->pushCriteria(new LessThanOrEqualToRent(Input::get('rent')));
        }

        if (Input::get('dogs')) {
            $this->repository->pushCriteria(new IsDogOk());
        }

        if (Input::get('cats')) {
            $this->repository->pushCriteria(new IsCatOk());
        }

        if (Input::get('smokers')) {
            $this->repository->pushCriteria(new CanSmoke());
        }

        if (Input::get('sharers')) {
            $this->repository->pushCriteria(new IsSharers());
        }

        if (Input::get('furnished')) {
            $this->repository->pushCriteria(new IsFurnished());
        }

        if (Input::get('garage')) {
            $this->repository->pushCriteria(new HasGarage());
        }

        if (Input::get('driveway')) {
            $this->repository->pushCriteria(new HasDriveway());
        }

        if (Input::get('appliances')) {
            $this->repository->pushCriteria(new HasAppliances());
        }

        if (Input::get('garden')) {
            $this->repository->pushCriteria(new HasGarden());
        }

        if (Input::get('detached')) {
            $this->repository->pushCriteria(new IsDetached());
        }

        if (Input::has('parkingFor')) {
            $this->repository->pushCriteria(new GreaterThanOrEqualToParking (Input::get('parkingFor')));
        }

        if (Input::get('upperFloor')) {
            $this->repository->pushCriteria(new IsUpperFloor());
        }

        if (Input::get('groundFloor')) {
            $this->repository->pushCriteria(new IsGroundFloor());
        }

        if (Input::has('propRef')) {
            $this->repository->pushCriteria(new FindByPropRef(Input::get('propRef')));
        }

        if (Input::get('istolet')) {
            $this->repository->pushCriteria(new IsTolet(Input::get('istolet')));
        }

        if (Input::get('hasappointments')) {
            $this->repository->pushCriteria(new IsAppointment(Input::get('hasappointments')));
        }

        if (Input::has('propRefs')) {
            $this->repository->pushCriteria(new FindByPropRefs(Input::get('propRefs')));
        }

        return parent::index();
    }
}
