<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\NewProspectPayRepository as NewProspectPay;


class NewProspectPayController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'newprospectpays';

    public function __construct(NewProspectPay $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
