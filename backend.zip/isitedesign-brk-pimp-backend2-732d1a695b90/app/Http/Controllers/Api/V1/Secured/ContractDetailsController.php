<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ContractDetailsRepository as ContractDetails;


class ContractDetailsController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'contractdetails';

    public function __construct(ContractDetails $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
