<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\RentRepository as Rent;


class RentController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'rents';

    public function __construct(Rent $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
