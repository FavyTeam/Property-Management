<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\InvoiceTemplateRepository as InvoiceTemplate;


class InvoiceTemplateController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'invoicetemplates';

    public function __construct(InvoiceTemplate $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
