<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ContractHistoryRepository as ContractHistory;


class ContractHistoryController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'contracthistories';

    public function __construct(ContractHistory $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
