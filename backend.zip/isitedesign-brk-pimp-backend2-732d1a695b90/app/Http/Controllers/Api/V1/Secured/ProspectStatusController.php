<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectStatusRepository as ProspectStatus;


class ProspectStatusController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospectstatuses';

    public function __construct(ProspectStatus $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
