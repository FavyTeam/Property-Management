<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\LordBlockRepository as LordBlock;
use App\Repositories\Criteria\Common\FindByLordRef;
use Input;


class LordBlockController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'lordblocks';

    /**
     * @var string
     */
    protected $relations = ['blockBy', 'maintRef'];

    public function __construct(LordBlock $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        if (Input::get('lordRef')) {
            $this->repository->pushCriteria(new FindByLordRef(Input::get('lordRef')));
        }

        return parent::index();
    }
}
