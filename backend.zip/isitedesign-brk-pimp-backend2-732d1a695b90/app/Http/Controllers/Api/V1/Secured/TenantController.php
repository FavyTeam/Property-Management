<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\TenantRepository as Tenant;
use App\Repositories\Criteria\Tenant\NoContract;
use App\Repositories\Criteria\Common\FindByTentRef;
use Input;


class TenantController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'tenants';

    public function __construct(Tenant $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    public function index()
    {
        if (Input::get('nocontract')) {
            $this->repository->pushCriteria(new NoContract());
        }

        if (Input::get('tentRef')) {
            $this->repository->pushCriteria(new FindByTentRef(Input::get('tentRef')));
        }

        return parent::index();
    }
}
