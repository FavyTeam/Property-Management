<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ToletRepository as Tolet;


class ToletController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'tolets';

    public function __construct(Tolet $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
