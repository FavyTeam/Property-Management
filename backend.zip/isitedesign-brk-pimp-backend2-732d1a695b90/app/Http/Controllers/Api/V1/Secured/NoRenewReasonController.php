<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\NoRenewReasonRepository as NoRenewReason;


class NoRenewReasonController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'newrenewreasons';

    public function __construct(NoRenewReason $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
