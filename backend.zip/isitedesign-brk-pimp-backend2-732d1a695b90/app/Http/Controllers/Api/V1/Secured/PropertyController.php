<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\PropertyRepository as Property;


class PropertyController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'properties';

    public function __construct(Property $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
