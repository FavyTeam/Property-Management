<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\InvoiceRepository as Invoice;


class InvoiceController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'invoices';

    public function __construct(Invoice $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
