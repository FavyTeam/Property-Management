<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\SourceRepository as Source;
use App\Repositories\Criteria\Source\ByIds;
use Input;


class SourceController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'sources';

    public function __construct(Source $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }

    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        if (Input::has('sourceIds')) {
            $this->repository->pushCriteria(new ByIds(Input::get('sourceIds')));
        }

        return parent::index();
    }
}
