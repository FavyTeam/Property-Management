<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\ProspectRepository as Prospect;
use App\Http\Requests\V1\Prospect\StoreRequest;


class ProspectController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'prospects';

    public function __construct(Prospect $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;

        // Call mom!
        parent::__construct();
    }
}
