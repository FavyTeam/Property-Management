<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\AreaRepository as Area;


class AreaController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'areas';

    public function __construct(Area $repository)
    {
        $this->repository = $repository;

        // Call mom!
        parent::__construct();
    }
}
