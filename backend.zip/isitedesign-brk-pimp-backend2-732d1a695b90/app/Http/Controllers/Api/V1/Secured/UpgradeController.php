<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Http\Requests\V1\Upgrade\StoreRequest;
use App\Http\Requests\V1\Upgrade\UpdateRequest;
use App\Repositories\Eloquent\UpgradeRepository as Upgrade;


class UpgradeController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'upgrades';

    /**
     * @var array
     */
    protected $relations = [
        'property',
    ];

    public function __construct(Upgrade $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        $this->updateRequest = UpdateRequest::class;

        // Call mom!
        parent::__construct();
    }
}
