<?php

namespace App\Http\Controllers\Api\V1\Secured;

use App\Http\Controllers\Api\V1\Controller;
use App\Repositories\Eloquent\LettingAgentRepository as LettingAgent;
use App\Http\Requests\V1\LettingAgent\StoreRequest;

class LettingAgentController extends Controller
{
    /**
     * @var string
     */
    protected $key = 'lettingagents';

    public function __construct(LettingAgent $repository)
    {
        $this->repository = $repository;
        $this->storeRequest = StoreRequest::class;
        parent::__construct();
    }
}
