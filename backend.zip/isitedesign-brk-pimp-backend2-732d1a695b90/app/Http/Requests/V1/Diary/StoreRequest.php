<?php

namespace App\Http\Requests\V1\Diary;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'bookedBy' => 'required',
            'bookedDate' => 'required',
            'bookedTime' => 'required',
            'date' => 'required',
            'time' => 'required',
            'someType' => 'required',
            'for' => 'required',
            'propRef' => 'required',
            'name' => 'required',
            'prospect' => 'required',
            'address' => 'required',
            'area' => 'required',
        ];
    }
}
