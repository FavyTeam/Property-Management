<?php

namespace App\Http\Requests\V1\LettingAgent;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'companyName' => 'required',
            'title' => 'required',
            'foreName' => 'required',
            'surName' => 'required',
            'address1' => 'required',
            'postcode' => 'required',
            'phoneWork' => 'required',
            'phoneMobile' => 'required',
            'email' => 'required|email',
            'charge' => 'required|numeric'
        ];
    }

}
