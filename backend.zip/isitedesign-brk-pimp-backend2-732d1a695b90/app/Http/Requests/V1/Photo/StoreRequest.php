<?php

namespace App\Http\Requests\V1\Photo;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $rules = [
            'propRef' => 'required|max:10',
            'photo' => 'image|mimes:jpeg,bmp,png|max:2000',
        ];
        $photos = count($this->file('photos'));
        // multiple upload rules for photos
        foreach (range(0, $photos) as $index) {
            $rules['photos.'.$index] = 'image|mimes:jpeg,bmp,png|max:2000';
        }

        return $rules;
    }
}
