<?php

namespace App\Http\Requests\V1\Contract;

use Dingo\Api\Http\FormRequest;
use Carbon\Carbon;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $start = Carbon::parse($this->get('termFrom'));
        $end = $start->addMonth(6);

        return [
            'tentRef' => 'required|unique:newcontracts,tent_ref',
            'drawnUp' => 'required|date|date_format:Y-m-d',
            'rentIncreaseDate' => 'required|date|date_format:Y-m-d',
            'termFrom' => 'required|date|date_format:Y-m-d|before:termTo',
            'termTo' => 'required|date|date_format:Y-m-d|after_or_equal:' . $end,
            'rent' => 'required|numeric|min: 1',
            'payMethod' => 'required',
            'payDay' => 'required|numeric|in:'.$start->day,
            'newRent' => 'required|numeric|min: 1',
            'propRef' => 'required|max:10|unique:newcontracts,prop_ref'
        ];
    }

    public function messages()
    {
        return [
            'payDay.in' => 'Pay Day must be the same  as the Start Date (Day of Month)',
        ];
    }
}
