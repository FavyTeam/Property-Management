<?php

namespace App\Http\Requests\V1\Prospect;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'payment' => 'required',
            'hbChecked' => 'required',
            'moneyOk' => 'required',
            'title' => 'required',
            'foreName' => 'required',
            'lastName' => 'required',
            'email' => 'required',
            'phoneMobile' => 'required',
            'source' => 'required',
            'currentStatus' => 'required',
            'noAdults' => 'required|min:1',
            'ageRange' => 'required',
            'guarantorOk' => 'required',
            'noPets' => 'required',
            'moveDate' => 'required',
            'minBeds' => 'required',
            'maxRent' => 'required',
            'parkingForText' => 'required'
        ];
    }
}
