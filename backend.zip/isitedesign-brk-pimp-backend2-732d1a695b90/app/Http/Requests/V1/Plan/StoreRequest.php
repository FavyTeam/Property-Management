<?php

namespace App\Http\Requests\V1\Plan;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'foreName' => 'required',
            'surName' => 'required',
            'addr1' => 'required',
            'addr2' => 'required',
            'addr3' => 'required',
            'addr4' => 'required',
            'postcode' => 'required',
            'telHome' => 'required',
            'telWork' => 'required',
            'email' => 'required|email|unique:plans,email',
        ];
    }
}
