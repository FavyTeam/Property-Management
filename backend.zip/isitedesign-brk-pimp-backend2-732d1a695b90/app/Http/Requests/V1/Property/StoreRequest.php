<?php

namespace App\Http\Requests\V1\Property;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'propRef' => 'required|max:10|unique:newproperties,PropertyRef',
            'accountType' => 'required',
            'addr1' => 'required',
            'addr2' => 'required',
            'addr3' => 'required',
            'addr4' => 'required',
            'postcode' => 'required',
            'area' => 'required',
            'lordRef' => 'required',
            'dateOn' => 'required',
            'takeOnBy' => 'required',
        ];
    }
}
