<?php

namespace App\Http\Requests\V1\Upgrade;

use Dingo\Api\Http\FormRequest;


class UpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'propRef' => 'required|unique:upgrades,Propertyref,'.$this->route('upgrade'),
        ];
    }
}