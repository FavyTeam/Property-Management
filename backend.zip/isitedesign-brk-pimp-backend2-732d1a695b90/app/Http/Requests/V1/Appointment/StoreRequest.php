<?php

namespace App\Http\Requests\V1\Appointment;

use Dingo\Api\Http\FormRequest;


class StoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'time' => 'required',
            'whoDoing' => 'required',
            'appSource' => 'required',
        ];
    }
}
