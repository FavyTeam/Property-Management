<?php

namespace App\Http\Requests\V2;

use Dingo\Api\Http\FormRequest;

Class TokenStoreRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'username' => 'required',
            'password' => 'required'
        ];
    }

}
