<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class InvPayMethod extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'invpaymethods';

    /**
     * @var null
     */
    protected static $fields = null;
}
