<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class InvoiceTemplate extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'invoicestemplate';

    /**
     * @var array
     */
    protected $hidden = [
        'idNo',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}
