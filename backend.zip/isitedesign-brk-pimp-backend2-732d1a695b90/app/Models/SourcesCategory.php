<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class SourcesCategory extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'sourcescategory';

    /**
     * @var null
     */
    protected static $fields = null;
}
