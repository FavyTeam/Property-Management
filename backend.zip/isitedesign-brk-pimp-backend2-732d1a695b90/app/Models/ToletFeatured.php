<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ToletFeatured extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'toletfeatured';

    /**
     * @var null
     */
    protected static $fields = null;
}
