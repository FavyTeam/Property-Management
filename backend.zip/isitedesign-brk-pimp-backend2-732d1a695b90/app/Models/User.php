<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class User extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'users';

    /**
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}