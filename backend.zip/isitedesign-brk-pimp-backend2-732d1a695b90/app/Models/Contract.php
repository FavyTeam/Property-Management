<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Contract extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'contracts';

    /**
     * @var null
     */
    protected static $fields = null;
}
