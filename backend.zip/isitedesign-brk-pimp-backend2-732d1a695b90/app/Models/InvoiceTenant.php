<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class InvoiceTenant extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'invoicestenant';

    /**
     * @var array
     */
    protected $hidden = [
        'invoiceIdNo',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}
