<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;
use Sofa\Eloquence\Eloquence; // base trait
use Sofa\Eloquence\Mappable; // extension trait
use Config, Input;
use Carbon\Carbon;


class BaseModel extends Authenticatable
{
    use HasApiTokens;
    use Notifiable;
    use Eloquence, Mappable;

    /**
     * @var array
     */
    protected $guarded = ['id'];

    /**
     * @var array|mixed
     */
    protected $maps = [];

    /**
     * @var array
     */
    protected $appends = [];

    /**
     * @var array
     */
    protected $appendsRequired = [
        'createdAt',
        'updatedAt',
    ];

    /**
     * @var array
     */
    protected $hidden = [];

    /**
     * @var array
     */
    protected $hiddenRequired = [
        'deletedAt',
    ];

    /**
     * @var bool
     */
    public static $snakeAttributes = false;

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    /**
     * BaseModel constructor.
     * @param array $attributes
     */
    public function __construct(array $attributes = [])
    {
        // Call mom!
        parent::__construct($attributes);

        // Get the key for mapping
        $key = Config::get('maps.mapkeys.' . get_class($this));

        // Quick fix for model that don't have mappable config file in config/maps
        if (null !== $key)
        {
            // maps
            $this->maps = array_merge(Config::get('maps.'.$key), Config::get('maps.default'));

            if (!Input::get('fields')) {
                // appends
                $this->appends = array_merge(array_keys($this->maps), $this->appendsRequired);

                // hidden
                $this->hidden = array_merge($this->hidden, array_values($this->maps), $this->hiddenRequired);
            }
        }
    }

    /**
     * Accessor for createdAt attribute
     *
     * @param $value
     * @return mixed
     */
    public function getCreatedAtAttribute($value)
    {
        return null !== $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value, Config::get('app.timezone'))->toRfc3339String() : $value;
    }

    /**
     * Accessor for updatedAt attribute
     *
     * @param $value
     * @return mixed
     */
    public function getUpdatedAtAttribute($value)
    {
        return null !== $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value, Config::get('app.timezone'))->toRfc3339String() : $value;
    }

    /**
     * Accessor for deletedAt attribute
     *
     * @param $value
     * @return mixed
     */
    public function getDeletedAtAttribute($value)
    {
        return null !== $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value, Config::get('app.timezone'))->toRfc3339String() : $value;
    }
}
