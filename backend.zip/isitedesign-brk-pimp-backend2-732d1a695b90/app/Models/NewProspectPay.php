<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class NewProspectPay extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'newprospectpay';

    /**
     * @var null
     */
    protected static $fields = null;
}