<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class PropertyPhoto extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'propertyphotos';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @param $value
     * @return string
     */
    public function getPathAttribute($value)
    {
        return secure_asset($value);
    }
}