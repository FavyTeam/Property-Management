<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Application extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'applications';

    /**
     * @var null
     */
    protected static $fields = null;
}
