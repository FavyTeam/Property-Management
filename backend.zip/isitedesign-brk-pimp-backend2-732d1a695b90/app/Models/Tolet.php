<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Tolet extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'tolet';

    /**
     * @var null
     */
    protected static $fields = null;
}
