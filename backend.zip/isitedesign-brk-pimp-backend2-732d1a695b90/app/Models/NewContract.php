<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class NewContract extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'newcontracts';

    /**
     * @var null
     */
    protected static $fields = null;
}
