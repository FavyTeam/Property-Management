<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Area extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'areas';

    /**
     * @var array
     */
    protected $hidden = [
        'areaIdNo',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}
