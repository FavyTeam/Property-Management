<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Diary extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'diary';

    /**
     * @var null
     */
    protected static $fields = null;

    public function newProperty()
    {
        return $this->belongsTo(NewProperty::class, 'PropRef', 'PropertyRef');
    }
}
