<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class UpgradeStatus extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'upgradestatus';

    /**
     * @var null
     */
    protected static $fields = null;
}
