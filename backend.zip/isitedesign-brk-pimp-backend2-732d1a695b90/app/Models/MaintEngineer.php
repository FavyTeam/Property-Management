<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class MaintEngineer extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'maintengineers';

    /**
     * @var array
     */
    protected $hidden = [
        'idNo',
    ];

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function blockedBy()
    {
        return $this->hasOne(User::class, 'id', 'BlockedBy');
    }
}