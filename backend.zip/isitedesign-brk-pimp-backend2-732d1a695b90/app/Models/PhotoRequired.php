<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class PhotoRequired extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'photosrequired';

    /**
     * @var null
     */
    protected static $fields = null;
}