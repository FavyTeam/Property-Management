<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class WaitList extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'waitlist';

    /**
     * @var null
     */
    protected static $fields = null;
}
