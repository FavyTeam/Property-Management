<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class PlanPropertyStatus extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'planpropertystatus';

    /**
     * @var null
     */
    protected static $fields = null;
}
