<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class TenantNote extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'tenantnotes';

    /**
     * @var null
     */
    protected static $fields = null;
}
