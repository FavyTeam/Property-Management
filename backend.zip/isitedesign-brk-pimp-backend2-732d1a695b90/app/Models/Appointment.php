<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Appointment extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'appointments';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function property()
    {
        return $this->hasOne(NewProperty::class, 'PropertyRef', 'PropRef');
    }
}
