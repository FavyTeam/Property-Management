<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ContractHistory extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'contracthistory';

    /**
     * @var null
     */
    protected static $fields = null;
}
