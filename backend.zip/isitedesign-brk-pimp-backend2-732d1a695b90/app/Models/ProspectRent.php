<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ProspectRent extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'prospectsrent';

    /**
     * @var null
     */
    protected static $fields = null;
}
