<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Plan extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'plans';

    /**
     * @var array
     */
    protected $hidden = [
        '_2addr1',
        '_2addr2',
        '_2addr3',
        '_2addr4',
        '_2postcode',
    ];

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function addedBy()
    {
        return $this->hasOne(User::class, 'id', 'AddedBy');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function managedBy()
    {
        return $this->hasOne(User::class, 'id', 'Managedby');
    }
}
