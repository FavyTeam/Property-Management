<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class NoRenewReason extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'norenewreason';

    /**
     * @var null
     */
    protected static $fields = null;
}