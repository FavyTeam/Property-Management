<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Furnishing extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'furnishings';

    /**
     * @var null
     */
    protected static $fields = null;
}
