<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Tenant extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'tenants';

    /**
     * @var null
     */
    protected static $fields = null;
}
