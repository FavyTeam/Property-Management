<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class LandAgent extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'landagents';

    /**
     * @var null
     */
    protected static $fields = null;
}
