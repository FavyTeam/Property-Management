<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Applicant extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'applicants';

    /**
     * @var null
     */
    protected static $fields = null;
}
