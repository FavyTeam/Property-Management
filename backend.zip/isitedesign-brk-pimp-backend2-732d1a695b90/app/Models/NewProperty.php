<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class NewProperty extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'newproperties';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function primaryPhoto()
    {
        return $this->hasOne(PropertyPhoto::class, 'PropertyRef', 'PropertyRef')
                    ->where('isPrimary', 1);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function photos()
    {
        return $this->hasMany(PropertyPhoto::class, 'PropertyRef', 'PropertyRef');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function applicants()
    {
        return $this->hasMany(Applicant::class, 'PropertyRef', 'PropertyRef');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function areas()
    {
        return $this->hasOne(Area::class, 'id', 'area');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function furnishing()
    {
        return $this->hasOne(Furnishing::class, 'id', 'furnished');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function appointments()
    {
        return $this->hasMany(Appointment::class, 'PropRef', 'PropertyRef');
    }
}
