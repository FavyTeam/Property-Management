<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class MaintBlockLog extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'maintblocklog';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @var array
     */
    protected $hidden = [
        'idNo',
    ];
}