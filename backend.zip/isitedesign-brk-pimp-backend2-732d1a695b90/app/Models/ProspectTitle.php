<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ProspectTitle extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'prospectstitle';

    /**
     * @var null
     */
    protected static $fields = null;
}
