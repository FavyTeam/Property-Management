<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class LettingAgent extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'lettingagents';

    /**
     * @var null
     */
    protected static $fields = null;
}
