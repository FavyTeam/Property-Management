<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ContractDetails extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'contractdetails';

    /**
     * @var null
     */
    protected static $fields = null;
}
