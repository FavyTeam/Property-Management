<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class RentLetter extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'rentletters';

    /**
     * @var null
     */
    protected static $fields = null;
}
