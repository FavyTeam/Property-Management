<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Source extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'sources';

    /**
     * @var null
     */
    protected static $fields = null;
}
