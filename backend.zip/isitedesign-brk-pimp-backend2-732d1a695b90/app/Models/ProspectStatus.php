<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ProspectStatus extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'newprospectstatus';

    /**
     * @var null
     */
    protected static $fields = null;
}