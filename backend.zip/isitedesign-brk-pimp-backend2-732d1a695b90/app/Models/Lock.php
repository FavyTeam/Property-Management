<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Lock extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'lock';

    /**
     * @var null
     */
    protected static $fields = null;
}
