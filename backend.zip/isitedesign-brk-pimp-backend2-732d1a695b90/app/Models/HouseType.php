<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class HouseType extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'housetypes';

    /**
     * @var array
     */
    protected $hidden = [
        'webId',
        'rightMoveId',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}
