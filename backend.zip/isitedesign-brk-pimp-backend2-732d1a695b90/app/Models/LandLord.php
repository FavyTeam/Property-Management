<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class LandLord extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'landlords';

    /**
     * @var array
     */
    protected $hidden = [
        'idCheckedBy',
    ];

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function checkedBy()
    {
        return $this->hasOne(User::class, 'id', 'IDCheckedBy');
    }
}
