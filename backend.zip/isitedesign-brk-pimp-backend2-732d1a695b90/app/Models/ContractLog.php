<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ContractLog extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'contractlog';

    /**
     * @var null
     */
    protected static $fields = null;
}
