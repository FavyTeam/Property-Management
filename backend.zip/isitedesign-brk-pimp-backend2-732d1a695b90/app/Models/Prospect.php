<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Prospect extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'prospects';

    /**
     * @var null
     */
    protected static $fields = null;
}
