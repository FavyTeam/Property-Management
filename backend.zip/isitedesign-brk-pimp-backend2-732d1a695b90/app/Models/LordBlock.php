<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class LordBlock extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'lordblock';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function blockBy()
    {
        return $this->hasOne(User::class, 'id', 'Blockby');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function maintRef()
    {
        return $this->hasOne(MaintEngineer::class, 'id', 'Maintref');
    }
}