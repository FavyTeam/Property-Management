<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class AreaGroups extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'areagroups';

    /**
     * @var null
     */
    protected static $fields = null;
}
