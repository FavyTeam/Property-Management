<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Country extends BaseModel
{    
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'countries';

    /**
     * @var null
     */
    protected static $fields = null;
}
