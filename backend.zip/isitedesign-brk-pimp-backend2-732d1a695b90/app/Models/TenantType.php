<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class TenantType extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'tenanttype';

    /**
     * @var null
     */
    protected static $fields = null;
}
