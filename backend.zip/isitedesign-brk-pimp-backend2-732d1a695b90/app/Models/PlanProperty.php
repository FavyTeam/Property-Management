<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class PlanProperty extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'planproperties';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function area()
    {
        return $this->hasOne(Area::class, 'id', 'Area');
    }
}
