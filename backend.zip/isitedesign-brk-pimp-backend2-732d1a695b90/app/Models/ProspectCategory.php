<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ProspectCategory extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'prospectcategory';

    /**
     * @var null
     */
    protected static $fields = null;
}
