<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Invoice extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'invoicesll';

    /**
     * @var array
     */
    protected $hidden = [
        'invoiceIdNo',
    ];

    /**
     * @var null
     */
    protected static $fields = null;
}
