<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Property extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'properties';

    /**
     * @var null
     */
    protected static $fields = null;
}
