<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class Upgrade extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'upgrades';

    /**
     * @var null
     */
    protected static $fields = null;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function property()
    {
        return $this->hasOne(NewProperty::class, 'PropertyRef', 'Propertyref');
    }
}
