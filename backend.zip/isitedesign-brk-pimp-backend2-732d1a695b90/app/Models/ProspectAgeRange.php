<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class ProspectAgeRange extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'prospectsagerange';

    /**
     * @var null
     */
    protected static $fields = null;
}