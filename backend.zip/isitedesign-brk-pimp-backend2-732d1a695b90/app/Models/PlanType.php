<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class PlanType extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'plantypes';

    /**
     * @var null
     */
    protected static $fields = null;
}
