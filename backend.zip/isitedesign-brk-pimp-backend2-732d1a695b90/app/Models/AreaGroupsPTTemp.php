<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;


class AreaGroupsPTTemp extends BaseModel
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'areagroupspttemp';

    /**
     * @var null
     */
    protected static $fields = null;
}
