<?php

namespace App\Traits;

use App\Repositories\Criteria\Common\SearchBy as Search;
use Response;
use Input;


trait Resource
{
    /**
     * Display a listing of the resource
     *
     * @return Response
     */
    public function index()
    {
        $this->sort();

        if (null !== $this->relations) $this->repository->with($this->relations);

        $responseType = 'collection';

        if (Input::get('search') && Input::get('q')) {
            // Push searchBy criteria to the repo
            $this->repository->pushCriteria(new Search(Input::get('search'), Input::get('q')));
        }

        if ($this->paginate) {
            $resource = $this->repository->paginate($this->perPage, $this->fields);
            $responseType = 'paginator';
        } else {
            $resource = $this->repository->all($this->fields);
        }

        return $this->response->{$responseType}(
            $resource,
            $this->getTransformer(),
            $this->getKey()
        );
    }

    /**
     * Display the specified resource.
     *
     * @param string $id
     * @return Response
     */
    public function show($id)
    {
        if (null !== $this->relations) $this->repository->with($this->relations);

        $resource = $this->repository->find($id);

        if (!$resource) {
            return $this->response->errorNotFound();
        }

        return $this->response->item(
            $this->repository->find($id),
            $this->getTransformer(),
            $this->getKey()
        );
    }

    /**
     * @param array $data
     * @return \Dingo\Api\Http\Response|void
     */
    public function store($data = null)
    {
        if (null !== $this->storeRequest) app($this->storeRequest);

        // Check if we have data submitted via POST
        $input = Input::get() ?: [];

        // Check if we have data submitted via LOCAL args
        $local = $data ?: [];

        // merge model attributes to be created
        $data = array_merge($input, $local);

        $id = $this->repository->create($data);

        return $this->response->item(
            $this->repository->find($id),
            $this->getTransformer(),
            $this->getKey()
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param string $id
     * @return Response
     */
    public function update($id)
    {
        if (null !== $this->updateRequest) app($this->updateRequest);

        $this->repository->update(Input::get(), $id);

        return $this->response->item(
            $this->repository->find($id),
            $this->getTransformer(),
            $this->getKey()
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param string $id
     * @return Response
     */
    public function destroy($id)
    {
        $this->repository->delete($id);
        return Response::make('', 204);
    }

    /**
     * @return mixed
     */
    public function getTransformer()
    {
        return new $this->transformer();
    }

    /**
     * @return array
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * @param void
     * @return void
     */
    public function sort()
    {
        if (Input::get('orders')) {
            $orders = Input::get('orders');
            foreach ($orders as $order) {
                $this->repository->orderBy($order[0], $order[1]);
            }
        } else {
            if (!empty($this->sortBy) && !empty($this->sortOrder)) {
                $this->repository->orderBy($this->sortBy, $this->sortOrder);
            }
        }
    }
}

