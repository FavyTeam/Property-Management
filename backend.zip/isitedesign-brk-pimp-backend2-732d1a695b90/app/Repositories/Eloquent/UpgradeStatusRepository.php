<?php

namespace App\Repositories\Eloquent;

use App\Models\UpgradeStatus;


class UpgradeStatusRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return UpgradeStatus::class;
    }
}