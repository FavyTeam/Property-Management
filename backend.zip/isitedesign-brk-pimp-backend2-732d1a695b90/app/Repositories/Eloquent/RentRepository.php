<?php

namespace App\Repositories\Eloquent;

use App\Models\RentIncrease;


class RentRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return RentIncrease::class;
    }
}