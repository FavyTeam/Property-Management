<?php

namespace App\Repositories\Eloquent;

use App\Models\ContractLog;


class ContractLogRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ContractLog::class;
    }
}