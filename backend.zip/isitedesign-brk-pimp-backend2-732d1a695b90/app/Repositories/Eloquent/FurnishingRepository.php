<?php

namespace App\Repositories\Eloquent;

use App\Models\Furnishing;


class FurnishingRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Furnishing::class;
    }
}