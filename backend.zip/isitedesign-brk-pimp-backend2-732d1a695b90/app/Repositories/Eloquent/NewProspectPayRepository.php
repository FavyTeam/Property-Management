<?php

namespace App\Repositories\Eloquent;

use App\Models\NewProspectPay;


class NewProspectPayRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return NewProspectPay::class;
    }
}