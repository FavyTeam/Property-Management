<?php

namespace App\Repositories\Eloquent;

use App\Models\HouseType;


class HouseTypeRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return HouseType::class;
    }
}