<?php

namespace App\Repositories\Eloquent;

use App\Models\NoRenewReason;


class NoRenewReasonRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return NoRenewReason::class;
    }
}