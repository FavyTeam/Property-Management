<?php

namespace App\Repositories\Eloquent;

use Illuminate\Support\Str;
use App\Repositories\Contracts\Contract\ContractInterface;
use App\Models\NewContract;


class NewContractRepository extends Repository implements ContractInterface
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return NewContract::class;
    }

    public function generateContRef()
    {
        return ((int) $this->model->max('cont_ref')) + 1;
    }
}