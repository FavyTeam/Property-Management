<?php

namespace App\Repositories\Eloquent;

use App\Models\Tenant;


class TenantRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Tenant::class;
    }
}