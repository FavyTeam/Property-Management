<?php

namespace App\Repositories\Eloquent;

use App\Models\Area;


class AreaRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Area::class;
    }
}