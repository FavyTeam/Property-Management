<?php

namespace App\Repositories\Eloquent;

use App\Models\ProspectAgeRange;


class ProspectAgeRangeRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ProspectAgeRange::class;
    }
}
