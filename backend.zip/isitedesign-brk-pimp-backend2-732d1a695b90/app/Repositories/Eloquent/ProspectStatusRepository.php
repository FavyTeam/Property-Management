<?php

namespace App\Repositories\Eloquent;

use App\Models\ProspectStatus;


class ProspectStatusRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ProspectStatus::class;
    }
}
