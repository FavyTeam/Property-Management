<?php

namespace App\Repositories\Eloquent;

use App\Models\Applicant;


class ApplicantRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Applicant::class;
    }
}