<?php

namespace App\Repositories\Eloquent;

use App\Models\NewProperty;


class NewPropertyRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return NewProperty::class;
    }
}