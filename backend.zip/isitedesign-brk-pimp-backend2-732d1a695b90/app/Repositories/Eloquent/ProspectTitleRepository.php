<?php

namespace App\Repositories\Eloquent;

use App\Models\ProspectTitle;


class ProspectTitleRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ProspectTitle::class;
    }
}
