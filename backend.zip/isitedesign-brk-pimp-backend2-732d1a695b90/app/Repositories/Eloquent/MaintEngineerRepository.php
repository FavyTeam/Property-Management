<?php

namespace App\Repositories\Eloquent;

use App\Models\MaintEngineer;


class MaintEngineerRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return MaintEngineer::class;
    }
}