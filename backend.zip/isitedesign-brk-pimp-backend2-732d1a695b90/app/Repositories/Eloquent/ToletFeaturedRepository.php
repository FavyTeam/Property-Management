<?php

namespace App\Repositories\Eloquent;

use App\Models\ToletFeatured;


class ToletFeaturedRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ToletFeatured::class;
    }
}