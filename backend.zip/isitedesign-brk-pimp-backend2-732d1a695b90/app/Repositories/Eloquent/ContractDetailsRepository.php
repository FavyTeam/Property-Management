<?php

namespace App\Repositories\Eloquent;

use App\Models\ContractDetails;


class ContractDetailsRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ContractDetails::class;
    }
}