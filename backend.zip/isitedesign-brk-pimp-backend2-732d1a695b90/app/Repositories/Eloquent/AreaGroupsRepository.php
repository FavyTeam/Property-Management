<?php

namespace App\Repositories\Eloquent;

use App\Models\AreaGroups;


class AreaGroupsRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return AreaGroups::class;
    }
}
