<?php

namespace App\Repositories\Eloquent;

use App\Models\Application;


class ApplicationRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Application::class;
    }
}