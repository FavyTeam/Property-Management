<?php

namespace App\Repositories\Eloquent;

use App\Models\InvoiceTenant;


class InvoiceTenantRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return InvoiceTenant::class;
    }
}