<?php

namespace App\Repositories\Eloquent;

use App\Models\Plan;


class PlanRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Plan::class;
    }
}