<?php

namespace App\Repositories\Eloquent;

use App\Models\Prospect;


class ProspectRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Prospect::class;
    }
}
