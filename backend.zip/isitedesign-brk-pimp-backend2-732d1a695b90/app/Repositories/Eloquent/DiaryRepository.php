<?php

namespace App\Repositories\Eloquent;

use App\Models\Diary;


class DiaryRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Diary::class;
    }
}
