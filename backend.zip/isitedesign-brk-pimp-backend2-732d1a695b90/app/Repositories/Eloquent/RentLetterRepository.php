<?php

namespace App\Repositories\Eloquent;

use App\Models\RentLetter;


class RentLetterRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return RentLetter::class;
    }
}