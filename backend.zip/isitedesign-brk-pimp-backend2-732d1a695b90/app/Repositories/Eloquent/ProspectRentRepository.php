<?php

namespace App\Repositories\Eloquent;

use App\Models\ProspectRent;


class ProspectRentRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ProspectRent::class;
    }
}
