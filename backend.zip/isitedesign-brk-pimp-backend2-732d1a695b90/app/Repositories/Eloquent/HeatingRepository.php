<?php

namespace App\Repositories\Eloquent;

use App\Models\Heating;


class HeatingRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Heating::class;
    }
}