<?php

namespace App\Repositories\Eloquent;

use App\Models\PhotoRequired;


class PhotoRequiredRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return PhotoRequired::class;
    }
}