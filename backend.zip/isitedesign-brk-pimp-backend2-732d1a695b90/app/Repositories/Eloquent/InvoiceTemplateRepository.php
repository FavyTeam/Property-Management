<?php

namespace App\Repositories\Eloquent;

use App\Models\InvoiceTemplate;


class InvoiceTemplateRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return InvoiceTemplate::class;
    }
}