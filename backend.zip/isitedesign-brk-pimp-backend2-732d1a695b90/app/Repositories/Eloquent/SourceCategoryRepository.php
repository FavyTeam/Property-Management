<?php

namespace App\Repositories\Eloquent;

use App\Models\SourcesCategory;


class SourceCategoryRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return SourcesCategory::class;
    }
}
