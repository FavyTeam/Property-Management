<?php

namespace App\Repositories\Eloquent;

use App\Models\Source;


class SourceRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Source::class;
    }
}
