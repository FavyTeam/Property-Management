<?php

namespace App\Repositories\Eloquent;

use App\Models\Contract;


class ContractRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Contract::class;
    }
}