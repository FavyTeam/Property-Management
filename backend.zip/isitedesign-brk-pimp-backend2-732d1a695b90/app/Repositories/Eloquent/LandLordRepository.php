<?php

namespace App\Repositories\Eloquent;

use App\Repositories\Contracts\LandLord\LandLordInterface;
use App\Models\LandLord;


class LandLordRepository extends Repository implements LandLordInterface
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return LandLord::class;
    }

    public function generateLordRef($surName, $foreName)
    {
        $lordRef = strtoupper(trim_string($surName, 3).trim_string($foreName, 3));

        // finalize
        $lordRef .= ($this->model->where('lordRef', 'LIKE', $lordRef.'%')->count() + 1);

        return $lordRef;
    }
}