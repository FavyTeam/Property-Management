<?php

namespace App\Repositories\Eloquent;

use App\Models\Appointment;


class AppointmentRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return Appointment::class;
    }
}