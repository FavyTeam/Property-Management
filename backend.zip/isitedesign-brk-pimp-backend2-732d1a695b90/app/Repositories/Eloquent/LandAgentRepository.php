<?php

namespace App\Repositories\Eloquent;

use App\Repositories\Contracts\LandLord\LandLordInterface;
use App\Models\LandAgent;


class LandAgentRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return LandAgent::class;
    }
}