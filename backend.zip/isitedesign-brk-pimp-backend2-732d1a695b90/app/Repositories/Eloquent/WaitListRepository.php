<?php

namespace App\Repositories\Eloquent;

use App\Models\WaitList;


class WaitListRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return WaitList::class;
    }
}