<?php

namespace App\Repositories\Eloquent;

use App\Models\LordBlock;


class LordBlockRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return LordBlock::class;
    }
}