<?php

namespace App\Repositories\Eloquent;

use App\Models\AreaGroupsPTTemp;


class AreaGroupsPTTempRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return AreaGroupsPTTemp::class;
    }
}
