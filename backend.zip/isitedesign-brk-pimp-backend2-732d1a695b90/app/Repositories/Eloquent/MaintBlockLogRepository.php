<?php

namespace App\Repositories\Eloquent;

use App\Models\MaintBlockLog;


class MaintBlockLogRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return MaintBlockLog::class;
    }
}