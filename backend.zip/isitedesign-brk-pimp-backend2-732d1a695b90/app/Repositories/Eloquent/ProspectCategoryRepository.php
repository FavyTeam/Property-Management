<?php

namespace App\Repositories\Eloquent;

use App\Models\ProspectCategory;


class ProspectCategoryRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return ProspectCategory::class;
    }
}
