<?php

namespace App\Repositories\Eloquent;

use App\Models\User;


class UserRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return User::class;
    }
}