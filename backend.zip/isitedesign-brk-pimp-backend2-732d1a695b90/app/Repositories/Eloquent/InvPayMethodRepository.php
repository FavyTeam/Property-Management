<?php

namespace App\Repositories\Eloquent;

use App\Models\InvPayMethod;


class InvPayMethodRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return InvPayMethod::class;
    }
}