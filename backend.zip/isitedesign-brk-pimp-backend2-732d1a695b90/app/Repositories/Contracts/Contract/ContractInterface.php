<?php

namespace App\Repositories\Contracts\Contract;

interface ContractInterface
{
    /**
     * Generate contRef
     *
     * @return mixed
     */
    public function generateContRef();
}