<?php

namespace App\Repositories\Contracts;

interface RepositoryInterface
{
    /**
     * @param array $columns
     * @return mixed
     */
    public function all($columns = ['*']);

    /**
     * Listing of paginated records
     *
     * @param int $perPage
     * @param array $columns
     * @return mixed
     */
    public function paginate($perPage = 25, $columns = ['*']);

    /**
     * Create new record
     *
     * @param array $data
     * @return mixed
     */
    public function create(array $data);

    /**
     * @param array $data
     * @param $id
     * @return mixed
     */
    public function update(array $data, $id);

    /**
     * Delete record
     *
     * @param $id
     * @return mixed
     */
    public function delete($id);

    /**
     *
     * @param $id
     * @param array $columns
     * @return mixed
     */
    public function find($id, $columns = ['*']);

    /**
     * Get a single row by a single column, '=' operator
     *
     * @param $field
     * @param $value
     * @param array $columns
     * @return mixed
     */
    public function findBy($field, $value, $columns = ['*']);

    /**
     * Sorting data
     *
     * @param string $field
     * @param string $direction
     * @return mixed
     */
    public function orderBy($field = 'id', $direction = 'desc');

    /**
     * Include relationship
     *
     * @param array $relations
     * @return mixed
     */
    public function with(array $relations);

    /**
     * Query criteria
     *
     * @param $field
     * @param $operator
     * @param $value
     * @return mixed
     */
    public function where($field, $operator, $value);

    /**
     * Get first row
     *
     * @return mixed
     */
    public function first();

    /**
     * Find whereIn
     *
     * @param $field
     * @param array $where
     * @param array $columns
     * @return mixed
     */
    public function findWhereIn($field, array $where, $columns = ['*']);

    /**
     * Find whereNotIn
     *
     * @param $field
     * @param array $where
     * @param array $columns
     * @return mixed
     */
    public function findWhereNotIn($field, array $where, $columns = ['*']);
}