<?php

namespace App\Repositories\Contracts\LandLord;

interface LandLordInterface
{
    /**
     * Generate lordRef
     *
     * @param $surName
     * @param $foreName
     * @return mixed
     */
    public function generateLordRef($surName, $foreName);
}