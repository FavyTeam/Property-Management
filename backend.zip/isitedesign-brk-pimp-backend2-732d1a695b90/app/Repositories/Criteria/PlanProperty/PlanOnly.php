<?php

namespace App\Repositories\Criteria\PlanProperty;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class PlanOnly extends Criteria
{
    private $type = 1;

    public function apply($model, Repository $repository)
    {
        return $model->join('plans', 'plans.id', '=', 'planproperties.planIdNo')->where('plans.planOrLand', '=', $this->type);
    }
}