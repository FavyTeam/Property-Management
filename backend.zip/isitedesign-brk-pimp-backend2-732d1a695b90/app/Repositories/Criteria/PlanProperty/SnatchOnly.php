<?php

namespace App\Repositories\Criteria\PlanProperty;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class SnatchOnly extends Criteria
{
    private $type = 2;

    public function apply($model, Repository $repository)
    {
        return $model->join('plans', 'plans.id', '=', 'planproperties.planIdNo')->where('plans.planOrLand', '=', $this->type);
    }
}