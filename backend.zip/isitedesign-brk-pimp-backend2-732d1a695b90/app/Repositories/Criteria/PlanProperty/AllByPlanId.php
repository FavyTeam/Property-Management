<?php

namespace App\Repositories\Criteria\PlanProperty;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class AllByPlanId extends Criteria
{
    private $planId;

    public function __construct($planId)
    {
        $this->planId = $planId;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('planproperties.planIdNo', '=', $this->planId);
    }
}