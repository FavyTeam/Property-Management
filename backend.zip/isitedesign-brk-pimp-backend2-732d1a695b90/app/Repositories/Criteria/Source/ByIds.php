<?php

namespace App\Repositories\Criteria\Source;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class ByIds extends Criteria
{
    private $sourceIds;

    public function __construct($sourceIds)
    {
        $this->sourceIds = $sourceIds;
    }

    public function apply($model, Repository $repository)
    {
        return $model->whereIn('id', $this->sourceIds);
    }
}
