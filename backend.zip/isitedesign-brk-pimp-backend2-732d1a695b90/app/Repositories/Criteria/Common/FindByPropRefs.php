<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByPropRefs extends Criteria
{
    private $propRefs;

    public function __construct($propRefs)
    {
        $this->propRefs = $propRefs;
    }

    public function apply($model, Repository $repository)
    {
        return $model->whereIn('propRef', $this->propRefs);
    }
}
