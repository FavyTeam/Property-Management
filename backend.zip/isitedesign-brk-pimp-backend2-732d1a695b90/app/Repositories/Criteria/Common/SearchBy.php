<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class SearchBy extends Criteria
{
    private $field;
    private $key;

    public function __construct($field, $key)
    {
        $this->field = $field;
        $this->key = $key;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where($this->field, 'LIKE', '%'.$this->key.'%');
    }
}