<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByProspectIdNo extends Criteria
{
    private $prospectIdNo;

    public function __construct($prospectIdNo)
    {
        $this->prospectIdNo = $prospectIdNo;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('prospectIdNo', '=', $this->prospectIdNo);
    }
}
