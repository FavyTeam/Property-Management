<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByPropRef extends Criteria
{
    private $propRef;

    public function __construct($propRef)
    {
        $this->propRef = $propRef;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('propRef', '=', $this->propRef);
    }
}
