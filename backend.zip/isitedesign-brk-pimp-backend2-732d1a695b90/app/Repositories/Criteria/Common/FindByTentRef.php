<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByTentRef extends Criteria
{
    private $tentRef;

    public function __construct($tentRef)
    {
        $this->tentRef = $tentRef;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('tentRef', '=', $this->tentRef);
    }
}
