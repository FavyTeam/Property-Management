<?php

namespace App\Repositories\Criteria\Common;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByLordRef extends Criteria
{
    private $lordRef;

    public function __construct($lordRef)
    {
        $this->lordRef = $lordRef;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('lordRef', '=', $this->lordRef);
    }
}
