<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FilterByArea extends Criteria
{
    private $area;

    public function __construct($area)
    {
        $this->area = $area;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('newproperties.area', $this->area);
    }
}