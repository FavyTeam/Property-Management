<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class Tolet extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->join('areas', 'areas.id', '=', 'newproperties.area')
                     ->where('newproperties.tolet', 1)
                     ->orderBy('areas.area', 'asc');
    }
}