<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class IsSharers extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->where('sharers', 1);
    }

}
