<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class IsFurnished extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->where('furnished', 1)
                     ->orWhere('furnished', 2)
                     ->orWhere('furnished', 4)
                     ->orWhere('furnished', 'LIKE', 'Part Furnished')
                     ->orWhere('furnished', 'LIKE', 'Fully Furnished');
    }

}
