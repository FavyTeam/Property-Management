<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class LessThanOrEqualToRent extends Criteria
{
    private $rent;

    public function __construct($rent)
    {
        $this->rent = $rent;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('rent', '<=', $this->rent);
    }
}
