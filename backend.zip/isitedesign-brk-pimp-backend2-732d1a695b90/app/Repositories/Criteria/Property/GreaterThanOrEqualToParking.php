<?php

namespace App\Repositories\Criteria\Property;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class GreaterThanOrEqualToParking extends Criteria
{
    private $parkingFor;

    public function __construct($parkingFor)
    {
        $this->parkingFor = $parkingFor;
    }

    public function apply($model, Repository $repository)
    {
        if($this->parkingFor) {
            return $model->where('parkingFor', '>=', $this->parkingFor);
        }
        return $model->where('parkingFor', 0);
    }
}
