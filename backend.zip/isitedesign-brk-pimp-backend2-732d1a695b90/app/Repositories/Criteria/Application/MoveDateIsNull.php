<?php

namespace App\Repositories\Criteria\Application;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class MoveDateIsNull extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->whereNull('moveDate');
    }
}
