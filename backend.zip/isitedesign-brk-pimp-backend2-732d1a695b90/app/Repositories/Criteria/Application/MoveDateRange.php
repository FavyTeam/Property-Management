<?php

namespace App\Repositories\Criteria\Application;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class MoveDateRange extends Criteria
{
    private $moveDateRange;

    public function __construct($moveDateRange)
    {
        $this->moveDateRange = $moveDateRange;
    }

    public function apply($model, Repository $repository)
    {
        return $model->whereBetween('moveDate', explode(',', $this->moveDateRange));
    }
}
