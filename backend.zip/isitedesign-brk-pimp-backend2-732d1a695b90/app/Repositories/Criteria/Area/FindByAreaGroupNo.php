<?php

namespace App\Repositories\Criteria\Area;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByAreaGroupNo extends Criteria
{
    private $areaGroupNo;

    public function __construct($areaGroupNo)
    {
        $this->areaGroupNo = $areaGroupNo;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('areaGroupNo', '=', $this->areaGroupNo);
    }
}
