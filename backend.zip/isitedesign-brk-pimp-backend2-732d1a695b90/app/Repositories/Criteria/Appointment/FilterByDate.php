<?php

namespace App\Repositories\Criteria\Appointment;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;
use DB;


class FilterByDate extends Criteria
{
    private $date;

    public function __construct($date)
    {
        $this->date = $date;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where(DB::raw('date(appointments.date)'), '=', $this->date);
    }
}
