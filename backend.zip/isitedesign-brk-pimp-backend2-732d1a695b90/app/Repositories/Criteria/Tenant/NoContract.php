<?php

namespace App\Repositories\Criteria\Tenant;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class NoContract extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->whereNull('contRef')->orWhere('contRef', '<', 1);
    }
}