<?php

namespace App\Repositories\Criteria\User;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class IsNotCurrent extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->whereNull('current')->orWhere('current', '=', 0);
    }
}
