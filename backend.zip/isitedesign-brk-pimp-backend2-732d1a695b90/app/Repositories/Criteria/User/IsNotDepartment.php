<?php

namespace App\Repositories\Criteria\User;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class IsNotDepartment extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->whereNull('department')->orWhere('department', '=', 0);
    }
}
