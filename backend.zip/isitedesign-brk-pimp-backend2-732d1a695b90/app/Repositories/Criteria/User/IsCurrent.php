<?php

namespace App\Repositories\Criteria\User;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class IsCurrent extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->where('current', '=', 1);
    }
}
