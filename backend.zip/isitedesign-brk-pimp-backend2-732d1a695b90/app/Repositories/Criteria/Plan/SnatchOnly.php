<?php

namespace App\Repositories\Criteria\Plan;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class SnatchOnly extends Criteria
{
    private $type = 2;

    public function apply($model, Repository $repository)
    {
        return $model->where('planOrLand', '=', $this->type);
    }
}