<?php

namespace App\Repositories\Criteria\Diary;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindDatesBefore extends Criteria
{
    private $dateBefore;

    public function __construct($dateBefore)
    {
        $this->dateBefore = $dateBefore;
    }

    public function apply($model, Repository $repository)
    {
        #dd($this->dateBefore);
        return $model->where('date', '<', $this->dateBefore);
    }
}
