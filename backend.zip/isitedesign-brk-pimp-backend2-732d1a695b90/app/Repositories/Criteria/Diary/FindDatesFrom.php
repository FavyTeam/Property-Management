<?php

namespace App\Repositories\Criteria\Diary;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindDatesFrom extends Criteria
{
    private $dateFrom;

    public function __construct($dateFrom)
    {
        $this->dateFrom = $dateFrom;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('date', '>=', $this->dateFrom);
    }
}
