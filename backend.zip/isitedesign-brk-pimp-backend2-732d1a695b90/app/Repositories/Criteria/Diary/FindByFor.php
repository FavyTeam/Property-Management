<?php

namespace App\Repositories\Criteria\Diary;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class FindByFor extends Criteria
{
    private $for;

    public function __construct($for)
    {
        $this->for = $for;
    }

    public function apply($model, Repository $repository)
    {
        return $model->where('for', '=', $this->for);
    }
}
