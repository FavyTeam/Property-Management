<?php

namespace App\Repositories\Criteria\MaintEngineer;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class NotUsedCondition extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->where('maintName', 'LIKE', '%NOT USED%');
    }
}
