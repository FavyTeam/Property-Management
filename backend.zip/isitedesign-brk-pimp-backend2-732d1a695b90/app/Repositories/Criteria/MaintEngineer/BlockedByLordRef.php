<?php

namespace App\Repositories\Criteria\MaintEngineer;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;
use App\Models\LordBlock;


class BlockedByLordRef extends Criteria
{
    private $lordRef;

    public function __construct($lordRef)
    {
        $this->lordRef = $lordRef;
    }

    public function apply($model, Repository $repository)
    {
        return $model->whereNotIn('id', LordBlock::where('lordRef', '=', $this->lordRef)->pluck('Maintref')->toArray());
    }
}
