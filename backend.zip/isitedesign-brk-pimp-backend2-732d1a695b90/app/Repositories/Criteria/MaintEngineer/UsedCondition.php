<?php

namespace App\Repositories\Criteria\MaintEngineer;

use App\Repositories\Criteria\Criteria;
use App\Repositories\Contracts\RepositoryInterface as Repository;


class UsedCondition extends Criteria
{
    public function apply($model, Repository $repository)
    {
        return $model->where('maintName', 'NOT LIKE', '%NOT USED%');
    }
}