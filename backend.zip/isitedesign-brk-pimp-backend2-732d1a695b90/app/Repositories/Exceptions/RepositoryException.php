<?php

namespace App\Repositories\Exceptions;

class RepositoryException
{

}