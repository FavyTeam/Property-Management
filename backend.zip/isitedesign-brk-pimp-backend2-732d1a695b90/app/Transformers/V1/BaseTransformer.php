<?php

namespace App\Transformers\V1;

use League\Fractal\TransformerAbstract;
use App\Models\BaseModel;


class BaseTransformer extends TransformerAbstract
{
    /**
     * transform()
     *
     * @param BaseModel $model
     * @return array
     */
    public function transform(BaseModel $model)
    {
        // give back the transform result
        return $model->toArray();
    }
}