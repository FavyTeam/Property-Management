<?php

namespace App\Transformers\V2;

use App\Models\Diary;
use App\Models\NewProperty;
use League\Fractal\TransformerAbstract;

class DiaryTransformer extends TransformerAbstract
{

    protected $availableIncludes = [
        'newProperty'
    ];

    public function transform(Diary $diary)
    {
        return [
            'id' => $diary->id,
            'diaryIdNo' => $diary->DiaryIdNo,
            'lock' => $diary->Lock,
            'bookedBy' => $diary->BookedBy,
            'bookedDate' => $diary->BookedDate,
            'bookedTime' => $diary->BookedTime,
            'date' => $diary->Date,
            'time' => $diary->Time,
            'someType' => $diary->Type,
            'timed' => $diary->Timed,
            'for' => $diary->For,
            'newProperty' => $diary->PropRef,
            'name' => $diary->Name,
            'prospect' => $diary->Prospect,
            'plan' => $diary->PLAN,
            'planProperty' => $diary->Planproperty,
            'address' => $diary->Address,
            'details' => $diary->Details,
            'conf1By' => $diary->Conf1By,
            'conf1Date' => $diary->Conf1Date,
            'conf1Time' => $diary->Conf1Time,
            'conf1Notes' => $diary->Conf1Notes,
            'conf2By' => $diary->Conf2By,
            'conf2Date' => $diary->Conf2Date,
            'conf2Time' => $diary->Conf2Time,
            'conf2Notes' => $diary->Conf2Notes,
            'area' => $diary->Area,
            'createdAt' => $diary->created_at,
            'updatedAt' => $diary->updated_at,
            'deletedAt' => $diary->deleted_at ? $diary->deleted_at : null
        ];
    }

    public function includeNewProperty(Diary $diary)
    {
        if ($newProperty = $diary->newProperty) {
            return $this->item($newProperty, new NewPropertyTransformer(), 'newProperties');
        }
    }
}
