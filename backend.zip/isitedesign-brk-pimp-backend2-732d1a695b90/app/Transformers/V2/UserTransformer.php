<?php

namespace App\Transformers\V2;

use App\Models\User;
use League\Fractal\TransformerAbstract;

class UserTransformer extends TransformerAbstract
{
    public function transform(User $user)
    {
        return [
            'firstName' => $user->first_name,
            'lastName' => $user->last_name,
            'userName' => $user->Username,
            'initials' => $user->Initials,
            'ratsDate' => $user->Ratsdate,
            'currentStatus' => $user["Current Status"],
            'ext' => $user->Ext,
            'activity' => $user->Activity,
            'loggedIn' => $user->Loggedin,
            'lunch' => $user->Lunch,
            'out' => $user->Out,
            'inactivity' => $user->Inactivity,
            'security' => $user->Security,
            'management' => $user->Management,
            'prospects' => $user->Prospects,
            'prospectsDefault' => $user->Prospectsdefault,
            'maximumProspects' => $user->MaximumProspects,
            'letterHead' => $user->Letterhead,
            'department' => $user->Department,
            'tenantAccount' => $user->TenantAccount,
            'addProperty' => $user->AddProperty,
            'febootiMail' => $user->Febootimail,
            'current' => $user->Current,
            'rac' => $user->RAC,
            'delProsp' => $user->Delprosp,
            'emailSignature' => $user->EmailSignature,
            'board' => $user->Board,
            'updateRequired' => $user->Updaterequired,
            'mobileNumber' => $user->Mobilenumber,
            'returnDate' => $user->Returndate,
            'returnTime' => $user->Returntime,
            'receptionFrom' => $user->Receptionfrom,
            'receptionTo' => $user->ReceptionTo,
            'janitor' => $user->Janitor,
            'seen' => $user->Seen,
            'ratsDateIn' => $user->ratsdatein,
            'ratsTimeIn' => $user->ratstimein,
            'ratsDateOut' => $user->ratsdateout,
            'ratsTimeOut' => $user->ratstimeout,
            'viewings' => $user->Viewings,
            'nextEvening' => $user->Nextevening,
            'logout' => $user->Logout,
            'createdAt' => $user->created_at,
            'updatedAt' => $user->updated_at,
            'deletedAt' => $user->deleted_at ? $user->deleted_at : null
        ];
    }
}
