<?php

namespace App\Transformers\V2;

use App\Models\Diary;
use App\Models\NewProperty;
use League\Fractal\TransformerAbstract;

class NewPropertyTransformer extends TransformerAbstract
{
    public function transform(NewProperty $newProperty)
    {
        return [
            'id' => $newProperty->PropertyRef,
            'lordRef' => $newProperty->LordRef
        ];
    }
}
