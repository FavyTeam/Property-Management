<?php

/**
 * Extract integer value from string
 *
 * @param string $string
 * @return int
 */
if (!function_exists('get_integer_val')) {
    function get_integer_val($string) {
        return intval(preg_replace('/[^0-9]+/', '', $string), 10);
    }
}

/**
 * Trim string according to length
 *
 * @param string $string
 * @param int $length
 * @param int $start
 * @return string
 *
 */
if (!function_exists('trim_string')) {
    function trim_string($string, $length = 10, $start = 0) {
        return substr($string, $start, $length);
    }
}