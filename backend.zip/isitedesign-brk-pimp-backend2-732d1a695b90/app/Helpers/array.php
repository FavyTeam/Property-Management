<?php

if (!function_exists('array_rename_keys')) {
    function array_rename_keys($array, $keyMapping) {
        foreach ($keyMapping as $oldKey => $newKey) {
            if (array_key_exists($oldKey, $array)) {
                $array[$newKey] = $array[$oldKey];
                unset($array[$oldKey]);
            }
        }
        return $array;
    }
}
