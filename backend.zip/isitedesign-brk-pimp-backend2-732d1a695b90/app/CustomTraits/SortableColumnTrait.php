<?php
namespace App\CustomTraits;

use Illuminate\Database\Eloquent\Builder;


trait SortableColumnTrait
{

    protected $sortableColumnsMap = [];
    protected $sortableColumns = [];

    /**
     * Maps the column received from the request to the correct column name in its db table
     * ex. 'testName' will be mapped to  'data->test->name'.
     * If column doesn't exist in the array, the value of $column will be returned.
     * @param $column
     * @return string|callable
     */
    private function getSortableColumn($column) {
        if (in_array($column, $this->sortableColumns)) {
            return array_get($this->sortableColumnsMap, $column, $column);
        }
    }

    protected function sortBy(Builder $query, $sortBy) {
        $sortByParts = explode(',', $sortBy);
        collect($sortByParts)
            ->each(function ($column) use ($query) {
                $direction = starts_with($column, '-') ? "desc" : "asc" ;
                $column = $this->getSortableColumn(ltrim($column, '-'));

                if (!$column) {
                    return null;
                }
                if (is_callable($column)) {
                    return $column($query, $direction);
                }
                $query->orderBy($column, $direction);
            });

        return $query;
    }

}
